
"""
    Testing in programming means checking if your code works as expected. It’s a systematic way to find and fix errors
    (bugs) before your code goes live.

    Python has some very useful testing modules such as:
        1. Pytest
        2. Unittest
        3. tox
"""

"""
    Unit Test module is a built-in module provided for testing. Certain nomenclature has to be followed for using this 
    module.
    
        everything has to be prepended with 'test_'. A class has to be defined in which we will wrtie the test and the class
        will inherit the Unittest.Testcase class to work.
        
        The methods inside the class also have to have test_ before them
"""

