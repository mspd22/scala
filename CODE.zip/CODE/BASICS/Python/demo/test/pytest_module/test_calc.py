import _0_pytest as calc
import pytest

def test_add():
    assert calc.add(10,2) == 12

def test_div():
    assert calc.div(10,5) == 2

"""
def test_div_by_0():
    calc.div(10, 0)
    assert True
    ''''
    def test_div_by_0():
    >  calc.div(10, 0)
    
    test_calc.py:10: 
    _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
    
    x = 10, y = 0
    
        def div(x, y):
            if y == 0:
    >           raise ZeroDivisionError('Can not divide by Zero')
    E           ZeroDivisionError: Can not divide by Zero
    '''
"""

def test_div_by_0():
    with pytest.raises(ZeroDivisionError):
        calc.div(10,0)

