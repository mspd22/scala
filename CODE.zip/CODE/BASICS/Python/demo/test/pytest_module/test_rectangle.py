import pytest
from _1_fixtures import Rectangle

def test_area():

    rectangle = Rectangle(7,6)
    assert rectangle.area() == 42


def test_perimeter():

    rectangle = Rectangle(3,5)
    assert rectangle.perimeter() == 16

"""
    ============================= test session starts ==============================
    collecting ... collected 2 items
    
    test_rectangle.py::test_area PASSED                                      [ 50%]
    test_rectangle.py::test_perimeter PASSED                                 [100%]
    
    ============================== 2 passed in 0.06s ===============================
    
    Until now there are no problems but we are defining the rectangle object two times here.
    We can use fixtures to reduce the code
"""

@pytest.fixture
def my_rectangle():
    return Rectangle(7, 6)

def test_area_2(my_rectangle):
    assert my_rectangle.area() == 42

def test_perimeter_2(my_rectangle):
    assert my_rectangle.perimeter() == 26

"""
    =============================  test session starts ==============================
    collecting ... collected 4 items
    
    test_rectangle.py::test_area PASSED                                      [ 25%]
    test_rectangle.py::test_perimeter PASSED                                 [ 50%]
    test_rectangle.py::test_area_2 PASSED                                    [ 75%]
    test_rectangle.py::test_perimeter_2 PASSED                               [100%]
    
    ============================== 4 passed in 0.02s ===============================
"""

"""
    WE CAN ALSO CREATE A CONFTEST.PY FILE to declare global variables which will be available for all the test files in the ]
    project.
"""