
"""
    PyTest -> A Testing Framework for Python unit Testing "and nose"

    Some features of PyTest
    1. Auto-Discovery of Tests using `_test` and `test_`
    2. Rich Assertion Introspection -> Just a fancy way of writing very detailed documentation of why a certain test failed.
    3. It supports parameterized and fixture based testing.

    Advantages of Using Python
    1. Simplified Syntax
    2. Rich Assertion Introspection
    3. Powerful Fixture System
    4. Compatibility
    5. Extensibility
"""
import math

def add(x, y):
    """Add Function"""
    return x + y

def sub(x, y):
    """Sub Function"""
    return x - y

def mul(x, y):
    """Mul Function"""
    return x * y

def div(x, y):
    """Div Function"""
    if y == 0:
        raise ZeroDivisionError('Can not divide by Zero')
    return x / y

class Shape:

    def area(self):
        pass

    def perimeter(self):
        pass

class Circle(Shape):

    def __init__(self,radius):
        self.radius = radius

    def area(self):
        return math.pi * (self.radius ** 2)

    def perimeter(self):
        return math.pi * self.radius * 2