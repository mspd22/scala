import math

import pytest
from _0_pytest import Shape,Circle

class Test_Circle:

    """
        The setup and teardown methods are used like some kind of context manager where certain operations which are
        for the complete lifecycle of current test are required to run are executed.

        Like constructor and destructors in normal classes
    """

    def setup_method(self, method):
        print(f"Set up Method {method}")
        self.circle = Circle(10)


    def teardown_method(self,method):
        print(f"Tearing Down {method}")

    def test_radius(self):
        assert self.circle.radius == 10

    def test_area(self):
        assert self.circle.area() == self.circle.radius ** 2 * math.pi

    def test_perimeter(self):
        assert self.circle.perimeter() == self.circle.radius * 2 * math.pi