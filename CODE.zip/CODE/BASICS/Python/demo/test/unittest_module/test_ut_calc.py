import unittest
import _0_unittest as calc

class test_calc(unittest.TestCase):

    def test_add(self):
        """
        All of these assert statements are counted as just one test

        :return: None
        """
        self.assertEqual(calc.add(10,5),15)
        self.assertEqual(calc.add(-1, 1), 0)
        self.assertEqual(calc.add(-1, -1), -2)

    def test_sub(self):
        self.assertEqual(calc.sub(10, 5), 5)
        self.assertEqual(calc.sub(-1, 1), -2)
        self.assertEqual(calc.sub(-1, -1), 0)

    def test_mul(self):
        self.assertEqual(calc.mul(10, 5), 50)
        self.assertEqual(calc.mul(-1, 1), -1)
        self.assertEqual(calc.mul(-1, -1), 1)

    def test_div(self):
        self.assertEqual(calc.div(10, 5), 2)
        self.assertEqual(calc.div(-1, 1), -1)
        self.assertEqual(calc.div(-1, -1), 1)

        '''
            TO check if an exception we are using is also being used correctly we can use unittest to see if it is raised
            at the proper time.
        '''

        # Method 1
        self.assertRaises(ValueError,calc.div,5,0) # --> OK

        # Method 2
        with self.assertRaises(ValueError):
            calc.div(5,0)
        # OK



"""
    Normally we would have to write `python -m unittest test_ut_calc.py` to run the tests but we can also use the 
        __name__ == __main__ conditional to run it from this file itself
        

    # Although currently the IDE is providing with a run button directly due to its python specific features present.
    
    
    For Test pass
        .
        ----------------------------------------------------------------------
        Ran 1 test in 0.000s
        
        OK
    
    For Test Fail
        F
        ======================================================================
        FAIL: test_add (test_ut_calc.test_calc.test_add)
        ----------------------------------------------------------------------
        Traceback (most recent call last):
          File "test_ut_calc.py", line 8, in test_add
            self.assertEqual(result,14)
            ~~~~~~~~~~~~~~~~^^^^^^^^^^^
        AssertionError: 15 != 14
        
        ----------------------------------------------------------------------
        Ran 1 test in 0.001s
        
        FAILED (failures=1)
    
    When a test fails the exact statement is provided to check and fix the problem

"""

if __name__ == "__main__":
    unittest.main()

