
def add(x, y):
    """Add Function"""
    return x + y

def sub(x, y):
    """Sub Function"""
    return x - y

def mul(x, y):
    """Mul Function"""
    return x * y

def div(x, y):
    """Div Function"""
    if y == 0:
        raise ValueError('Can not divide by Zero')
    return x / y

class Employee:

    raise_amount = 1.05

    def __init__(self,first_name,last_name,pay):
        self.first_name = first_name
        self.last_name = last_name
        self.pay = pay

    @property
    def email(self):
        return self.first_name + "." + self.last_name + "@email.com"

    @property
    def fullname(self):
        return self.first_name + " " + self.last_name

    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amount)

    def __repr__(self):
        return f'Name : {self.first_name} {self.last_name}, Email : {self.email}, Pay : {self.pay}'


