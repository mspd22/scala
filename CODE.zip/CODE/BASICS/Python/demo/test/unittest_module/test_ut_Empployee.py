import unittest
from _0_unittest import Employee

"""
    Tests can run in any order, so do not assume that they will run in the same order as you define. Hence it is necessary 
    to isolate each test.
"""
class TestEmployee(unittest.TestCase):

    """
    Set up class and Tear Down Class are class methods which are useful for constructing and destructing test resources
    before and after the testing has been done.
    """
    @classmethod
    def setUpClass(cls):
        print("SetUpClass")

    @classmethod
    def tearDownClass(cls):
        print("TearDownClass")

    def setUp(self):
        print('setUp')
        self.emp_1 = Employee('Corey', 'Schafer', 50000)
        self.emp_2 = Employee('Sue', 'Smith', 60000)

    def tearDown(self):
        print('tearDown\n')

    def test_email(self):
        print('test_email')
        self.assertEqual(self.emp_1.email, 'Corey.Schafer@email.com')
        self.assertEqual(self.emp_2.email, 'Sue.Smith@email.com')

        self.emp_1.first_name = 'John'
        self.emp_2.first_name = 'Jane'

        self.assertEqual(self.emp_1.email, 'John.Schafer@email.com')
        self.assertEqual(self.emp_2.email, 'Jane.Smith@email.com')

    def test_fullname(self):
        print('test_fullname')
        self.assertEqual(self.emp_1.fullname, 'Corey Schafer')
        self.assertEqual(self.emp_2.fullname, 'Sue Smith')

        self.emp_1.first_name = 'John'
        self.emp_2.first_name = 'Jane'

        self.assertEqual(self.emp_1.fullname, 'John Schafer')
        self.assertEqual(self.emp_2.fullname, 'Jane Smith')

    def test_apply_raise(self):
        print('test_apply_raise')
        self.emp_1.apply_raise()
        self.emp_2.apply_raise()

        self.assertEqual(self.emp_1.pay, 52500)
        self.assertEqual(self.emp_2.pay, 63000)


if __name__ == '__main__':
    unittest.main()

