def main():
    pass


if __name__ == "__main__":
    main()

"""
    When python first runs a file before it executes or reads any code it will set up a few special
    variables and __name__ is one of them 
    
    And when python runs a python file directly it sets its name to __main__
    
    But when we import a module then the __name__ variable is set to the name of the file
    
    SO we can set up cases when we want to perform a particular operation when the file is run directly and when it was 
    imported
"""

"""
    Duck Typing and EAFP
    
    Duck Typing -> If it acts like a duck and quacks like a duck then it is DUCK!
    
    We do not care it is another class or not we do not care we will run it like a DUCK
    
    
    To check whether a method exists or not -> Look before you leap => This is non-pythonic
    
    Easier to ask for forgiveness then permission -> pythonic
        Do not ask permission to do something all the time just do it and we will handle it if it does not work
"""

"""
def quack_and_fly :

    look before you leap -> LBYL
    if hasattr(thing,'fly'):
        if callable(thing) :
            then do something

"""

"""
    Python is a multi-paradigm programming language, which means that it supports several programming paradigms. Some of the
     main paradigms supported by Python are:

    1. Imperative programming: This paradigm focuses on telling the computer what to do, step by step. Python supports imperative 
        programming with features such as variables, loops, and control structures.
        
    2. Object-oriented programming (OOP): This paradigm is based on the idea of objects and their interactions. Python supports 
    OOP with features such as classes, inheritance, and polymorphism.
    
    3. Functional programming: This paradigm is based on the idea of functions as first-class citizens, and it emphasizes the 
    use of pure functions and immutable data. Python supports functional programming with features such as higher-order 
    functions, lambda expressions, and generators.
    
    4. Aspect-oriented programming: This paradigm is based on the idea of separating cross-cutting concerns from the main
     functionality of a program. Python does not have built-in support for aspect-oriented programming, but it can be 
     achieved using libraries or language extensions.    
"""


"""
    Code Formatting - It is crucial for maintaining readability, consistency, and reducing errors. PEP 8 Style Guides.
    
    There are several code formatter available for python. Some examples include
    
        1. Black - Black aims for consistency, generality, readability and reducing git diffs. Similar language 
            constructs are formatted with similar rules. It is opinionated along with following PEP 8 Style Guides
            
        Style configuration options are deliberately limited and rarely added. Previous formatting is taken into 
        account as little as possible, with rare exceptions like the magic trailing comma. The coding style used by 
        Black can be viewed as a strict subset of PEP 8.
        
        2. Ruff - An extremely fast Python linter and code formatter, written in Rust.
"""
