
print("Imported myModule....")

test = "Test String"

def find_index(to_search, target) :
    """
        Finds the index of the search term int the given list
    """
    for i,ele in enumerate(to_search):
        if ele == target: return i

    return -1
