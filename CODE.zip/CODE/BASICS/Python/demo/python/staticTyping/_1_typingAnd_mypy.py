"""
Typing - A built-in module used for providing type annotations and type hints for type checkers.
"""

from typing import TypeAlias, Any, Sequence, Callable, TypeVar

"""
    Variables - Technically many of the type annotations shown below are redundant, since mypy can usually infer the type of
            variable from its value.
"""
# This is how you declare the type of variable
age: int = 1

# You don't need to initialize a variable to annotate it
a: int  # Ok (no value at runtime until assigned)

# Doing so can be useful in conditional branches
child: bool
if age < 18:
    child = True
else:
    child = False

"""
    For more examples and types see : `https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html`
    
    Advanced - `https://docs.python.org/3/library/typing.html
"""

# When we say that
ex: str = 10
# We can see that we do not get a run time error because static typing using annotations is only a documentation not
# an enforcing rule. The type hint will not define or change python to a strongly typed language.

"""
    TO be strict and always enforce the type annotations we can check our code during compile time using a static type checker
    like - mypy
    
    just type `mypy path_to_python_script` to see if there are any errors in the type hints or annotations
    
    Example:
        - for the above line we will get an error like this
        
        $ -> mypy demo/python/staticTyping/_1_typingAnd_mypy.py
        demo/python/staticTyping/_1_typingAnd_mypy.py:31: error: Incompatible types in assignment (expression has type "int", variable has type "str")  [assignment]
        Found 1 error in 1 file (checked 1 source file)
    
    Static Code Analysis Tool -> This is what a static code analysis tool is used for and it is very useful for having 
    proper documentation of type hints.
"""


# Function Annotation
def add_numbers(arg1: int = 1, arg2: int = 5) -> int:
    return arg1 + arg2


print(add_numbers(4, 5))

# List Types

nums: list[list[int]] = [[1, 2], [12, 13]]
print(nums)

# For variable data types
my_mixed_list: list[int | str] = [
    1,
    "a",
    2,
    "b",
]  # or my_mixed_list: List[int | str] = [1, 'a', 2, 'b']

# List with a specified size
my_fixed_length_list: list[int] = [
    1,
    2,
    3,
]  # or my_fixed_length_list: List[int, int, int] = [1, 2, 3]

# List with a variable type
# my_variable_length_list: list[int,...] = [1, 2, 3, 4, 5]  # or my_variable_length_list: List[int,...] = [1, 2, 3, 4, 5]

"""
    The same for other collections types as well
"""

"""
    TypeAliases and Type Keyword
"""
Vector = list[float]
# or
type vector = list[float]
# or
Vector2: TypeAlias = list[vector]

"""
NewType
Use the NewType helper to create distinct types:

from typing import NewType

UserId = NewType('UserId', int)
some_id = UserId(524313)
"""

"""
    Optional Types
    
    It can be something or the other
"""


def foo(output: bool | None) -> None:
    print(output)


"""
    Any -> It could be anything
"""


def bar(output: Any):
    print(output)


"""
    Sequence 
"""


def fooSeq(seq: Sequence[str]) -> None:
    if type(seq[0] == str):
        print(seq)


fooSeq(("a", "b", "c"))  # Tuple
fooSeq(["a", "b", "c"])  # List
fooSeq("Hello")  # String
fooSeq(
    1
)  # Error in mypy -> demo/python/staticTyping/_1_typingAnd_mypy.py:125: error: Argument 1 to "fooSeq" has incompatible type "int"; expected "Sequence[str]"  [arg-type]

""" !!!! Tuples """
x: tuple[int, int, int] = (
    12,
    3,
    4,
)  # Should specify everything inside a tuple for every index


"""
    Callable -> Functions as arguments or returns
    
    The last datatype should be the return type
"""


def fooCall(func: Callable[[int, int], int]):
    func(1, 2)


fooCall(add_numbers)  # No errors

"""
    Generics -> IDK what type it will be at the moment
"""

T = TypeVar("T")


def get_item(lst: list[T], index: int) -> T:
    return lst[index]


"""
    MYPY -> A static Code Analysis tool.
        
        - mypy file_name.py -> Analyse the file using mypy for annotation and type mistakes.
    
        - Strict Mode -> Annotations are necessary
            => mypy file_name.py --strict (for one file)
"""
