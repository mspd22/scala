"""
    Static typing in Python is a way to specify the data type of variable, function parameter, or return value before
    the code is executed. This is in contrast to dynamic typing, which is the default behavior in Python, where the
    data type of variable is determined at runtime.

    - In Python, static typing is optional and is typically done using type hints, which are annotations that indicate the
     expected data type of variable, function parameter, or return value.

     - Type hints are not enforced by the Python interpreter, but they can be used by third-party tools, such as type
     checkers, linters, and IDEs, to catch type-related errors before the code is executed.

     Advantages of static typing in python include:
        1. Better Code readability.
        2. Fewer Runtime Errors.
        3. Improved Code Maintainability.
        4. Better support for IDEs and tools.
"""

"""
    Pydantic, mypy, pyre, typing, and pyright are all related to type checking and static typing in Python, but they 
    serve different purposes and have different focuses:

    1. typing: 
        - It is a built-in Python module that provides support for type hints and static typing. It defines the syntax 
        and semantics for type hints, including the type function, type aliases, and generic types. typing is the 
        foundation for static typing in Python and is used by all the other tools mentioned below.

    2. mypy:
        - It is a static type checker for Python that checks the types of variables, function parameters, and return 
        values at compile-time. It's a separate tool that can be run on your Python code to catch type-related errors 
        before runtime. mypy is widely used and has a large community of users and contributors.

    3. pyre:
        - It is a static type checker for Python developed by Facebook. It's similar to mypy but has some differences in
         its approach and features. pyre is designed to be more scalable and efficient than mypy and provides additional
          features like incremental type checking and support for more advanced type system features.

    4. pyright:
        - It is a static type checker for Python developed by Microsoft. It's designed to be fast, scalable, and highly
         configurable. pyright provides features like incremental type checking, support for type inference, and 
         integration with popular IDEs like Visual Studio Code.

    5. pydantic:
        - It is a Python library that provides runtime type checking and validation for Python data models. It's not a 
        static type checker like mypy, pyre, or pyright, but rather a library that helps you define and validate data 
        models at runtime. pydantic is often used for building robust and scalable data models, especially in web 
        applications and APIs.
"""