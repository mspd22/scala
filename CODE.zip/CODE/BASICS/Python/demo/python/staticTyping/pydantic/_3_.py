"""
    Custom Validators
        There are two types of custom validators we can use. They are
        1. Before Pydantic Validators
        2. After Pydantic Validators

    Validators in pydantic are not only checkers but are also transformers
"""
from xml.etree.ElementTree import indent

from mypy.meet import are_typed_dicts_overlapping
from pydantic import BaseModel, Field, ValidationError, field_validator


class Model(BaseModel):
    absolute : int = Field(ge=0)

try:
    m1 = Model(absolute=10)
    m2 = Model(absolute=-5)
except ValidationError as ve:
    print(ve)
    '''
        1 validation error for Model
        absolute
          Input should be greater than or equal to 0 [type=greater_than_equal, input_value=-5, input_type=int]
    '''

'''
    We can also define our own transformation
'''
class Model(BaseModel):
    absolute : int

    @field_validator('absolute')
    @classmethod
    def make_absolute(cls, value):
        return abs(value)
    '''
        Here we are not checking to see if the value is actually a integer or not because we are using an 
        after validator. Hence it is already coerced into a integer.
    '''

m3 = Model(absolute=10)
m4 = Model(absolute=10)
print(m3)
print(m4)


"""
    Nested Models
"""
data = {
    "first_name" : "Arthur",
    "last_name" : "Clarke",
    "born" : {
        "place" : {
            "country" : "Lunar Colony",
            "city" : "Central City"
        },
        "date" : "3001-01-10"
    }
}

from datetime import datetime, date


class Place(BaseModel):
    country : str
    city : str

class Born(BaseModel):
    place : Place
    dt : date = Field(alias="date")

class Person(BaseModel):

    first_name : str | None = Field(alias="first_name",default=None)
    last_name : str = Field(alias="last_name")
    born : Born | None = None

arthur = Person.model_validate(data) # No Validation Errors
print(arthur.model_dump())
'''
    {
    'first_name': 'Arthur',
    'last_name': 'Clarke',
    'born': {
        'place': {
            'country': 'Lunar Colony',
            'city': 'Central City'},
        'dt': datetime.date(3001, 1, 10)
        }
    }
'''