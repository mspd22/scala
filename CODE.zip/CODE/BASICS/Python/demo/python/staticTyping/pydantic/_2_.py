
"""
    Custom Serializers - Pydantic has predefined serialization rules

    ex floats have a predefined precision etc.,
"""

from pydantic import BaseModel, field_serializer, Field
from datetime import datetime, timezone


class Model(BaseModel):
    number : float

m = Model(number=1.0)
print(m.model_dump()) # --> {'number': 1.0}
m = Model(number=(1/3))
print(m.model_dump()) # --> {'number': 0.3333333333333333}

'''
    Similarly pydantic serialises dates in the ISO format
'''
class Model(BaseModel):
    dt : datetime

m = Model(dt = datetime.now(timezone.utc))
print(m.model_dump()) # --> {'dt': datetime.datetime(2025, 3, 17, 5, 35, 51, 694852, tzinfo=datetime.timezone.utc)}
print(m.model_dump_json()) # --> {"dt":"2025-03-17T05:36:40.417059Z"}

"""
    We want to customize such that all float values are set to 2 precision in both dump methods
"""

class Model(BaseModel):
    number : float
    dt : datetime = Field(default_factory= lambda : datetime.now(timezone.utc))

    @field_serializer('number')
    def serialize_float(self,value):
        return round(value,2)

    @field_serializer('dt',when_used='json-unless-none')
    def serialize_date(self,dt):
        return dt.strftime("%Y/%-m%-d %I:%M %p")
    '''
        Here we are specifying to only use the serializer when we are serializing to json and the value provided is not None
    '''

m = Model(number=(1/3))
print(m.model_dump()) # --> {'number': 0.33, 'dt': datetime.datetime(2025, 3, 17, 5, 44, 38, 131782, tzinfo=datetime.timezone.utc)}
print(m.model_dump_json()) # --> {"number":0.33,"dt":"2025/317 05:44 AM"}



