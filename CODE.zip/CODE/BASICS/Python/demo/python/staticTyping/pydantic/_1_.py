from datetime import datetime, timezone

from pydantic import BaseModel, ValidationError, Field


class Person(BaseModel):
    first_name: str = "Jane"
    last_name: str = "Doe"
    # age: int No default value will give validation error when trying to create an object without providing this field value explicitly
    age : int = 0

"""
    Required vs Optional Fields
    
    If we do not specify any default values for the fields in the class them pydantic will throw a validation error when we
    try to create an object with incomplete data
    
    But we need to be careful while using default fields as pydantic will not validate them during compile time.
"""

try :
    person = Person()
except ValidationError as ve:
    print(ve)
    #1 validation error for Person
    # age
    #   Field required [type=missing, input_value={}, input_type=dict]

"""
    We can check what fields are available for a class and if they are required or not.
    
    {
     'first_name': FieldInfo(annotation=str, required=False, default='Jane'), 
     'last_name': FieldInfo(annotation=str, required=False, default='Doe'), 
     'age': FieldInfo(annotation=int, required=False, default=0)
    }
"""
print(Person.model_fields)

"""
    Nullable Fields
    
    We can declare fields as None if we think that they will can be null as well
    
    or
    
    We can use the Optional keyword and say Optional[str]
"""

class Person(BaseModel):
    first_name: str | None
    last_name: str
    # age: int No default value will give validation error when trying to create an object without providing this field value explicitly
    age : int = 0

print(Person.model_fields)
'''
{
    'first_name': FieldInfo(annotation=Union[str, NoneType], required=True),
    'last_name': FieldInfo(annotation=str, required=False, default='Doe'),
    'age': FieldInfo(annotation=int, required=False, default=0)}
    
    So now we can say
'''
p = Person(first_name=None, last_name="Smith", age = 19)
print(p) # first_name=None last_name='Smith' age=19

"""
    Aliases and Field Classes
    
    Sometimes we cannot serialise data due to improper or incorrect field names of the data provided. This can be
    avoided by using Pydantic Aliases and Fields Classes
"""
data = {
    "id" : 100,
    "First Name" : "John",
    "LASTNAME" : "Smith",
    "age in years" : 42
} # This data sample has field names with are not suitable for pythonic uses cases at all so we can use Field classes to change them
class Person(BaseModel):
    id_ : int = Field(alias="id")
    first_name: str = Field(alias="First Name")
    last_name : str = Field(alias="LASTNAME")
    age: int = Field(alias="age in years",default=0)
    '''
        We can also define some default values in the field class
    '''

p = Person.model_validate(data)
print(p) # id_=100 first_name='John' last_name='Smith' age_=42
p.first_name = "Jack"

"""
    Serialization of pydantic objects
"""

print(p.model_dump()) # -->  {'id_': 100, 'first_name': 'John', 'last_name': 'Smith', 'age': 42}
# We can also use the original aliases if we want(commonly used in APIs)
print(p.model_dump_json(by_alias=True)) # --> {"id":100,"First Name":"John","LASTNAME":"Smith","age in years":42}


"""
    Mutable Defaults - They are fine to define in pydantic as, during the creation of an instance of a
    class it will check for any mutable fields and perform a deep copy of the default values provided(if any)
"""
class Model(BaseModel):
    numbers : list[int] = []

m1 = Model()
m2 = Model()

print(id(m1))
print(id(m2)) # Different

"""
    Default Factories - Dynamic Default values for pydantic classes
"""

class Log(BaseModel):
    dt : datetime = Field(default_factory=lambda : datetime.now(timezone.utc))
    message : str

log1 = Log(message="Message 1")
log2 = Log(message="Message 2")

print(log1) #dt=datetime.datetime(2025, 3, 17, 5, 28, 16, 958724, tzinfo=datetime.timezone.utc) message='Message 1'
print(log2) #dt=datetime.datetime(2025, 3, 17, 5, 28, 16, 960002, tzinfo=datetime.timezone.utc) message='Message 2'



