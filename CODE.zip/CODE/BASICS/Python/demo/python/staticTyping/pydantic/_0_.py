from pydantic import BaseModel, ValidationError

"""
    Pydantic - Pydantic is a Python library that allows you to define robust, type-safe, and self-documenting models 
     using Python type hints. It's often used for building robust APIs, data validation, and data serialization.

    It provides features like
        1. Data Validation: Validating data against the models definition, ensuring that the data conforms to the 
            expected structure and types.
            
        2. Type Safety: Pydantic ensures that the data is type-safe, preventing from run time errors.
        
        3. Serialisation: It provides built-in support for serialising models to JSON, and can be extended to support 
            other formats.
        
        4. Deserialization: It can deserialize data from JSON(or other objects) into a python object.
        
        
    Pydantic models are defined using Python classes, and they can include features such as:
    
        - Fields: Define the structure of the model using fields, which can have types, default values, and 
            validation rules.
        - Validators: Define custom validation rules for fields using Python functions.
        - Aliases: Define aliases for fields, which can be used to provide alternative names for fields.
        - Config: Define model-wide configuration options, such as the serialization format or the error handling 
            behavior.
    
    
    Pydantic Data Models are simply just python classes with extra functionalities provided by inheritance.
         
"""

"""
    Validating without pydantic
"""


class User:
    def __init__(self, emp_id, name="Jane Doe"):

        if not isinstance(emp_id, int):
            raise TypeError(
                f"Expected id to have type int, instead got {type(id).__name__}"
            )

        if not isinstance(name, str):
            raise TypeError(
                f"Expected name to have type str, but instead got {type(name).__name__}"
            )

        self.emp_id = id
        self.name = name


try:
    user = User(emp_id="123")
except TypeError as e:
    print(e)

"""
    With Pydantic

    We will define our class which will inherit a class called base model and then we can use the base model class and
    declare our variables with type checking
"""


class Person(BaseModel):
    first_name: str = "Jane"
    last_name: str = "Doe"
    age: int = 0

    def __repr__(self) -> str:
        return "{" + f"{self.first_name} {self.last_name} , {self.age}" + "}"


person = Person(
    age="12"
)  # We get static error : Expected type 'int', got 'str' instead, if we use a string

print(
    person.age
)  # But we can also run the code and pydantic will try to convert the string to an integer if
# possible and assign it to the instance variable

print(type(person.age))  # <class 'int'>

"""
    This mean that if an instance of a class is created then the variables are guaranteed to be the types that they are 
    allowed to be only and no other type can pollute them.
    
    If there is any mismatch pydantic will give you a compile time error and a run time error as well
    
    And also pydantic will not by default serialise objects to strings because objects always have a string representation.
    Because converting anything you give into a string is a very broad representation and can lead to very serious bugs.
    
    So saying first_name = 100 will not work at all
"""

try:
    p = Person(first_name=100, age="junk")
except ValidationError as ve:
    print(ve)
    """ 
        
    !!!!Pydantic does not stop at the first validation so that it can find all the errors that have to be checked for us
    
        2 validation errors for Person
        first_name
          Input should be a valid string [type=string_type, input_value=100, input_type=int]
        age
          Input should be a valid integer, unable to parse string as an integer [type=int_parsing, input_value='junk', input_type=str]
    """

"""
    You can modify the attributes using the access operator('.').
    This has to be very careful as even though pydantic does validate data that is being deserialize, passed through a constructor etc...,;
    it does not validate data passed though the dot notation
"""

# SO we can do this
p: Person = Person(age=25)
print(p)
p.first_name = "Jack"
print(p)

# We have to be careful about cases like this
p.age = "junk"
print(p)  # first_name='Jack' last_name='Doe' age='junk'
"""
    It gives compile time warning but not throw an error by default properties
"""

# We can get the list of exceptions as data using special methods provided by pydantic validation error exception
exception_obj: TypeError
try:
    p = Person(first_name=100, age="junk")
except ValidationError as ve:
    exception_obj = ve

print("\n---Exceptions List---")
print(exception_obj.errors())

# We can also create a JSON object using the json() Method
exception_obj.json()


"""
    Deserializing Data using dictionaries and json
"""
data = {"first_name": "Mike", "last_name": "Hunter", "age": 34}

data_json = """
    {
    "first_name" : "Mike",
    "last_name" : "Hunter",
    "age" : 34
    }
"""
person_2 = Person.model_validate(data)
print("\n\n", person_2)

person_3 = Person.model_validate_json(data_json)
print("\n\n", person_3)


