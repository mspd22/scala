import logging

"""
    We can change the attributes of the logger.basic to change the format of the logging
    
    Use the format keyword
"""
logging.basicConfig(filename='logs/logger.log',level=logging.DEBUG,
        format='%(asctime)s:%(levelname)s:%(message)s')

def add(x, y):
    """Adds two numbers"""
    return x + y

def subtract(x, y):
    """Subtracts two numbers"""
    return x - y

def multiple(x, y):
    """Multiplies two numbers"""
    return x * y

def divide(x, y):
    """Divides two numbers"""
    return x + y

num1 = 5
num2 = 10

print("--PRINT STATEMENTS--")
add_result = add(num1,num2)
print('ADD: {} + {} = {}'.format(num1,num2,add_result))

sub_result = subtract(num1,num2)
print('SUBTRACT: {} - {} = {}'.format(num1,num2,sub_result))

mul_result = multiple(num1,num2)
print('MULTIPLY: {} * {} = {}'.format(num1,num2,mul_result))

div_result = divide(num1,num2)
print('DIVIDE: {} / {} = {}'.format(num1,num2,div_result))
print("\n")

"""
    But this is not better then logging
    
    we can use logging using the logging standard library

    Five standard different log levels
        1. DEBUG : Detailed information, typically of interest only when diagnosing problems.
        2. INFO : Confirmation that things are working as expected.
        3. WARNING : An indication that something unexpected happened, or indicative of some problem in the near future(e.g. 'disk space low'). The software is still working as expected.
        4. ERROR : Due to a more serious problem, the software has not been able to perform some functions.
        5. CRITICAL : A serious error, indicating that the program itself may be unable to continue running.
        
    The default level of logging is warning or above, so it will capture warning, error and critical statements only.
    
"""


add_result = add(num1,num2)
logging.debug('ADD: {} + {} = {}'.format(num1,num2,add_result))

sub_result = subtract(num1,num2)
logging.debug('SUBTRACT: {} - {} = {}'.format(num1,num2,sub_result))

mul_result = multiple(num1,num2)
logging.debug('MULTIPLY: {} * {} = {}'.format(num1,num2,mul_result))

div_result = divide(num1,num2)
logging.debug('DIVIDE: {} / {} = {}'.format(num1,num2,div_result))

"""
    EXAMPLE
"""

"""
    Advanced Topics - Loggers, Handlers and Formatters
"""

# Example :2025-03-11 14:13:14,801:root:INFO:Created Employee John-Doe
# in the above example the `root` specifies the logger we are using, we are using the default one because we have not
# specified any. This is not a bad practise, but it is better to use separate loggers for each logging purpose

# The first logger is considered if no logger name is specified for the entire logging system. i.e. the configurations
# defined in the first config method will be used for the entire time

""" Getting our own logger"""

logger = logging.getLogger(__name__) # -> __main__
logger.setLevel(logging.INFO)

# print(logger)

"""
    File Handler -> Specific the file we want to log to
"""

file_handler = logging.FileHandler('logs/employee.log')


"""Now we need to add the formatting to our file handler and not our logger"""
formatter = logging.Formatter('%(asctime)s:%(name)s:%(levelname)s:%(message)s')
file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

class Employee:

    def __init__(self,first_name,last_name,pay):
        self.first_name = first_name
        self.last_name = last_name
        self.email = self.get_email
        self.pay = pay

        print("Created Employee {}-{}".format(self.first_name,self.last_name))
        logger.info("Created Employee {}-{}".format(self.first_name,self.last_name))

    @property
    def full_name(self):
        return self.first_name + " " + self.last_name

    @property
    def get_email(self):
        return self.first_name + "." + self.last_name + "@gmail.com"

emp1 = Employee("Corey","Schafer",100000)
emp2 = Employee("John","Doe",100000)

