
"""
    Requests Library -> Allows us to easily make HTTP requests for getting data from websites

    Http for Humans

    Only for getting data but to parse the information then use beautiful soup or Requests.HTML
"""

import requests

req = requests.get("https://xkcd.com/353/")
print(req) # <Response [200]>

# Get all the attributes and methods of a request
print(dir(req))

"""
    Print the contents of the webpage
"""

print("\n\n---Printing The Html content---")
print(req.text)

"""Writing images to file using byte reads"""

img = requests.get("https://xkcd.com/comics/python.png")
with open('logs/image_0.png', 'wb') as file:
    file.write(img.content)


"""
    To check the status code of a response
"""
print(img.status_code) # 200
print(img.ok)

"""Get more information"""
print("\n\n---Getting more information about the response---")
print(img.headers)

"""
    Using HTTPBIN to test requests
    
    You can just pass url parameters directly to the request method but beautiful soup gives me the ability to create a
    dictionary to represent them
"""

url_parameter = {'page' : 2, "count" : 25}
# http = requests.get("https://httpbin.org/get?page=2&count=25") -> Error prone
http_get = requests.get("https://httpbin.org/get", params=url_parameter)

print(http_get.text)

print(http_get.url)

"""
    We can also post data to the webpages using the post method
"""

post_data = {"UserName" : "John", "Password" : "******"}
http_post = requests.post("https://httpbin.org/post",data=post_data)

print(http_post.text)

# We can also get the json object like a dictionary
