
"""
    Beautiful Soup - Web Scrapper

    Web Scrapping is the process of parsing through websites and getting the information you want.

    Requests is used for sending requests

    We also need a parser
        There are different types of parsers available and there are some differences between them. These differences are
        shown when trying to parse incomplete or error-prone HTML but they most work the same when parsing through perfect HTML.

    Different Parsers will fill out missing info differently. We will need the LXML parser here.
"""

from bs4 import BeautifulSoup
import requests

with open('../include/sample.html') as html_file :
    soup = BeautifulSoup(html_file, 'lxml')
    # This is a BeautifulSoup object

print(soup)

# Formatting
print("\n\n---FORMATTED FILE---")
print(soup.prettify())


"""
    We can access the information inside like accessing  attributes
    
    Accessing a tag will give us the first tag in that page
    
    We can use the find method to search for specific classes or id
    
    We can get a list of all the instances of a particular tag using the find_all method
"""

match = soup.title
print(match) # <title>An example Html Page</title>
print(match.text) # An example Html Page

print("\n\nThe First Div Tag on the page.")
print(soup.div.prettify())

print("\n\n---Finding the footer---")
match = soup.find('div',class_ = 'footer')
print(match.prettify())

# Getting the headline using nested access
headline = soup.find('div',class_ = "article").h2.a.text
print(headline) # Article 1 Headline

print("\n\n---Using Find ALL---")
for article in soup.find_all('div',class_="article"):
    print(article.prettify())
    print()


""" Using the requests library to parse a webpage"""
source = requests.get("https://coreyms.com").text
soup = BeautifulSoup(source, 'lxml')

with open('logs/htmlExample.txt','w') as file:
    file.write(soup.prettify())

print("\n\n---Getting an article from the website---")
print(soup.find('div', class_="container").prettify())

headline = soup.find('div',class_ = 'container').h1.text
print("The Headline of the page is : ",headline)

print("\n\n---Getting the video iframe---")
vid_src = soup.find('div',class_= 'container').a
print(vid_src)

"""
    To the value of an attribute of a Tag you can access them like a dictionary
"""

print("\n---Just the YT Link :",end=" ")
print(vid_src['href'])

# Getting just the channel name from here
print(vid_src['href'].split('/')[-1])