
"""
    Context Managers -> Help us to properly manage resources so that we can specify exactly what to set up and tear down

    Example Using `with` for file operations

    CM manage so many things for us automatically

    We can customise our own CM by using
        1. A class
        2. A function with a decorator
"""
from os import listdir
from typing import final

"""
    An example CM for opening and automatically closing a file
"""

"""Class"""
class Open_File():

    def __init__(self, filename, mode):
        self.filename = filename
        self.mode =mode

    def __enter__(self):
        self.file = open(self.filename, self.mode)
        return self.file

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.file.close()
        # The remaining arguments for when exceptions happen

with Open_File("logs/TestCm.txt",'w') as file:
    file.write("Testing")

print(file.closed)

"""Function"""

from contextlib import contextmanager

@contextmanager
def open_file(file_name,mode):
    try:
        f = open(file_name, mode)
        yield f
    finally :
        f.close()

with open_file("logs/testCm.txt",'a') as file:
    file.write("\nAnother test")

print(file.closed)

"""
    ANOTHER PRACTICAL EXAMPLE
    
    
"""
import os

@contextmanager
def change_directory(destination):

    try:
        cwd = os.getcwd()
        os.chdir(destination)
        yield
    finally:
        os.chdir(cwd)

with change_directory("./logs/"):
    print(listdir())

"""
    This has created a context manager which takes a path to a directory and performs some function there and
    returns control back to the calling directory
"""
