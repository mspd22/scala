"""
    - A list is iterable, but it is not an iterator

    Iterable -> Something that can be looped over

    For an object to be iterable it must contain a special method called the __iter__ method
"""
nums = [1,2,3]
for num in nums :
    print(num)

# To see if the list class has a __iter__ method
print(dir(list))

"""
    Iterator -> An object with a state so it remembers where it is during iteration and it also knows how to 
    get its next value
    
    next() -> method is used to generate the next value of an iterable
    __next__() -> This method is present in an iterator
    
    But using the __iter__ method on our list we will get an iterator which we can iterate over
"""

my_list_iterator = nums.__iter__()
# also same -> my_list_iterator = iter(nums)
print("Methods available to a list iterator\n",dir(my_list_iterator))
"""
    This iterable also contains a __iter__ method but this iter method returns the same iterable object but instead of 
    creating an iterable object
"""

print(next(my_list_iterator))
print(next(my_list_iterator))
print(next(my_list_iterator))
# print(next(my_list_iterator))  -> StopIteration Error
"""
    AN ITERABLE REMEMBERS ITS LAST STATE!!!
    
    And also an iterator cannot be reused once it goes forward it cannot go back to a previous state
    
"""

my_list_iterator = nums.__iter__()
print("\nWhile Loop")
while True:
    try:
        item = next(my_list_iterator)
        print(item)
    except StopIteration:
        break

class MyRange:

    def __init__(self,start=0,end=0,step=1):
        self.value = start
        self.end = end
        self.step = step


    def __iter__(self):
        return self # Since an iterator must have both next and iter methods

    def __next__(self):
        if self.value >= self.end :
            raise StopIteration

        current = self.value
        self.value += self.step
        return current

print("\nCustom Range Function")
nums = MyRange(1,100,5)
print(next(nums))
print(next(nums))
print(next(nums))
print(next(nums))
print(next(nums))

import itertools

counter =itertools.count()