

"""
    Dictionaries -> Data Structures which hold key : value pairs
"""
from operator import itemgetter

myDict = {
    'name' : "John",
    'age' : 25,
    'courses' : ['M','P','C']
}

print(myDict['name'])
print(myDict['age'])
print(myDict['courses'])

# If we try to access an element which does not exist then we get a key error
# We can use the get method to get none as the result when the key specified is not present in the dictionary

print(myDict.get('Phone'))
print(myDict.get('Phone',"Phone not present"))

myDict['Phone'] = '555-555-555'
print(myDict)

myDict['name'] = "Doe"
print(myDict['name'])

"""
    The Update Method -> Takes a Dictionary as the input and then updates the input dictionary based on the keys present
"""

myDict.update({'name' : "John", 'age' : 30})
print(myDict)

"""
    Deleting an element -> Del keyword and pop method
"""

del myDict['Phone']
print(myDict)

age = myDict.pop('age')
print(myDict)


"""
Iterating through a dictionary
"""

print(len(myDict))
print(myDict.keys())
print(myDict.values())
print(myDict.items())

for key,value in myDict.items() : print(f"{key} : {value}")

del myDict


