"""
    Lists -> An array of data. Can be of different data types
"""

nums = [i for i in range(1,16)]
print(nums)

"""
    Indexing and slicing same as Strings
"""
print(len(nums))

"""
    Append -> Adds an element to the end of the list
    Insert -> Adds an element to the specified index
    extend -> Takes an iterable and appends to the list
    remove -> Removes an element based on the key provided to it
    pop -> Removes an element and returns it, by default pops last element
"""
nums.append(16)
nums.insert(0,0)

"""
    We can have a list of list
"""

numExtra = [i for i in range(15,21)]
print(numExtra)

nums.extend(numExtra)
print(nums)

nums.remove(0)
print(nums)

nums.pop(-1)
print(nums)

"""
    Sorting Lists
    1. sort method -> Sorts the  list inplace
    2. sorted function -> returns a sorted version of the list provided
"""

nums.sort(reverse=True)
print(nums)

print(sorted(nums))

"""
    Some Built-in functions
    min
    max
    sum
    etc..,
"""

print(min(nums))
print(max(nums))
print(sum(nums))

"""
    Finding Elements in a List
    
    1. index -> Searches for a element and returns the index it is present at
        Will provide value error if element is not present in the list
        
    2. in Operator -> Returns a boolean to represent if an element is present in a list
"""

print(nums.index(10))

"""
    Traversing Iterables
"""

for i in nums:
    print(i,sep="\t",end=" ")


for ele,index in enumerate(nums):
    print(f"{index} : {ele }")

"""
    Join Method -> Returns a string of the list combined using the specified join parameter
"""

nums_str = '-'.join([str(i) for i in nums])
print(nums_str)


"""
    Tuples -> Immutable Data structure
    
    If we have two lists which are the same but when we change one list the change is also reflected in the other list
    then this is a problem and we can stop this using tuples
"""

t1 = tuple(i for i in range(1,11))
print(t1)
# We cannot append or remove any element since it is immutable

"""
    NamedTuple -> import the named tuple module
"""
from collections import namedtuple

color = (55,155,255) # RGB values but these are hard to read and understand
# we can use a dict
color_dict = {"red" : 55, "green" : 155, " blue" : 255}
print(color_dict['red'])

Color_template = namedtuple("color",['red','green','blue'])
color_nt = Color_template(55,155,255)

print(color_nt.red)
print(color_nt[1])

# Named Tuples are the combination of tuple and a dict
""" 
    Sets -> Unordered unique list
    
    They do not care about order and are mostly used for checking whether a value is present in a DS or not
"""
s1 = {i for i in range(1,10)}
print(s1)

"""
    Sets provide some very useful built-in functions
"""
cs_courses = {"History", "Math", "Physics", "CompSci"}
art_courses = {"History", "Math", "Art", "Design"}

print(cs_courses.intersection(art_courses))
print(cs_courses.difference(art_courses))
print(cs_courses.union(art_courses))

"""
    The sorted method is very versatile as it can sort any iterable you pass to it
"""

# Imagine you want to sort the list based on the absolute values of the elements present in the list.
li = [-6,-5,-4,1,2,3]
s_i = sorted(li) # will not work
print(s_i)

s_i = sorted(li,key=abs)
print(s_i)

class Employee():
    def __init__(self,name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary

    def __repr__(self):
        return '({}, {}, ${})'.format(self.name,self.age,self.salary)

e1 = Employee("Carl", 37, 70000)
e2 = Employee("Sarah", 29, 80000)
e3 = Employee("John", 43, 90000)

employees = [e1,e2,e3]
print(employees)

def e_sort(emp):
    return emp.name

# Custom Functions for sorting
print(sorted(employees,key=e_sort,reverse = True))

# or using lambdas
print(sorted(employees,key=lambda e : e.name))
