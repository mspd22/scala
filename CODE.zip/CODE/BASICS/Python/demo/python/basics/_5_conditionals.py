"""
    SAME AS all other languages

    if -> Check a condition and the block of code is only executed if the condition is True

    elif -> Add another condition

    else -> The last resort
"""

# Comparisons
# Equal ==
# Not Equal !=
# Greater than >
# Less than <
# Greater than or equal to >=
# Less than or equal to >=
# Object Identity is

"""
    When making the condition check the order in which the condition are being checked
    
    Short Circuit -> False first
        
    Boolean Operator and their Logical Equivalent
    
    && -> and
    || -> or
    ! -> not
"""

a = [1,2,3]
b = [1,2,3]

print(a == b)
print(a is b)
print(id(a))
print(id(b))

c = a
print(a == c)
print(a is c)
print(id(c))
print(id(c))


"""
    What Python Actually evaluates to true or false
    
    False Values:
        1. False
        2. None
        3. Zero of any numeric type
        4. Any empty sequence. For example, '', (), [] 
        5. Any Empty Mapping like {}
"""

"""
    Else statement with a loop
    
    Should have been called the 'noBreak' instead -> Only executes if the loop completed its execution 
    without being broken in the middle
"""

myList = [1,2,3,4,5]

for i in myList:
    print(i)
else :
    print("Hit the else statement")

for i in myList:
    print(i)

    if i == 3: break
else :
    print("Hit the else statement")