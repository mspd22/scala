
"""
    Strings hold a list of characters or text data.
"""

message = "Hello World"
print(message)

# We can use alternative quotes or escape characters to print and store quotes
ex1 = "It's a ball"
ex2 = 'It\'s a ball'

print(ex1)
print(ex2)

print("""We can use triple quote of both single and double type to specify text data 
that goes over multiple lines""")

"""
    Indexing a String and slicing
"""

print(f"Length of the message : {len(message)}")
print(f"Accessing the first character of a string with [] operator : {message[0]}")

# While slicing the first index is inclusive but the second index is exclusive
print(f"Slicing a string or a iterable can be by using the [] and : operators like : {message[0 : 5]}")

print(f"--Slicing with just one index specified--")
print(message[4:])
print(message[:8])

print("Negative Indexing")
print(message[-1]) # Starts from -1 at the last character
print(message[-4:])

print("Steps")
print(message[0::2]) #steps specifies how many characters to read after
print(message[-1 : : -2]) # Reverse Slicing

"""
    Some Inbuilt String methods
"""

print(message.lower())
print(message.upper())
print(message.count('Hello'))
print(message.count('l'))
print(message.find('World'))
print(message.find('z'))

"""
    Replacing a String
"""

print(message.replace('World','Universe'))

"""
    WE CAN CONCATENATE STRINGS USING THE `+` OPERATOR   
"""

print("WE CAN CONCATENATE STRINGS USING THE `+` OPERATOR ")
s1 = "This is an"
s2 = " example"

res = s1 + s2
print(res)

"""
    STRING FORMATTING
"""

greeting = "Hello"
name = "John Doe"
print("\n\nFORMATTED STRINGS")
print("{} {}. Welcome!.".format(greeting,name))


"""f-strings"""
print("F-STRINGS")
print(f"{greeting}, {name.upper()}!. Welcome")

"""
    To get more documentation and help we can use the DIR method and HELP method
"""

print(dir(name))

# print(help(str))

print(help(str.lower))