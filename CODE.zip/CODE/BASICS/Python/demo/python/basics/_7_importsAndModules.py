from demo.python.include import myModule
# We can also do this
# from demo.python.include.myModule import find_index as f_i

"""
    When we import a module it checks multiple locations and the locations it checks are within a list called the sys.path
"""

"""
    We will have access to all the variables defined in the module
"""
print(myModule.test)

courses = ['History','Art','Math']

index = myModule.find_index(courses,'Art')
print(index)

import sys

for i in sys.path :
    print(i)

"""
    Changing the locations where the python interpreter tries to find the modules. 
    
        1. We can add paths to the sys.path by using the append or insert methods since the
    sys.path is just a list
    
        2. The second place where the system tries to find the paths is the python path environment
        
        3. Then the standard library modules.
"""

# 1. sys.path.append('Path')

# 2.
# export PATH="Path" in .bash_profile file

# An example of  the standard library Module
import random

print(random.random())
print(random.choice(courses))

# Another useful standard library is math
# Another useful standard library is datetime and the calendar module
# Another useful standard library is os

"""
    TO know where the standard library files are located, you can use the __file__ method
"""

print(random.__file__)
# /Library/Frameworks/Python.framework/Versions/3.13/lib/python3.13/random.py
