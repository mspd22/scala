
num = 5

num = num + 1
print(num)

""" Augmented Assignment """
num +=1
print(num)

num *= 5
print(num)

num /= 2
print(num)

num **= 2
print(num)

num %= 3
print(num)

"""
    FLOOR DIVISION
"""
print(5 // 2)

"""
    SOME BUILT IN MATH FUNCTIONS
"""
print("\n\nSOME BUILT IN MATH FUNCTIONS")
x = 3.14
y = -4
z = 5

print(round(x)) # Rounds a number to its nearest integer
print(abs(y)) # The distance of the number from the origin
print(pow(x,z)) # The exponential function
print(max(x,y,z)) # Finds the max
print(min(x,y,z)) # Finds the min

import math

print("\n\nTHE MATH LIBRARY PROVIDES A LOT OF VARIABLES AND METHODS FOR MATHEMATICS OPERATIONS")
print(f"THE MATH CONSTANT PI : {math.pi}")
print(f"THE MATH CONSTANT e : {math.e}")
print(f"The square of a number is given by sqrt : {math.sqrt(x)}")
print(math.ceil(x))
print(math.floor(x))

"""
    The order of execution of the arthematic expressions follows the order of precedence which is predefined and if 
    precedence of two operators are the same then it checks the associativity of the operators and executes them in that order
"""