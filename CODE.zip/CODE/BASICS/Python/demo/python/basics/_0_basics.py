"""
    Python is a high level interpreted, general purpose language.
    It's design phylo
"""

"""
    Printing is done by using the print statement
"""
print("Hello World!")

"""
    Variables - A container for a value(string, integer, float, double, boolean) -> Basic Variable types
        
        It is a reference to a memory location that contains some data we can read/write to when needed
"""

# Strings
first_name = "John"
last_name = "Doe"

print("My name is " + first_name + " " + last_name)
print(f"My name is {first_name +" "+ last_name}") # f-strings or formatted strings

#integers
age = 25
num_of_students = 30

print(f"I am {age} years old")
print(f"Your class has {num_of_students} Students in total.")

# float
price = 10.99
gpa = 8.99
print("The price is {}.".format(price))
print(f"You CGPA is {gpa}")

# boolean
is_student = True
print("You are a student : " + str(is_student ))

# You can get the type of variable using the type method
print("\nGETTING THE DATA TYPES")
print(type(first_name))
print(type(age))
print(type(price))
print(type(is_student))

print("\nTYPE CASTING")
"""
    We can convert variables of one type into variables of another type.
    But it is not always possible and some information about the data maybe lost due to insufficient memory
"""

newAge = int(gpa)
print(f"Your new Integer GPA is {newAge}")
print(type(newAge))

newStr = str(age)
print(type(newStr))
print(newStr + "1") # Adding two strings

""" A boolean will always give true unless we type cast a empty data type"""


"""
    Taking Input -> Using the input() method
    
    !!! We take all the input as a string, so we need to type cast it to the required data type before we use it
"""

name = input("\nEnter your Name : ")
age = int(input("Enter your Age : "))
print(f"\nHello {name}")
print("Happy Birthday")
print(f"You are {age} years Old!")


"""
    Looping
"""

for i in range(1,10) :

    print(i)
    if i == 4 :
        break

i = 0
while i < 10:
    print(i)
    if i == 5 : break