"""
    Functions -> Instructions packaged together to perform a specific Operator

    A black box -> ONlY focus on the input and the returned value
"""

def func() :
    print("THIS IS THE FUNC FUNCTION")
    # pass # WE will leave it empty for now but do not throw out any errors for now

print(func)
print(func())

# DRY

"""
    Default Variables
"""
def func1(greeting,name = "You") :
    print(f"{greeting} {name}")

func1("Hello")
func1("Hello","John")

# !!! YOUR REQUIRED POSITIONAL ARGUMENTS HAVE TO COME BEFORE KEYWORD ARGUMENTS

def student_info(*args, **kwargs):
    print(args)
    print(kwargs)

student_info()

"""
    Lambda Functions - An anonymous function with no name which can be used in the same way as an other function.
    
    lambda functions are made to be passed to be passed to higher order functions
"""

def add(x,y):
    return x + y

print(add(5,4)) # -> 9

# Now the same can be done using a lambda function like this
l_add = lambda x,y : x + y
print(l_add(23,2)) # 25

""" Traditionally we use them as this"""
print((lambda x,y:x+y)(4,5))

nums = [i for i in range(1,500)]

print(filter(lambda x : x%17==0,nums))
print(list(filter(lambda x: x%17==0, nums)))

# HOF
def my_map(my_func, my_iter):

    res = []
    for item in my_iter:
        new_item = my_func(item)
        res.append(new_item)

    return res

print(my_map(lambda x : x%3==0,nums))

