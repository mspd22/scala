import os
import csv
from webbrowser import open_new

includePath = "../../python/include"

"""
    CSV module has many good methods and operators which will help us in parsing csv files easily
"""

print("\n--USING THE CSV READER AND WRITER--")
with open(os.path.join(includePath,"names.csv"),'r') as file :
    csv_reader = csv.reader(file)

    """
        While reading and writing on a csv file, the delimiter used is very important.
        If we use the wrong delimiter then the reader or writer will not parse the csv file correctly
    """
    print(csv_reader) # An object in memory containing all the lines of the csv file
    csv_reader = list(csv_reader)
    """ The first line will be giving us the attribute names"""
    for line in csv_reader:
        print(line)

    with open(os.path.join(includePath,"newNames.csv"),'w') as writeFile :
        csv_write = csv.writer(writeFile, delimiter='\t')

        for line in csv_reader :
            csv_write.writerow(line)

"""
    Dictionary Reader And Writer
"""

print("\n\n")

print("--USING THE DICTIONARY READER AND WRITER--\n")
with open(os.path.join(includePath,"names.csv"),'r') as file :

    csv_reader = csv.DictReader(file)
    csv_reader = list(csv_reader)
    """
        A generator of an ordered dictionary with the keys being the attributes
    """

    fieldNames = csv_reader[0].keys()
    print("THE FIELD NAMES ARE REQUIRED FOR THE DICTIONARY WRITER : ",end = "\t")
    print(fieldNames)
    for line in csv_reader:
        print(line)

    # with open(os.path.join(includePath, "newNames.csv"), 'w') as writeFile:
    #     csv_write = csv.DictWriter(writeFile, fieldnames=fieldNames,delimiter='\t')
    #
    #     for line in csv_reader:
    #         csv_write.writerow(line)
    """
        Easy to modify the write data
    """
    fieldNames = [i for i in fieldNames][0:2]
    print("\nNEW FIELD NAME : ",fieldNames)

    with open(os.path.join(includePath, "newNames.csv"), 'w') as writeFile:
        csv_write = csv.DictWriter(writeFile, fieldnames=fieldNames,delimiter='\t')
        csv_write.writeheader()
        for line in csv_reader:
            del line['email']
            csv_write.writerow(line)