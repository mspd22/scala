
"""
    LEGB Scope -> Local Enclosing Global Built-in
"""
x = "Global X"
z = "Global Z"

def test():
    y = "Local y"
    x = "Local x"

    global z
    z = "Local Z"
    print("Within Test Function")
    print(z)
    print(y)
    print(x) # Will check the function to find x, if not found then it will check the enclosing scope for x and doesn't find it
    # then it will go to the global scope

    """
        Here the x is not changed in the global scope due to the actions of the variable in the local scope
        
           - It is because of the reason that the x variable in the local scope takes precedence and is treated as a separate variable,
            it is not the same as the global x variable.
            
           - TO make it the same we need to use the global keyword to explicitly tell the compiler that the variable x is the same 
            as that of the global x
        
        Function Arguments behave the same except for that we cannot define them as global inside the function as arguments and global 
        variables cannot be defined twice
    """

print("In main")
test()
# print(y) -> Will not work in reverse order it will only grow in the scope not shrink
print(x)
print(z)

"""
    Built-in Scope
"""

print(min([22,21,32,31,23,123,123,312,1585]))

import builtins
print(dir(builtins))

"""
    WE CAN OVERWRITE THE BUILT-IN FUNCTION AND VARIABLES SO TRY NOT TO DO THAT EVEN THOUGH PYTHON ALLOWS IT
    
    And the overwritten functions will be present in the global scope hence they will be considered before built-in scope
"""

"""
    ENCLOSING SCOPE -> In Nested Functions(Closures)
    
    The compiler will check in the follwing order as defined by L ->  E ->  G ->  B
    
        - The non-local keyword works as the global keyword does for enclosing variables
"""
def outer():

    c = "Outer c"
    i = "Outer I"
    o = "Outer O"
    def inner():

        nonlocal c
        c = "Inner C"
        o = "Inner O"
        print(o)
        print(i)
        print(c)

    inner()
    print(o)
    print(i)
    print(c)

outer()