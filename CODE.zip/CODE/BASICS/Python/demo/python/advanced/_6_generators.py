
# def square_numbers(nums):
#
#     result = []
#     for i in nums:
#         result.append(i**2)
#     return result

# my_nums => [1,4,9,16,25,36] if we use lists
"""
    Generator functions -> Using Yield keyword

    Generator items are not stored in memory until used so better performance -> Like lazy variables in SCALA
"""

def square_numbers(nums):
    for i in nums:
        yield i*i

my_nums = square_numbers([1,2,3,4,5,6]) # -> This is a Generator Object
print(my_nums) # <generator object square_numbers at 0x1010a3510>

print(next(my_nums))
print(next(my_nums))
print(next(my_nums))
print(next(my_nums))
print(next(my_nums))
print(next(my_nums))
# print(next(my_nums)) -> Will throw the StopIteration ERROR SINCE IT RUN OUT OF GENERATOR ITEMS



# We can also use a list comprehension
my_nums = [i*i for i in range(1,7)] # -> List comprehension
# my_nums = (i*i for i in range(1,7)) -> Generator Comprehension

for num in my_nums :
    print(num,end = "\t")