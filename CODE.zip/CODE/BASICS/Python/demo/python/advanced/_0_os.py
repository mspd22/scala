import os
from compileall import compile_dir

print(dir(os))

# Get the current working directory
print(os.getcwd())

# Change the current Directory
os.chdir("/Users/s0m12qs/Desktop")
print(os.getcwd())

# List all files and folders in the cwd
print(os.listdir())

# Add a folder to the cwd

# Method 1
os.mkdir('/Users/s0m12qs/Desktop/temp')

# Method 2
os.makedirs('/Users/s0m12qs/Desktop/subDir/temp') # Preferred

"""
    The difference between mkDir and makeDirs is that mkDir cannot create any sub dir or child directories
    
    But makeDirs can take a path with sub Directories and create them all as per the request 
    
    For deleting the directories we have the same with rmDir and removeDirs
"""

os.rmdir('/Users/s0m12qs/Desktop/temp') # Preferred

os.removedirs('/Users/s0m12qs/Desktop/subDir/temp')

# TO rename a file we can use the rename method
# os.rename('oldFile','newFile')

os.chdir("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/Python/demo/python/advanced")
# Get all the information about a file
print(os.stat("_0_os.py"))
"""
os.stat_result(st_mode=33188, st_ino=5960094, st_dev=16777233, st_nlink=1, st_uid=502, st_gid=20, 
st_size=1050,st_atime=1741582810, st_mtime=1741582810, st_ctime=1741582810)
"""

from _datetime import datetime
# To get the moment when a file was modified
print(datetime.fromtimestamp(os.stat('_0_os.py').st_mtime))

"""
    TO traverse the directory tree and print all the files and folders in the path
    
    The walk method is a generator that yields a tuple of size 3 namely
        1. The path of the directory
        2. The directories within that path
        3. The files within that path
    
    SO basically it performs a DFS traversal from the specified directory and provides a generator containing a sequence of tuples
     that specifies the current directory, a list containing the directories in the cwd and a list containing the files in the cwd.
"""

for dirPath, dirName, fileNames in os.walk("/Users/s0m12qs/Desktop") :
    print('Current Path : ', dirPath)
    print('Directories : ', dirName)
    print('Files : ',fileNames)
    print()

"""
    We can get environment variables using the environ method
"""

print(os.environ)

"""
    We can also use the os.path module to combine two paths
"""
# os.path.join("Path1","Path2")

print("\n\n",os.path.basename("/a/d/a/d/dw/w/ddw/d/dsa/test.txt"))
print(os.path.dirname("/a/d/a/d/dw/w/ddw/d/dsa/test.txt"))
print(os.path.split("/a/d/a/d/dw/w/ddw/d/dsa/test.txt"))

# Check if a file or exists
print(os.path.exists("/a/d/a/d/dw/w/ddw/d/dsa/test.txt"))

# Check if a path is a file or a directory
print(os.path.isfile("/a/d/a/d/dw/w/ddw/d/dsa/test.txt"))
print(os.path.isdir("/a/d/a/d/dw/w/ddw/d/dsa/test.txt"))

# Check the extension
print(os.path.splitext("/a/d/a/d/dw/w/ddw/d/dsa/test.txt"))