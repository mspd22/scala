"""
    The general syntax of a try block looks like
    try :
        pass
    except :
        pass
    else :
        pass
    finally:
        pass

    Put more specific exceptions at the top and the general exceptions at the bottom.
"""

try:
    # f = open("testFile.txt")
# except Exception: # But this is too general
#     print("File is not Found")
    print("If no exception is caught then the else block is executed.")

except FileNotFoundError:
    print("The file is not found")
else :
    print("WILL RUN THE CODE THAT IS SUPPOSED TO RUN IF THE TRY BLOCK DID NOT RAISE AN EXCEPTION")
finally:
    print("THE FINALLY BLOCK WILL EXECUTE NO MATTER WHAT.\nSO IT IS GENERALLY USED FOR GARBAGE COLLECTION")

"""
    We can raise our own exceptions using the raise keyword
"""

try:
    raise Exception
except Exception:
    print("\n\nExceptions, so many")