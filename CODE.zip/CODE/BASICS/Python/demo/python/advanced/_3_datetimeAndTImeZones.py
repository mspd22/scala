import datetime
import pytz

"""
    datetime 
        1. Naive - Easier to work with but don't have enough information to infer about time zones and day light savings time
        2. Aware - Complex but are informed enough to keep track of time zones and day light savings time.
        
"""

"""
    Naive Datetime
"""
d = datetime.date(2016,7,24)
print(d)

tday = datetime.date.today()
print(tday)
print(tday.day)

# weekday -> Monday starts at 0
# isoweekday -> Monday starts at 1

print(tday.weekday())
print(tday.isoweekday())

"""
    Time Delta -> The difference between times
    
    timeDelta = date1 + date2  -> We get a time delta if perform arthematic operations on two times
    date2 = date1 + timeDelta -> We get another date
"""

tdelta = datetime.timedelta(days=7)
print(tday - tdelta) # Time 1 week about

bday = datetime.date(2025,3,5)
print(tday - bday)

"""
    Time -> Hours, Minutes, Seconds, Microseconds
"""

t = datetime.time(9,30,45,10000)
print(t)

"""
    DateTime -> Date and Time combined
"""
dt = datetime.datetime(2016,7,26,12,45,30,100000)
print(dt)
tdelta = datetime.timedelta(days=7,hours=3,minutes=232)
print(dt + tdelta)

# ----------------

dt_now = datetime.datetime.now()
dt_today = datetime.datetime.today()
dt_utcnow = datetime.datetime.utcnow()

print(dt_now)
print(dt_today)
print(dt_utcnow)


"""
    TIME ZONES -> Creating times which are timezone aware
"""
# Method 1
dt = datetime.datetime(2016,7,27,12,30,45,tzinfo=pytz.UTC)
print(dt)

# Method 2
dt = datetime.datetime.now(tz=pytz.UTC)
print(dt)

# SEE all the time zones available
for tz in pytz.all_timezones :
    print(tz)

# CONVERTING NAIVE DATETIME TO AWARE DATETIME
dt_naive = datetime.datetime.now()
print("NAIVE DATE TIME : ",dt_naive)

# we cannot do this
# dt_aware = dt_naive.astimezone(pytz.timezone('US/Eastern'))
# instead we have to do the timezone localise method

temp_dt = pytz.timezone('US/Eastern')
dt_aware = temp_dt.localize(dt_naive)
print("AWARE DATE TIME : ",dt_aware)

"""
    TO print a datetime as a specific format we can use the isoformat() method
"""