nums = [1,2,3,4,5,6,7,8,9,10]
myList = []
for i in nums:
    myList.append(i*i)

print(myList)

"""
    The same can be done by using a list comprehension by writing
"""

print([i*i for i in nums])

"""
    Using Maps and Lambdas
"""

print(list(map(lambda n : n * n,nums)))

# n only if n is even
print([i for i in nums if i%2 ==0])

"""Using filter"""
print(list(filter(lambda x : x % 2 == 0, nums)))

# a letter-number pair for each letter in `abcd` and each number in `1234`
pairList = []
for ch in "abcd":
    for num in (1,2,3,4):
        pairList.append(ch + str(num))

print(pairList)

# Using list comprehension
print([ch + str(num) for ch in "abcd" for num in (1,2,3,4)])


"""
    Dictionary Comprehension
"""

names = ['Bruce','Clark','Barry','Logan','Wade']
heroes = ['Batman','Superman','Flash','Wolverine','Deadpool']

# print(zip(names,heroes))

myDict = {}

for name,hero in zip(names,heroes):
    myDict[name] = hero
print(myDict)

# Using dictionary comprehension
myDict2 = {name : hero for name,hero in zip(names,heroes) if name != 'Barry'}
print(myDict2)

"""
    Set Comprehension
"""
dupli = [1,1,2,3,4,5,5,5,6,7,7,8,8,9,9]
print({n for n in dupli})


"""
    Generator Expression
"""

my_gen = (n*n for n in nums)
print(my_gen)

for i in my_gen:
    print(i )