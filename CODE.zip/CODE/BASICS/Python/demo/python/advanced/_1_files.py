# File objects
import os.path

# Two methods to open and work with files
testFile = '../../python/include/test.txt'

"""
    The open method is used to open file object for reading and writing to files
     It takes two arguments the first is the path to the file and the second is the mode in which we want to open the file in
     a - append
     r - read
     w - write
     r+ - read and write
     etc...,
"""

f = open(testFile,'r')

print(f.name)
print(f.mode)

"""
    We have to explicitly close the file in this method 
"""
f.close()

# Will close the file automatically, implicit cleanup
with open(testFile,'r') as file :
    print(file.name)
    print(file.mode)
    f_contents = file.read()
    print(f_contents)

    file.seek(0)
    print(file.readlines())

    file.seek(0)
    print(file.readline())

    file.seek(0)
    # Iterate over the lines in a files.
    for line in file:
        print(line,end ="")

    # read can take an argument which specifies the amount of characters to be read.
    file.seek(0)
    print(file.read(20))

    # See where the cursor is currently at
    print(file.tell()) # -> Should be 20

print(file.closed)

# print(file.read()) -> Will give an error

with open(os.path.join(os.path.dirname(testFile),'test2.txt'),'r') as file :

    print(file.name)
    file.write("Write 1")
    file.write("Write 1") # Writes to the next cursor position

    file.seek(0)
    file.write("R")

    # line = file.readline()
    # with open(testFile,'w') as innerFile :
    #     for i in line.split(':') :
    #         innerFile.write(i)
    #         innerFile.write("\n")


