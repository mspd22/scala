
"""
    Decorators -> A function which takes another function as an argument, adds some functionality and returns another function,
    without altering the source code of the original function we passed in
"""
from functools import wraps


def outer(msg):
    def inner():
        print(msg)

    return inner


my_func = outer("Hi") # A first class function ( a function which returns or takes a functions as an argument)

my_func()

hi_func = outer("Hi")
bye_func = outer("Bye")

hi_func()
bye_func()

"""
    Instead of printing a message we passed in, what if we executed a message we passed in -> Decorator
    
    This is the simplest decorator
"""
def decorator_function(original_func):

    def wrapper_function(*args,**kwargs):
        print("Wrapper Function Executed this before {}".format(original_func.__name__))
        return original_func(*args,**kwargs) # -> Executes the function and returns the None back so just saying original_func()
        # is also enough if there are no return values

    return wrapper_function

def display():
    print("DISPLAY FUNCTION RAN")

decorated_display = decorator_function(display) # It will return a function state which will access to all the state arguments and variables

decorated_display() # -> Executes the original function

"""
    Normally we will use the @decorator_function to represent functions which are getting wrapped
"""

# @decorator_function
# def display():
#     print("DISPLAY FUNCTION RAN")
#
#   Same as saying this |
#                       V
# display = decorator_function(display)
# display()

"""
    What if we want to decorate both the functions with the same decorator - Wrapper function will check for arguments
"""

@decorator_function
def display_info(name, age) :
    print("display info ran with arguments {} and {}".format(name,age))

# now display_info = decorated_function(display_info)
display_info("John",30)

"""
    Class decorators
"""

class DecoratorClass(object):

    def __init__(self,original_func):
        self.original_func = original_func

    def __call__(self,*args, **kwargs):
        print("Call Function Executed this before {}".format(self.original_func.__name__))
        return self.original_func(*args, **kwargs)

"""
    Now we can just say @DecoratorClass just like the function decorator above
"""

"""
    Some Practical Applications
"""
def my_logger(orig_func):
    import logging
    logging.basicConfig(filename='{}.log'.format(orig_func.__name__), level=logging.INFO)

    @wraps(orig_func)
    def wrapper(*args, **kwargs):
        logging.info(
            'Ran with args: {}, and kwargs: {}'.format(args, kwargs))
        return orig_func(*args, **kwargs)

    return wrapper


def my_timer(orig_func):
    import time

    @wraps(orig_func)
    def wrapper(*args, **kwargs):
        t1 = time.time()
        result = orig_func(*args, **kwargs)
        t2 = time.time() - t1
        print('{} ran in: {} sec'.format(orig_func.__name__, t2))
        return result

    return wrapper

import time


@my_logger
@my_timer
def display_info(name, age):
    time.sleep(1)
    print('display_info ran with arguments ({}, {})'.format(name, age))

display_info('Tom', 22)


"""
    Decorator With Arguments
"""

def prefix_decorator(prefix):
    def decorator_function2(original_func):
        def wrapper_func(*args,**kwargs):

            print(prefix,"Executed Before : ",original_func.__name__)
            result = original_func(*args,**kwargs)
            print(prefix,"Executed After : ",original_func.__name__)
            return result

        return wrapper_func
    return decorator_function2

@prefix_decorator('LOG - ')
def display_info2(name, age) :
    print("display info ran with arguments {} and {}".format(name,age))

display_info2("John",20)
display_info2("Mark",25)
