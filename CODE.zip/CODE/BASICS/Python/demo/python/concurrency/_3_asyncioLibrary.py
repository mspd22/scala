
"""
    PROVIDES ASYNC/AWAIT LOOP OPERATIONS FOR ASYNCHRONOUS EXECUTION

    When to use asyncio over threads or multiprocessing to maximise performance and efficiency

        1. For tasks which wait a lot like network requests or reading files
        2. Excels in performing multiple tasks without using much cpu power. -> makes the application more efficient and
        responsive

    Thread -> For when tasks wait a lot but need to share data i.e. IO bound
    MultiProcesses -> For CPU intensive tasks

"""

"""
    Five Key Concepts:
        1. The event loop: 
        
            - The core that manages and distributes the tasks. A central hub with all the tasks waiting to
                executed. Each task takes its turn in the center where it is executed immediately or paused if it is 
                waiting for an IO operation
            
            - When a task awaits it steps aside and another task can begin execution in its place. Making sure tha the
            loop is always efficiently utilized 
            
        2. Coroutines:
"""


import asyncio

# EX 1
"""
'''
    This is supposed to be executed together
'''

async def fetch(delay):
    print("FETCHING DATA....")
    await asyncio.sleep(delay=delay) # Simulate IO operation
    print("Data Fetched....")
    return {"data : " "Some Data"}


# Coroutine Function -> Entry point
async def main():
    print("Start of main coroutine")
    # await keyword is used to await a coroutine and actually allow it get executed

    task = fetch(2) # Not executed here, only the coroutine object is returned
    
    print("\n\n--The coroutine is not executed before it is awaited--\n\n")
    #Await the fetch coroutine, pausing execution of main until fetch_data completes
    result = await task
    print(f"Data Received : {result}")
    print("End of main coroutine ")

"""



"""
    The asyncio application begins wih a run method which takes a coroutine function which returns a coroutine object
    
    Then it will start the event loop by running the coroutine
"""

# EX 2
"""
async def fetch_data(delay, id):
    print("Fetching data... id : ",id)
    await asyncio.sleep(delay)
    print("Data Fetched, id : ",id)
    return {"data" : "Some Data", "id" : id}

async def main():

    task1 = fetch_data(2,1)
    task2 = fetch_data(2,2)

    result1 = await task1
    print(f"Received Result : {result1}")

    result2 = await task2
    print(f"Received Result : {result2}")
    '''
        Here we will not get any synchronous Benefits due to the fact that we will wait until task1 is executed and then 
        only will task2 get executed
    '''
"""

"""
    3. Task:
        - Task is a way to schedule a coroutine to run ASAP and allow us to run multiple coroutines simultaneously.
        
        - With tasks we don't have the issue of waiting for one coroutine to finish before the next one is executed
        
        - As soon as a coroutine is sleeping or waiting for some IO operation, another task is executed.
            (not multiprocessing)
"""
async def fetch_data(id, delay):
    print(f"Coroutine {id} is starting to fetch data")
    await asyncio.sleep(delay)
    return {"data" : f"Sample Data from Coroutine {id}", "id" : id}

# Tasks
"""
async def main():

    '''
        Since we are using asyncio.create_task we need not wait for one coroutine to finish to start the execution of
        another one

        We can control the flow of coroutines by strategically calling the `await` command
    '''
    task1 = asyncio.create_task(fetch_data(1,2))
    task2 = asyncio.create_task(fetch_data(2,3))
    task3 = asyncio.create_task(fetch_data(3,1))

    result1 = await task1
    result2 = await task2
    result3 = await task3

    print(result1,result2,result3)
"""

"""
    Better way to write the above
"""
"""
async def main():
    # Run coroutine concurrently and gather their return values in a list
    results = await asyncio.gather(fetch_data(1,2), fetch_data(2,1), fetch_data(3,3))

    # Process the returns
    for result in results:
        print(f"Received Results : {result}")

    '''
        The disadvantage with gather function is that it does not provide error handling so if one coroutine fails the 
        entire execution is not stopped and the resulting state can become inconsistent
    '''
"""

"""
    Task Groups -> Even better than gather
    
    - Provides with built in error handling, an error in any of the tasks will stop the entire program
"""

"""
async def main():

    tasks = []
    async with asyncio.TaskGroup() as tg:
        for i, sleep_time in enumerate([2,1,3],start=1):
            task = tg.create_task(fetch_data(i,sleep_time))
            tasks.append(task)

    results = [task.result() for task in tasks]

    for result in results:
        print(result)

"""


"""
    4. Futures - low level feature libraries use this

    5. Synchronisation
        a. Locks
        b. semaphore
        c. Event 
"""

shared_resource = 0
lock = asyncio.Lock()
async def modify_shared_resource(semaphore):
    global shared_resource
    # async with semaphore:
    async with lock:
        # Critical Section
        print(f"Shared Resource before modifications : {shared_resource}")
        shared_resource += 1
        await asyncio.sleep(1)
        print(f"Shared Resource After modifications : {shared_resource}")
        # Critical section ends

async def main():

    semaphore = asyncio.Semaphore(2)
    await asyncio.gather(*(modify_shared_resource(semaphore=semaphore) for _ in range(5)))

# main() -> Coroutine object
asyncio.run(main())
# If we try to run main() then we will get an error saying that the coroutine function was never awaited, so asyncio.run

