
"""
    SubProcess Module -> Call external programs/commands
"""

import subprocess

subprocess.run('ls') # List the files and directories in our cwd

# shell = true -> optional argument for mac/linux for single commands
# But for running with multiple commands it is required
# subprocess.run('ls -la') -> Will throw error
subprocess.run('ls -la',shell=True)

""" or """
print("\n\n")
subprocess.run(['ls','-la'])

"""
    To capture it to a variable we cannot just assign it, it will still run the command
"""
p1 = subprocess.run(['ls','-la'])
print(p1)

"""
    We got a completed process object, some methods that are provided by this object are
"""
print(help(p1))

print("The arguments passed to the command : ",p1.args)
print("The return code provided back is : ",p1.returncode)
print("The Standard Out provided back is : ",p1.stdout)

p1_out = subprocess.run(['ls','-la'],capture_output=True) # -> This will capture the stdout to the attribute
print("\n\nNow since the capture is True it will not print to the stdout : \n",p1_out)
print("The arguments passed to the command : ",p1_out.args)
print("The return code provided back is : ",p1_out.returncode)
print("The Standard Out provided back is : ",p1_out.stdout.decode()) # Captured as bytes

# p1_out = subprocess.run(['ls','-la'],capture_output=True,text=True) -> This will get the stdout as text instead of bytes
# The above is same as doing -> p1_out = subprocess.run(['ls','-la'],stdout = subprocess.PIPE,stderr = subprocess.PIPE, text = True)

p_error = subprocess.run(['ls','-la','does_not_exist'],capture_output=True,text=True)
print("THIS WILL NOT GIVE AN ERROR BUT ONLY RETURN A NO-ZERO RETURN CODE : ",p_error.returncode)
print("ERROR : ",p_error.stderr)

# We can make python throw an error using the check=True argument
# WE can also redirect the error to DEVNULL
p_error = subprocess.run(['ls','-la','does_not_exist'],stderr=subprocess.DEVNULL)
print(p_error)

"""
    Chaining Commands
"""
p1 = subprocess.run(['cat','../include/test.txt'],capture_output=True,text=True)
print(p1.stdout)

p2 = subprocess.run(['grep','-n','test'],capture_output=True,text=True,input=p1.stdout)
print(p2.stdout)

"""
    Or you can do 
"""

p_chain = subprocess.run('cat ../include/test.txt | grep -n test',capture_output=True,text=True,shell=True)
print(p_chain.stdout)



