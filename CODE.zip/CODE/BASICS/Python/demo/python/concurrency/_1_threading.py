
"""
    Threading Module -> Running tasks concurrently
"""
import threading
import time
import concurrent.futures

start = time.perf_counter()

def do_something(seconds=1):
    print(f'Sleeping {seconds} second(s)...')
    time.sleep(seconds)
    return f'Done Sleeping...{seconds}'


# do_something(1)
# do_something(1)
# do_something(1)

"""
    This will make it such that our program takes n seconds for executing the do_something Method for n times
    This is called synchronous execution where we are executing the functions one after another.
    
    Time is wasted due to many factors such as IO-Bound Tasks and CPU-Bound Tasks
    
    Threading will show more benefits when we use it for reducing IO-bound Tasks.
    When there are CPU-Bound tasks threading will at best add no benefit but can sometimes slow down the execution due 
    to added overhead costs.
    
    So we will need to use multi-processing when we have CPU-Bound Tasks
"""

##############################################################################

"""
    Threading - old way - without loops
"""
"""
t1 = threading.Thread(target=do_something)
t2 = threading.Thread(target=do_something)

# We have two thread objects
# We have to start them for them to actually do something
t1.start()
t2.start()

# But just starting them will not ensure that the program will execute completely,
# we need to tell the program to wait for the threads to complete first.
t1.join()
t2.join()
# output-> Finished in 1.0 second(s)
"""

"""Threading - old way - loop version"""
"""
threadList = []
for _ in range(10):
    t = threading.Thread(target=do_something)
    t.start()
    threadList.append(t)

for thread in threadList:
    thread.join()
# output -> Finished in 1.01 second(s)

"""


"""Threading With Arguments"""
"""
threadList = []
for _ in range(10):
    t = threading.Thread(target=do_something,args=[1.5])
    t.start()
    threadList.append(t)

for thread in threadList:
    thread.join()
# output -> Finished in 1.51 second(s)
"""

"""
    Threading - New Way -> With a Thread Pool Executor
    
    Submit
"""
"""
with concurrent.futures.ThreadPoolExecutor() as executor:
    
    f1 = executor.submit(do_something, 1)
    f2 = executor.submit(do_something, 1)

    print("F1 Result : ", f1.result())
    print("F1 Result : ", f2.result())
    # The submit method schedules a function to be executed and returns a future object
    # The future object encases the execution of the function and allows to check in on it after it has been scheduled
    # But the submit method is only useful when we want to execute a function once

"""

"""
    Threading - New Way -> With a Thread Pool Executor
    
    Submit - with loops
"""
"""
with concurrent.futures.ThreadPoolExecutor() as executor:

    secs = [5,4,3,2,1]
    results = [executor.submit(do_something,sec) for sec in secs]

    # A method which creates an iterator of the results
    for f in concurrent.futures.as_completed(results):
        print(f.result())

    ''' 
        Here the 5 seconds are started first but the one second is completed first hence we are using separate 
        threads for each function.
    '''
"""

"""
    Threading - New Way -> With a Thread Pool Executor

    Submit - with map
"""

with concurrent.futures.ThreadPoolExecutor() as executor:

    secs = [5,4,3,2,1]
    results = executor.map(do_something,secs)

    for result in results:
        print(result)
    '''
        map will return the result in the order it was started irrespective of which finished first
    '''



finish = time.perf_counter()

print(f'Finished in {round(finish-start, 2)} second(s)')