
"""
    Multi-Processing -> Useful for CPU-Bound Tasks and IO task

    Significantly speed up our program

    In threading we are ont necessarily executing the processes at the same time but with multiprocessing this is
     what we do by utilising multiple processors
"""

import time
import multiprocessing
import concurrent.futures


def do_something(seconds=1):
    print(f'Sleeping {seconds} second(s)...')
    time.sleep(seconds)
    return f'Done Sleeping...{seconds}'


if __name__ == "__main__" :

    start = time.perf_counter()

    """
    p1 = multiprocessing.Process(target=do_something)
    p2 = multiprocessing.Process(target=do_something)
    # Same as threads, we have just created two processes we are yet to start them

    
    # Start the processes
    p1.start()
    p2.start()

    # Join to make sue they complete before the calling process
    p1.join()
    p2.join()
    
    """

    #OLD WAY
    """
    processes = []
    for _ in range(10):
        p = multiprocessing.Process(target=do_something,args=[1.5])
        p.start()
        processes.append(p)

    for process in processes: process.join()

    
    """

    with concurrent.futures.ProcessPoolExecutor() as executor :

        # f1 = executor.submit(do_something,1)
        # f2 = executor.submit(do_something,1)
        #
        # print(f1.result())
        # print(f2.result())

        secs = [5,4,3,2,1]
        # results = [executor.submit(do_something,sec) for sec in secs]
        #
        # for f in concurrent.futures.as_completed(results):
        #     print(f.result())

        results = executor.map(do_something,secs)
        for result in results:
            print(result)


    finish = time.perf_counter()

    print(f'Finished in {round(finish - start, 2)} second(s)')

"""

    NO TWO THREADS FROM THE SAME PROCESS CAN EXECUTE SIMULTANEOUSLY, BUT PROCESSES THEMSELVES CAN RUN AT THE SAME TIME.
    
    A protected global interpreter lock must be acquired by the thread to run.
        1. Ensures thread safety
        2. Improves single thread performance
        3. Prevents simultaneous multi-threading
            - Bad for CPU limited tasks but for beneficial for IO tasks
"""