import datetime

class Employee:

    raise_amount = 1.04
    num_of_employees = 0

    def __init__(self,first_name,last_name,pay):
        self.first_name = first_name
        self.last_name = last_name
        self.pay = pay
        self.email = self.get_email()
        Employee.num_of_employees += 1

    def get_email(self):
        return self.first_name + "." + self.last_name + "@gmail.com"

    def full_name(self):
        return self.first_name + " " + self.last_name

    def apply_raise(self):
        self.pay = int(self.pay * Employee.raise_amount)

    def __repr__(self):
        return f'Name : {self.first_name} {self.last_name}, Email : {self.get_email()}, Pay : {self.pay}'

    """
        Regular methods in a class automatically takes the self as the first argument but we can change it so that
        the class is the first argument taken using the @classmethod decorator
    """
    @classmethod
    def set_raise_amount(cls,amount):
        cls.raise_amount = amount

    """
        Creating an alternate class constructor
    """

    @classmethod
    def emp_from_str(cls,emp_str):

        first, last, pay = emp_str.split('-')
        return cls(first,last,pay)

    """
        Static Methods unlike class or regular methods do not take any default first argument like cls or self.
        They are like normal methods but are included in the class because they contain some requirement or relation to 
        the class
    """

    @staticmethod
    def is_workday(day):
        if day.weekday == 5 or day.weekday == 6:
            return False
        return True

emp1 = Employee("Test", "Unit", 100000)
print(emp1.email)

Employee.set_raise_amount(1.04)

print(Employee.raise_amount)
print(emp1.raise_amount)

"""
    Using Employee.set_raise_amount(num) is the same as saying Employee.raise_amount = num
    
    Running the class method using an instance will also apply the change to all the instances and the class itself
"""

emp2 = Employee.emp_from_str("John-Doe-100000")
print(emp2)

# Checking to see if the current day is a weekday or not
my_date = datetime.date(2016,7,11)
print(Employee.is_workday(my_date))