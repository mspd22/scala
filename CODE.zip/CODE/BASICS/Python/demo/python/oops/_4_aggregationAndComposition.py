
"""
    Aggregation - Represents a relationship where one object (the whole) contains references to one or more INDEPENDENT
                objects (the parts) -> "has-a" relation

    In the below example the classes library and book can exist without each other
"""

class Library:
    def __init__(self,name):
        self.name = name
        self.books = []

    def add_book(self, book):
        self.books.append(book)

    def list_books(self):
        return [f"{b.title} by {b.author}" for b in self.books]
class Book:

    def __init__(self,title, author):
        self.title = title
        self.author = author

library = Library("NW Public Library")

book1 = Book("HP","JKR")
book2 = Book("TH","JRRT")
book3 = Book("TCOM","TP")

library.add_book(book1)
library.add_book(book1)
library.add_book(book1)

print(library.list_books())


"""
    Composition - The composed object directly owns an object, which cannot exist independently. -> "owns-a" relation
"""