
"""
    Magic Methods -> Some special methods used in python which allows us to emulate some behaviour in python,
    and they also allow to perform operator overloading

    double underscore methods -> Magic Method -> Dunder Methods
"""

"""
    Example
        1. __init__
        2. __str__ -> A more readable representation of the object (for general purpose use cases like display to end user)
        @fallback_to_str
        3. __repr__ -> An unambiguous representation of the object (for developer use cases like debugging, logging)
        4. __add__ -> Dunder Add Method
        And many other numeric method
        
        5. __len__ -> The length of a object
"""

"""
    PROPERTY DECORATOR : Allows us to define a method which we can access like a variable
    
    getter and setter
"""
class Employee:

    raise_amount = 1.04
    num_of_employees = 0

    def __init__(self,first_name,last_name,pay):
        self.first_name = first_name
        self.last_name = last_name
        self.pay = pay
        self.email = self.get_email
        Employee.num_of_employees += 1

    @property
    def get_email(self):
        return self.first_name + "." + self.last_name + "@gmail.com"

    @property
    def full_name(self):
        return self.first_name + " " + self.last_name

    @full_name.setter
    def full_name(self,name):
        first, last = name.split(" ")

        self.first_name = first
        self.last_name = last

    @full_name.deleter
    def full_name(self):
        print("Deleting the Object Name",self)

        self.first_name = None
        self.last_name = None

    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amount)

    def __repr__(self):
        return f'Name : {self.first_name} {self.last_name}, Email : {self.get_email}, Pay : {self.pay}'

emp1 = Employee("John","Doe",100000)
print(emp1)
print(emp1.email)

print("Before : ",emp1)
emp1.full_name = "John Conner" # Cannot do this without a setter
print("After : ",emp1)

del emp1.full_name