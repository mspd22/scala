
"""
    Class -> A blueprint for designing a block of code that is useful for grouping important and related functionalities

    Attributes and methods

    An object is an instance of a class

    Variables in a class
        1. Instance Var -> Variables that are exclusive to each instance of a class
        2. Class Var -> Variables that are shared among all the instances and the class itself
"""

class Employee:

    """
        Class Variables
    """
    raise_amount = 1.04
    num_of_employees = 0

    """
        We have to add self to the methods in our class because the instance that is calling the method is passed implicitly
    """

    def __init__(self,first_name,last_name,pay):
        self.first_name = first_name
        self.last_name = last_name
        self.pay = pay
        self.email = first_name + "." + last_name + "@gmail.com"
        Employee.num_of_employees += 1

    def full_name(self):
        return self.first_name + " " + self.last_name

    """When we want to access the class variables, we need to access them from an instance of a class or the class name itself"""
    def apply_raise(self):
        self.pay = int(self.pay * Employee.raise_amount)


emp1 = Employee("John","Doe",230202) # An instance of a class
emp2 = Employee("Mark","Mc",22333) # Another separate instance

print(emp1.email)
print(emp2.email)

print(emp2.full_name())
print(Employee.full_name(emp1)) # Can also be called as this

""" Increasing Pay """
print(emp1.pay)
emp1.apply_raise()
print(emp1.pay)

"""
    When we try to access a member of a class then python checks whether the instance contains that variables or not,
    if it is not found then it checks the class and the parent classes for the member.
    
    Hence why the instances also have access to the class variables
"""

print(emp1.__dict__)
print(Employee.__dict__)

"""
    When we try to access and set the class variables from an instance then the variable is created for that particular
    instance and then the namespace of that instance also adds the member to itself.
    
    So the class variable becomes an instance variable for that instance only. All the other instances continue to access
    the class variable until unless they are set in that instance.
"""