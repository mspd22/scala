
"""
    Inheritance allows us to inherit attributes and behaviour from other classes allowing us to reuse code and define proper
    general blueprints which can then be inherited and specialized according to the use case.
"""
class Employee:

    raise_amount = 1.04
    num_of_employees = 0

    def __init__(self,first_name,last_name,pay):
        self.first_name = first_name
        self.last_name = last_name
        self.pay = pay
        self.email = self.get_email()
        Employee.num_of_employees += 1

    def get_email(self):
        return self.first_name + "." + self.last_name + "@gmail.com"

    def full_name(self):
        return self.first_name + " " + self.last_name

    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amount)

    def __repr__(self):
        return f'Name : {self.first_name} {self.last_name}, Email : {self.get_email()}, Pay : {self.pay}'


"""
    Even without any code in the developer class the functionality of the Employee class has been inherited and can be
    used by it
    
    When the developer object is created python looks the init method in the developer class but does not find it,
    then it will move up the chain of inheritance until it finds a init function in one of its parent classes and use it
    
    This chain is called method resolution order.
"""
class Developer(Employee):

    raise_amount = 1.10

    """
        The child classes generally have more information than the parent class can handle
    """

    def __init__(self,first_name,last_name,pay,language):
        super().__init__(first_name,last_name,pay)
        """
            or 
        """
        # Employee.__init__(self,first_name,last_name,pay)
        self.language = language

    def __repr__(self):
        return super().__repr__() + f", Language : {self.language}"

dev1 = Developer("Corey","Schafer",100000,"Python")
dev2 = Developer("Test","Unit",500000,"Java")

print(dev1)
print(dev2)

# print(help(Developer)) # Will give a lot of information and the MRO

print("\nChanging the pay of the developer using a explicit raise amount for Developer")
print(dev1.pay)
dev1.apply_raise() # Will use the developer class defined raise amount
print(dev1.pay)


class Manager(Employee):

    def __init__(self,first_name,last_name,pay,employees = None):
        super().__init__(first_name,last_name,pay)
        if employees is None :
            self.employees = []
        else :
            self.employees = employees

    def add_employee(self,emp):

        if emp not in self.employees :
            self.employees.append(emp)

            return True
        return False

    def remove_employee(self,emp):
        if emp in self.employees :
            self.employees.remove(emp)

            return True
        return False

    def print_employees(self):

        for i,emp in enumerate(self.employees):
            print(i," --> ",emp.full_name())

    def __repr__(self):
        return super().__repr__() + f", {self.employees}"


mgr1 = Manager("Sue","Smith",90000,[dev1,dev2])
print(mgr1)

mgr1.print_employees()

"""
    isinstance() -> A method provided by python to check if an object is an instance of a particular class
    Syntax : isinstance(object,class)
    
    issubclass() ->  A method provided by python to check if an class is an sub class of a particular class
    Syntax : issubclass(childClass,parentClass)
"""