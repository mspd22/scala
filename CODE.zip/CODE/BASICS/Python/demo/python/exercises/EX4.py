# Circumference and Area of a Circle
import math

radius = float(input("ENTER THE RADIUS OF THE CIRCLE : "))
print(f"THE CIRCUMFERENCE OF THE CIRCLE IS : {round(2 * radius * math.pi,4)}cm^2")
print(f"THE AREA OF THE CIRCLE IS : {round(math.pi * pow(radius, 2.0),4)}cm^2")