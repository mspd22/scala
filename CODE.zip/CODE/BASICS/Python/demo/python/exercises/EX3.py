# Mad libs Game
# Word Game where you create a story by filling in the blanks with random words

adjective1 = input("Enter an adjective(description) : ")
noun1 = input("Enter a noun (person, place, thing : ")
adjective2 = input("Enter the Second Adjective : ")
verb1 = input("Enter an verb ending with 'ing' : ")
adjective3 = input("Enter the third adjective : ")

print(f"Today I went to a {adjective1} Zoo.")
print(f"In an exhibit i saw a {noun1}")
print(f"{noun1} was {adjective2} and {verb1}")
print(f"I was {adjective3}")