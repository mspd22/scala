# Hypotenuse of a right triangle
import math

a = float(input("SIDE A : "))
b = float(input("SIDE B : "))

print(f"THE HYPOTENUSE IS OF LENGTH : {math.sqrt((pow(a,2.0) + pow(b,2.0)))}")