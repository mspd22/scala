# Shopping Cart Program

item = input("The Item You Want to Buy : ")
price = float(input("The price of the item : "))
quantity = float(input("How many do you need : "))

print(f"You have bought {int(quantity)} x {item}. Your Total comes to ${price * quantity}")