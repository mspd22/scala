# Rectangle area calculate

length = float(input("ENTER THE LENGTH OF THE RECTANGLE : "))
width = float(input("ENTER THE WIDTH OF THE RECTANGLE : "))

print(f"THE AREA OF THE RECTANGLE IS : {length * width}")

# print(f"THE AREA OF THE RECTANGLE IS : {float(input("Enter the length : ")) * float(input("Enter the width : "))}")