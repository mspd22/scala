package playground

object scalaPlayground extends App {
    println("Hello Scala!")
}
