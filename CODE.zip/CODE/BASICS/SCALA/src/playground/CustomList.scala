package playground

trait MyPredicate[-A] {
    def test(condition : A) : Boolean
}

trait MyTransformer[-A,B] {
    def transform(toTransform : A) : B
}

/*
    @params
    HEAD - the first node of the list
    tail - the rest of the list

    @methods
    isEmpty() - > Checks to see if the list is empty or not
    add(int) - > Adds a new element to the list
    toString - > Return a string representation

    @advancedMethods
    map(transformer) : CustomList
    filter(predicate) : CustomList
    flatMap(transformer) : CustomList
 */

abstract class CustomList[+A] {

    def head : A
    def tail : CustomList[A]
    def isEmpty : Boolean
    def add[B >: A](element : B) : CustomList[B]

    def printElements : String
    override def toString: String = "[ " + printElements + "]"

    // map, filter and flatMap

    /*
        Here we will write map[B] because we need to be aware of the type we are converting the list into i.e B
     */
    def map[B](transformer : MyTransformer[A, B]) : CustomList[B]
    def flatMap[B](transformer: MyTransformer[A, CustomList[B]]) : CustomList[B]
    def filter(myPredicate: MyPredicate[A]) : CustomList[A]

    // helperFunctions

    def ++[B >: A](list : CustomList[B]) : CustomList[B]
}

class Cons[+A](headElement : A,tailList : CustomList[A]) extends CustomList[A]{

    def head : A = headElement
    def tail : CustomList[A] = tailList
    def isEmpty: Boolean = false
    def add[B >:A](element: B): CustomList[B] = new Cons(element,this)

    def printElements: String = headElement + " " + tailList.printElements

    // map, filter and flatMap

    override def filter(myPredicate: MyPredicate[A]): CustomList[A] = {
        if(myPredicate.test(headElement)) new Cons(headElement,tailList.filter(myPredicate))

        else tailList.filter(myPredicate)
    }

    override def map[B](transformer: MyTransformer[A, B]) : CustomList[B] = {
        new Cons(transformer.transform(headElement),tailList.map(transformer))
    }

    override def flatMap[B](transformer: MyTransformer[A, CustomList[B]]): CustomList[B] = {
        transformer.transform(headElement) ++ tailList.flatMap(transformer)
    }

    //

    def ++[B >: A](list : CustomList[B]) : CustomList[B] = new Cons(headElement, tailList ++ list)
}

object Empty extends CustomList[Nothing]{

    def head: Nothing = throw new NoSuchElementException("No List present")
    def tail: Nothing = throw new NoSuchElementException("No List Present")
    def add[B >: Nothing](element: B): CustomList[B] = new Cons(element,Empty)
    def isEmpty: Boolean = true
    override def printElements : String = ""

    // filter, map and flatMap

    def map[B](transformer : MyTransformer[Nothing, B]) : CustomList[B] = Empty
    def flatMap[B](transformer: MyTransformer[Nothing, CustomList[B]]) : CustomList[B] = Empty
    def filter(myPredicate: MyPredicate[Nothing]) : CustomList[Nothing] = Empty

    //

    def ++[B >: Nothing](list : CustomList[B]) : CustomList[B] = list
}

object listTesting extends App{

    val newList = new Cons(1, new Cons(2, new Cons(3, new Cons(4, Empty))))

    println(newList.head)
    println(newList.toString)

    println(newList.add(10))
}
