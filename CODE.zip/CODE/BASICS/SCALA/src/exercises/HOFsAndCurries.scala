package exercises

object HOFsAndCurries extends App {

    /*
        1. EXPAND functionalMyList
            - foreach Method A => Unit
            - sort function ((A,A) => Int) => MyList
            - zipWith (list, (A,A) => B) => MyList[B]
            - fold (start)(function) => A value -> just reduce with custom starting accumulator


        2. toCurry(f : (Int,Int) => Int) => (Int => Int => Int)
           fromCurry -> Reverse

        3. compose((f,g) => x => f((g(x))
           andThen((f,g) => g(f(x))
     */

    /*
        EXERCISE 3
     */

    def square(x : Int) : Int = x * x
    def mul(x : Int) : Int = x * 9

    def compose[A,B,T](f : A => B, g : T => A) : T => B = (x : T) => f(g(x))

    val fun1 = compose(square,mul)
    println(fun1(1))

    def andThen[A,B,C](f : A => B, g : B => C) : A => C = (x : A) => g(f(x))
    println(andThen((x : Int) => x * 2, (y : Int) => y + 3)(10))

    /*
        Exercise 2
     */

    def toCurry(f : (Int,Int) => Int) : Int => Int => Int = (x : Int) => (y : Int) => f(x,y)
    def fromCurry(f : (Int => Int => Int)) : (Int, Int) => Int = (x : Int, y : Int) => f(x)(y)
}
