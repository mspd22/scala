package exercises

import scala.annotation.tailrec

object mapsAndTuples extends App {

    /*
        1. What would happen if in the lowercase map we had two original entries like "Jim" and "jim"

        2. Overly simplified social network based on maps
            Person = String
            - add -> add a new Person to the network
            - remove
            - friend - Mutual
            - unFriend

            - number of friends of a Person
            - how many people have no friends
            - If there is a social connection between two people
     */

    val lowerCaseMap : Map[String, Int] = Map("Jim" -> 102, "jim" -> 9039)
    println(lowerCaseMap)

    // Q1
    println(lowerCaseMap.map(pair => pair._1.toLowerCase -> pair._2))

    // The value got updated with the latest value

    // Q2

    def add(network : Map[String,Set[String]], name : String) : Map[String, Set[String]] = network + ( name -> Set[String]())

    def friend(network : Map[String,Set[String]],name : String, friend : String) : Map[String,Set[String]] = {
        val friendsA = network(name)
        val friendsB = network(friend)

        network + (name -> (friendsA + friend)) + (friend -> (friendsB + name))
    }

    def unFriending(network : Map[String,Set[String]],name : String, friend : String) : Map[String,Set[String]] = {

        val friendsA = network(name)
        val friendsB = network(friend)

        network + (name -> (friendsA - friend)) + (friend -> (friendsB - name))
    }

    def remove(network : Map[String,Set[String]],personToRemove : String) : Map[String, Set[String]] = {

        @tailrec
        def removeAux(setOfFriends : Set[String],networkAcc : Map[String,Set[String]]) : Map[String,Set[String]] ={

            if(setOfFriends.isEmpty) networkAcc

            else removeAux(setOfFriends.tail,unFriending(networkAcc,personToRemove,setOfFriends.head))
        }

        removeAux(network(personToRemove),network) - personToRemove
    }

    def nFriends(network: Map[String, Set[String]], name : String) : Int = {
        if(network.contains(name)) network(name).size

        else -1
    }

    def mostFriends(network : Map[String, Set[String]]) : String = network.maxBy(pair => pair._2.size)._1

    def noFriends(network : Map[String, Set[String]]) : Int = network.count(pair => pair._2.isEmpty)

    def socialConnection(network : Map[String, Set[String]], person1 : String, person2 : String) : Boolean = {

        @tailrec
        def bfs(target : String, consideredPeople : Set[String], discoveredPeople : Set[String]) : Boolean = {

            if(discoveredPeople.isEmpty) false

            else{
                val person = discoveredPeople.head

                if(person == target) true

                else if(consideredPeople.contains(person)) bfs(target,consideredPeople,discoveredPeople.tail)

                else bfs(target,consideredPeople + person, discoveredPeople.tail ++ network(person))
            }
        }

        bfs(person1,Set(),network(person1) + person2)
    }

    val empty : Map[String, Set[String]] = Map()
    val socialNetwork = add(add(empty,"Bob"),"Mary")

    println(socialNetwork)

    println(friend(socialNetwork,"Mary","Bob"))
    println(remove(friend(socialNetwork,"Mary","Bob"),"Bob"))

    // PeopleNet Jim, Bob, Mary

    val testNet = friend(friend(add(add(add(empty,"Bob"),"Mary"),"Jim"),"Bob","Jim"),"Bob","Mary")
    println(testNet)

    println(nFriends(testNet,"Mary"))
    println(mostFriends(testNet))
    println(noFriends(testNet))
    println(socialConnection(testNet,"Jim","Mary"))
    println(socialConnection(testNet,"Jim","Bob"))
}
