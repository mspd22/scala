package topics.patternMatching

import playground.{Cons, CustomList, Empty}

object _1_allThePatterns extends App {

    // 1. Constants
    val x : Any = "Scala"
    val contains = x match {
        case 1 => "A Number!"
        case "Scala" => "The Scala"
        case true => "The Truth"
        case _1_allThePatterns => "A singleton Object"
    }

    // 2. Match Anything
        // 2.1 Wildcard
    val matchAnything = x match {
        case _ => true
    }

        // 2.2 variables
    val matchVariable = x match {
        case something => s"I've found $something"
    }


    // 3. Tuples
    val aTuple = (1, 2)
    val matchATuple = aTuple match {
        case (1, 1) => println("sk")
        case (something, 2) => s"I have found $something"
    }

    val nestedTuple = (1, (2, 3))
    val mathcNestedTuple = nestedTuple match {
        case (_ ,(2, v)) => s"I have found $v"
    }

    // 4. Case Classes - a constructor pattern
    val aList : CustomList[Int] = new Cons(1, new Cons(2 ,new  Cons(3, Empty)))
    val matchList = aList match {
        case Empty =>
//        case Cons(head, Cons(subhead, subtail)) =>
    }

    // 5. List Patterns
    val aStandardList = List(1,2,3,4)
    val standardListMatching = aStandardList match {
        case List(1, _, _, _) => // explicit search - advanced
        case List(1, _*) => // List of arbitrary length - advanced
        case 1 :: List(_) => // infix Pattern
        case List(1,2,3) :+ 42 => // infix patterns
    }

    // 6. Type Specifiers
    val unKnown : Any = 2
    val unKnownMatch = unKnown match {
        case list : List[Int] => //explicit type specifier
        case _ =>
    }

    // 7. Name Binding
//    val nameBindingMatch = aList match {
//        case nonEmptyList @ Cons(_ , _) => // name binding => use the name later
//        case Cons(1, rest @ Cons(2, _)) => // name binding inside nested patterns
//    }

    // 8. Multi-Patterns - Multiple Patterns chained by a pipe operator
//    val multiPattern = aList match {
//        case Empty | Cons(0, _) => // compound pattern (multi-pattern)
//    }

    // 9. if guards
//    val secondElementSpecial = aList match {
//        case Cons( _, Cons(specialElement, _)) if specialElement % 2 == 0 =>
//    }

    /*
        QUESTION
     */


    val numbers = List(1,2,3)
    val numbersMatch = numbers match {
        case listOfStrings : List[String] => "A list of strings"
        case listOfNumbers : List[Int] => "A list of Integers"
        case _ => ""
    }

    println(numbersMatch) // -> Will give a list of strings as the output

    /*
        -- TYPE ERASER --

        JVM TRICK QUESTION - JVM IS DESIGNED FOR JAVA WHICH IS DESIGNED WITH BACKWARDS COMPATIBILITY IN MIND

        BUT AT JAVA 1 IT DID NOT HAVE GENERICS, WHICH WERE INTRODUCED AT JAVA 5.
        SO TO MAKE JAVA 5 COMPILER COMPATIBLE WITH JAVA 1, THE JAVA 5 COMPILER ERASES ALL GENERIC TYPES AFTER TYPE CHECKING
        SO the jvm is oblivious to generic types. Scala also suffers from this fault.


        so After type checking our pattern matching expressions look like this
            val numbersMatch = numbers match {
                case listOfStrings : List => "A list of strings"
                case listOfNumbers : List => "A list of Integers"
                case _ => ""
            }
     */
}
