package topics.patternMatching

object _2_patternsEverywhere extends App {

    try{
        //code
    } catch {
        case e :  RuntimeException => "Runtime"
        case npe : NullPointerException => "npe"
        case  _ => "Something else"
    }

    // catches are actually matches
    /*
         try{
            //code
        } catch (e) {
            e match {
                case e :  RuntimeException => "Runtime"
                case npe : NullPointerException => "npe"
                case  _ => "Something else"
            }
        }
     */

    /*
        GENERATORS ARE ALSO MATCHES
     */

    val list = List(1,2,3,4)
    val evenOnes = for {
        x <- list if x % 2 == 0 // ??
    } yield 10 * x

    // ALL GENERATORS
    val tuples = List((1,2),(3,4))
    val filterTuples = for {
        (first,second) <- tuples
    } yield first * second

    // case classes :: ,operators ....

    val tuple = (1,2,3)
    val (a, b, c) = tuple
    // Multiple  Value Definition based on Pattern matching

    val head :: tail = list
    println(head + "  :  " + tail)

     /*
        PARTIAL FUNCTION - Literal
      */

    val mappedList = list.map{
        case v if v % 2 == 0 => v + " Is Even"
        case 1 => "The one"
        case _ => "Something Else"
    }

    /*
        SAME AS SAYING -
             val mappedList = list.map{ x => x match {
                case v if c % 2 == 0 => v + " Is Even"
                case 1 => "The one"
                case _ => "Something Else"
                }
            }
     */

    println(mappedList)
}
