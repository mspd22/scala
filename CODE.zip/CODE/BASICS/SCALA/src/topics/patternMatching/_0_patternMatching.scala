package topics.patternMatching
import scala.util.Random

object _0_patternMatching extends App {
    /*
        PATTERN MATCHING - A SWITCH ON STEROIDS

        Use cases -
            1. Decompose Values (especially with case Classes)
            2. What if no matches are present. That is we do not use the _ identifier, then we will get a Scala.MatchError
            3. The return type of the PM will be the unified type of all the cases (L.C.A)
            4. Pattern Matching on sealed Hierarchies and pm works well with case classes
     */

    val random = new Random
    val x = random.nextInt(10)

    val description = x match {
        case 1 => "The one"
        case 2 => "Double or Nothing"
        case 3 => "Third Times the Charm"

        case _ => "Everything Else"
    }

    println(x + " " + description)

    // Decomposing case classes
    case class Person(name : String, age : Int)
    val bob = Person("Bob",20)

    /*
        We can decompose a case class into its components and also apply guards on the cases
     */
    val res = bob match {
        case Person(n, a) /* This is a guard */ if a < 21 => s"Hi!, my name is $n and I can't drink in the USA."
        case Person(n, a) => s"Hi!, my name is $n and I am $a years old."
        case _ => "I don't know who I am."
    }

    println(res)

    // PM on sealed Hierarchies

    sealed class Animal
    case class Dog(breed : String) extends Animal

    val animal : Animal = Dog("Terra Nova")
    animal match{
        case Dog(someBreed) => println(s"Matches a Dog of $someBreed breed")
    }

    /*
        DO NOT DO THIS
     */

    val isEven = x match {
        case n if n %2 == 0 => true
        case _ => false
    } // NO

    val isEvenCon = if(x % 2== 0)  true else false
    val isEvenNormal = x%2 == 0 // this is the normal way


    /*
        EXERCISES -
            Implement a simple function that uses pm and takes an  expr as a parameter and provides a
            human-readable format
     */

    trait Expr
    case class Number(n : Int) extends Expr
    case class Sum(e1 : Expr, x2 : Expr) extends Expr
    case class Prod(e1 : Expr, x2 : Expr) extends Expr

    def show(e : Expr) : String = e match {
        case Number(n) => s"$n"

        case Sum(e1,e2) => show(e1) + " + " + show(e2)

        case Prod(e1,e2) =>
            def maybeShowParenthesis(exp : Expr) = exp match {
                case Prod(_, _) => show(exp)
                case Number(n) => show(exp)
                case _ => "( " + show(exp) + " )"
            }

            maybeShowParenthesis(e1) + " * " + maybeShowParenthesis(e2)
    }

    println(show(Sum(Prod(Prod(Sum(Number(10),Number(23)),Sum(Number(100),Number(20))),Prod(Sum(Number(10),Number(2)),Number(45))),Number(33))))
}
