package topics.basics
import topics.oops.Person

object _8_packagesAndImports extends App {

    /*
        Packages are a group of definitions bundled under the same name. The package definition on the top of the scala file defines that the all the code
        written will belong to that package. Members within a package are visible using their simple names.
     */

    // so for example I can do this

    // val newObj = basics.matches
    // println(newObj.age)

    /*
        WE CAN ALSO IMPORT PACKAGES USING THE IMPORT KEYWORD

        Or we can use the fully qualified name that is packageName.className etc...,
     */

    val testing = new Person("John",20)


    /*
        PACKAGES ARE ORDERED HIERARCHICALLY. THE HIERARCHY IS DEFINED USING THE DOT NOTATION.

        They are generally identical to the folder structure

        Now we will see a scala specific code organising structure -> A Package Object
     */

    // A Package Object arises from the problem that sometimes we want to write methods or constants basically outside of everything else.
    // Right now we can write classes or objects or methods and access everything from them, but we might need some universal constants or
    // methods

    /*
        1. There can only be one package object per package
        2. The package object is named as Package.scala
        3. There will be an object inside the package object with the same name as the package it resides in
     */
}

/*
    IMPORTS

    1. Use the import Keyword
    2. if there are multiple imports from a same package the nomenclature is something like -
        import packageName.{entity1, entity2, ...}
    or if you want to import everything in a package
        import packageName._
    3. You can also give aliases to the entities you import as such
        import playground.{Cinderella => Princess}

    Aliasing is useful when you import multiple methods with the same name
 */

/*
    Some default Packages which are included are
    java.lang - String, object, Exception
    Scala - Int, Nothing, Function
    Scala.Predef - println, ???

    etc...,
 */