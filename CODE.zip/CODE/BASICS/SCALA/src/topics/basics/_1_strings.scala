package topics.basics

object _1_strings extends App {

    /*
        String -> the string class is immutable in scala and if we want to modify a string then use a string builder class
     */

    val str : String = "Hello, I am learning Scala";

    println(str.charAt(2))
    println(str.substring(7))
    val myList : List[String] = str.split(" ").toList
    println(str.startsWith("Hello"))
    println(str.replace(" ","-"))
    println(str.length())
    println(str.toLowerCase())

    // SCALA SPECIFIC

    val str42 = "2"
    val num42 = str42.toInt
    println('a' +: str42 :+ 'z')
    println(str.reverse)



    /*
        String Interpolation in scala can be done in four ways

            1. THE NORMAL WAY OF JUST CONCATENATING THEM USING '+' OPERATOR OR USING THE CONCAT METHOD
            2. USING THE S STRING INTERPOLATION
            3. USING THE F STRING INTERPOLATION (type safe)
            4. RAW INTERPOLATION
        */

    val s : String = "Hello"
    val r : String = "World!"

    println(s + ", " + r);

    val name : String = "John";
    val age = 50.5;


    println(s"$name is $age Years old.")
    println(f"$name%s is $age%.2f Years old.")

    // we can also do this
    println(f"$name%s is ${age + 10.3}%10.2f Years old.")


    print(s"Hello \tWorld\n")
    print(raw"Hello \t World")
}
