package topics.basics

object _3_Arrays extends App {

    /*
    Arrays -> A data type which stores fixed size sequential data of a single type.

    1. An array is used to store a collection of data, but it is often more useful to
            think of an array as a collection of variables of the same type.

    2. The variable store the reference to the address of the first data of the array and then dereferences it when called.

    3. Scala does not provide ways to perform operations directly, but it does allow processing in any dimension. Use Array._
        package to get access to different array operations.
 */

    // Ways to declare an array

    val arr1 : Array[Int] = new Array[Int](5)
    for(i <- 0 to 4) arr1(i) = i+1
    println(arr1.mkString("Array(", ", ", ")"))

    // or

    val arr2 : Array[Int] = Array(1,2,3,4,5)
    println(arr2.mkString("Array(", "," , ")"))

    /*
        Multi-Dimensional Arrays
     */

    import Array._
    val mulArr : Array[Array[Int]] = ofDim[Int](2,3)

    for(i <- 0 to 1)
        for(j <- 0 to 2)
            mulArr(i)(j) = (i+1)*(j+1)
    println(mulArr.mkString("Array(", ", ", ")"))

    // The Concat Method
    val arr3 : Array[Int] = Array.concat(arr1,arr2)
    println(arr3)

    // The Range Method range(start, end, step)
    val arr4 : Array[Int] = range(1,50,3)
    println(arr4.mkString("Array(", ", ", ")"))

}
