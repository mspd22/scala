package topics.basics

object _5_matches extends App {

    val age : Int = 25;
    age match {
        case 10 => println("YOU ARE BELOW 10 YEARS");
        case 25 => println("YOU ARE BETWEEN 10 AND 25");
        case 50 => println("YOU ARE BETWEEN 25 AND 50");
        case _ => println("AGE NOT FOUND");
    }
}
