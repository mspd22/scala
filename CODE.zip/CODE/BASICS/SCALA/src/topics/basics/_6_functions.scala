package topics.basics

import scala.annotation.tailrec

object _6_functions extends App {
    /*
    def nameOfFunction (args : dataTypeOfArgument) : returnType{
        statements...
        ...
        ...
        ...
        ...

        return value -> return type can be of any valid scala data type
    }

    1. Here we can just remove the remove keyword as Scala considers the last line of the function as a return value if no keyword is used.

    2. A Scala method is a part of a class which has a name, a signature, optionally some annotations, and some bytecode whereas a function
        in Scala is a complete object which can be assigned to a variable.
 */

    object math{

        def add(x : Int, y : Int) : Int = {
            return x + y
        }

        def sub(x : Int,y : Int) : Int = x - y

        /* A function that does not return anything implicitly returns a Unit type back to the calling object/method */
    }


    println(math.add(10,20))
    println(math.sub(10,20))

    // THIS CAN ALSO BE WRITTEN AS
    println(math `add` (40, 50))


    /*
        CALL BY NAME

        1. When we want to send a value for which the value has to be calculated at the time of calling
        2. We will use a code block as a parameter for the calling function which will execute the code block everytime it calls it.


        Here the => is used to define that this is a call-by-name function or argument which literally means that the name or the code block is
            taken and put in the place of the argument of the function.

            Example -

                def callByName(x: => Long) : Unit = {
                    println(x);
                    println(x);
                }

                This will be written in compile time as

                def callByName(x: => Long) : Unit = {
                    println(System.nanoTime())
                    println(System.nanoTime())
                }

                callByName(System.nanoTime())

        In normal callByValue functions the value of the expression given, will be calculated first and directly given to the function.
        But in call by value it executes the expression each time it is used in the function block

        !!! Most importantly the expression will be not be evaluated until it is used in the function
     */

    object cbn{

        def cbnMain() : Unit = {
            delayed(time())
        }

        def time() : Long = {
            println("--GETTING SYSTEM TIME IN TIME--")
            System.nanoTime
        }

        def delayed(t : => Long) : Unit = {
            println("In delayed method : ")
            println(f"Param : $t%d")
        }
    }

    cbn.cbnMain()



    /*
        Name Arguments -> You can change the order in which you can pass arguments
     */

    def namedArguments(a : Int,b : Int) : Int = a + b

    println(namedArguments(b = 40,a = 30))

    /*
        Default Parameters -> same same
     */

    def defaultParameters(a : Int, b : Int = 1) : Int = {
        if(a < 1) b
        else a *  defaultParameters(a-1)
    }

    /*
        Variable Parameters

     */

    def variableParameters(args: String*): Unit = {
        var i: Int = 0

        for (arg <- args) {
            println("Arg value[" + i + "] = " + arg)
            i = i + 1
        }
    }

    variableParameters("Hello","world","!")


    /* RECURSIVE FUNCTIONS */ // same-same

    /*
        HIGHER ORDER FUNCTIONS (HOFs) - FUNCTIONS WHICH TAKE OTHER FUNCTIONS AS PARAMETERS OR RETURN OTHER FUNCTIONS
    */

    // A function which will take three arguments
    //      1. A function which will apply the transformation
    //      2. The number of times the transformations has to take place
    //      3. The subject of the transformation

    // nTimes(f,n,x) => f(f(f( ...... x    .....))) n-times =  nTimes(f,n-1,x)
    @tailrec
    def nTimes(f : Int => Int, n : Int, x : Int) : Int = {
        if(n < 1) x

        else nTimes(f,n-1,f(x))
    }

    // a functions which is used to add one to an integer.
    def plusOne(x : Int) : Int = x + 1

    /*
        This is one way of doing it, but we can do better instead of applying the function here we can create a lambda to which we can give any value
        for the same
     */

    def nTimesBetter(f : Int => Int, n : Int) : Int => Int = {

        if(n < 1) (x:Int) => x

        else (x : Int) => nTimesBetter(f,n-1)(f(x))
    }

    /*  Make a HOF   which takes an array or list and gives the minimum using the above syntax*/

    def math1(x : Double, y : Double, f : (Double,Double) => Double) : Double = f(x,y)
    def math2(x : Double, y : Double, z: Double, f : (Double,Double) => Double) : Double = f(x,f(y,z))

    println("TEST 1 : " + math1(10,20, (x,y) => x + y))
    println("TEST 2 : " + math1(10,20,  _+_))
    println("TEST 3 : " + math2(10,20,30, (x,y) => x + y))
    println("TEST 4 : " + math2(10,20,30, (x,y) => x min y))
    println("TEST 5 : " + math2(10,20,30, _ min _))


    /*
        NESTED FUNCTIONS -> FUNCTIONS INSIDE A FUNCTION

        Here the inner functions are also called as local functions
     */


    def outer(): Unit = {
        def Inner() : Unit = {
            println("INSIDE")
        }
        Inner()
        println("OUTSIDE")
    }
    outer()

    /*

        Nested Functions give use the ability to use closures

        CClosures are the functions whose return value depends on one or more values present outside the function

        A free variable is a variable whose value is not dependent on the function but the function is dependent on this variable
     */

    def couter() :Unit = {
        var num = 10
        println("COUTER 1 : " + num)
        def cinner() : Unit = {
            println("CINNER 1 : " + num)
            num = 100
            println("CINNER 2 : " + num)
        }
        cinner()
        println("COUTER 2 : "  + num)
    }

    couter()

    // The value of the free variable can be changed for the inner function or closure function
    // Impure Closure - The value of the free variable can be changed from inside the closure
    // Pure Closure - The value of the free variable cannot be changed from the closure


    /* ANONYMOUS FUNCTIONS */

    val doubler = new Function1[Int,Int] { // this can also be written as val doubler = new ((Int) => Int) { .....
        override def apply(x: Int): Int = x*2
    }

    println(doubler(10))

    /* Instead of this, we can just write */

    val betterDouble : Int => Int = (x : Int) => x*2
    println(betterDouble(10))



}
