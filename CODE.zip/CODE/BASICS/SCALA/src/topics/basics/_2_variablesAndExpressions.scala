package topics.basics

object _2_variablesAndExpressions extends App {

    // Two ways to declare variables in scala

    /*
        1. Mutable variables using var - CHANGING A VARIABLE IS CALLED A SIDE EFFECT
        2. Immutable variables using val

        In scala val is similar to final or const, but they serve a completely different purpose. They are considered as intermediate computations
            stored to be used in later larger computations.
     */

    // var variableName : dataType = value;
    // ; is optional
    var x : Int = 10
    println(x)

    val y : Int = 100
    println(y)
    // y = 30 // -> This line will give compilation error since we have declared an immutable variable and trying t0 change it

    /*
        var c : Int; is not possible
        instantiation without initialisation is not possible.
     */

    /*
        Scala is capable of type interpretation
     */

    var b = true;
    // above the scala compiler is capable of determining that the var is a boolean

    var d = 10.3423;
    // by default, it considers this as a double but if we want we can change it to float using
    var dd = 10.3423f;

    /* MULTIPLE EXPRESSIONS */
    def foo() : Unit = {
        println("Inside Foo")
    }

    /*
        CODE BLOCKS
     */

    val r1 = {
        val r1 : Int = 100
        val r2 : Int = 300
        val b37 : Boolean = false
        foo(); // this will be called.
        r1 + r2
    }
    println(r1)

    val (a50 : Int, b50 : Int) = (10,20)
    println(s"$a50 and $b50")
    // println(b37); // Here this line will give an error because the variables declared inside the expressions are temporary and do not affect the outside

    /*
        Lazy Loading or On-Demand_Loading

        What if we create a list with millions of values, but it is not assigned yet so there is a large waste of space

        to solve this we can use the lazy keyword

        lazy var x : Int = 100;
        x: Int = <Lazy>

        Here until x is used it is not instantiated
     */


    /*
        Variables Scope

        1. Fields -> Inside Objects
        2. Local Variables -> Inside Methods
        3. Method Parameters -> Passed as Arguments

     */




    /* ---EXPRESSIONS--- */


    //INSTRUCTIONS VS EXPRESSIONS

    // 1. INSTRUCTIONS ARE STATEMENTS WHICH TELL THE COMPUTER TO DO SOMETHING
    // 2. EXPRESSIONS ARE STATEMENTS WHICH HAVE SOME VALUE OR TYPE - those which get evaluated



    // EVERYTHING (MOSTLY) IN SCALA IS A EXPRESSION

}
