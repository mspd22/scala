package topics.basics

object _4_loops extends App {

    /*
        Loops are used for executing a block for a specified number of times.

        Scala supports three types of loops:
            1. while Loop - Repeats a statement or group of statements while a given condition is true. It tests the condition before executing the loop body.
            2. do-while Loop - Like a while statement, except that it tests the condition at the end of the loop body.
            3. for Loop - Executes a sequence of statements multiple times and abbreviates the code that manages the loop variable.

        Scala provide us with two loop control statements
            1. Continue - goes to the next iteration of the loop without completely breaking it
            2. Break - breaks the loop and progresses the control flow
     */
    import scala.util.control.Breaks

    // THE WHILE LOOP
    println("THE WHILE LOOP RUNS UNTIL THE CONDITION IS TRUE")
    println("The while loop:")
    var i : Int = 0
    while(i< 10){
        print(f"$i%d ")
        i += 1
    }
    println("\n\n")


    println("THE DO-WHILE LOOP HAS BEEN DEPRECATED INS SCALA\n\n")
    //The do-while LOOP -> THIS IS DEPRECATED IN JAVA IS NO LONGER SUPPORTED.
    // i = 0;
    // do{
    //     print(f"$i%d ");
    //     i += 1;
    // } while(i < 10);

    /*
        THE FOR LOOP

        '<-' - THIS IS CALLED A GENERATOR
     */

    println("\n\nTHE FOR LOOP IS THE MOST VERSATILE LOOP WHICH CAN PERFORM MANY FUNCTIONS WHEREAS THE WHILE LOOP IS SAFER AND EASIER TO MAINTAIN\n")
    // 1 Normal For loop
    for(i <- 1 to 10) print(f"$i%d ")
    println()

    println("\nFOR LOOP WITH MULTIPLE COMMANDS")
    // 2 MULTIPLE COMMANDS
    for(i <- 1 to 10; j <- 1 to 10){
        println(f"$i%d and $j%d")
    }

    println()

    for(i <- 1 to 10; j <- 1 to 10){
        print(f"i is $i%d ")
        print(f"j is $j%d ")
        println()
    }


    println("\nFOR LOOP WITH COLLECTIONS")
    // 3 FOR LOOP FOR COLLECTIONS
    for(ele <- Array(1,2,3,4,5)){
        println(ele)
    }


    println("\nFOR LOOP WITH FILTERS")
    // 4 FOR LOOP WITH FILTERS
    val numList1 = List(1,2,3,4,5,6,7,8,9,10)

    // for loop execution with multiple filters
    for( a <- numList1 if a != 3; if a < 8 ){
        println( "Value of a: " + a )
    }

    println("\nFOR LOOP WITH YIELD STATEMENT TO RETURN THE VALUES DURING LOOP")
    // 5 FOR LOOP WITH YIELD STATEMENTS
    val numList2 = List(1,2,3,4,5,6,7,8,9,10)

    // for loop execution with a yield
    var retVal = for { a <- numList2 if a != 3; if a < 8 } yield a

    // Now print returned values using another loop.
    for( a <- retVal){
        println( "Value of a: " + a )
    }

    /*
        Break Statements in SCALA

        1. SCALA DOES NOT PROVIDE A BREAK STATEMENT BY DEFAULT BUT WE CAN USE THE BREAKABLE METHOD

        A new breaks object has to be created in which the loops will be present, and then we can use the break method to break outside of loop
     */

    println("\n\nBREAKS IN SCALA")
    var loop = new Breaks
    var lb : Int = 0

    loop.breakable{
        while(true){
            println(f"b is now $lb%d")
            lb +=1

            if(lb > 15) loop.break()
        }

        // this will not work since the break statement brings the control outside the breakable object;
        while(true){
            println(f"b is now $lb%d")
            lb += 1

            if(lb > 30) loop.break()
        }
    }

    println("\n\nNested Breaks in Scala")

    var outerLoop = new Breaks
    var innerLoop = new Breaks
    val numList1o = List(1,2,3,4,5)
    val numList2o = List(11,12,13)

    outerLoop.breakable {
        for( ao <- numList1o){
            println( "Value of a: " + ao )

            innerLoop.breakable {
                for( bo <- numList2o){
                    println( "Value of b: " + bo )

                    if( bo == 12 ){
                        innerLoop.break
                    }
                }
            } // inner breakable
        }
    } //
}
