package topics.basics

object _7_pafsAndRecursion extends App {

    import java.util.Date
    import scala.annotation.tailrec
    /*
        Partially Applied Functions

        These are use when we want to invoke functions with partial arguments
     */

    // For example,
    // we have

    def log(date : Date,msg : String) : Unit = {
        println(s"$date ------ $msg")
    }

    // val date = new Date
    // log(date, "message1")

    // Thread.sleep(1000)
    // log(date, "message2")

    // Thread.sleep(1000)
    // log(date, "message3")

    // /* Instead of this we can just do this */

    // val PAF = log(new Date : Date, _ : String);
    // PAF("message1")

    // Thread.sleep(1000)
    // PAF("message2")

    // Thread.sleep(1000)
    // PAF("message3")


    /*
      RECURSION -> Call of a function over and over again by itself

      The jvm on which scala runs keeps a call stack to remember the intermediate results and each call of the function results in a stack frame
     */

    //Example
    def fact(n : Int) : Int = {
        if(n <= 2) n

        else n * fact(n-1)
    }

    //This is a recursion function(a tail recursive function since the recursive call is the last expression of its call stack)
    // But computing factorials of large numbers will be a problem due to the maximum stack depth limitations so we need to write code in a
    // smart way

    def betterFact(n : BigInt) : BigInt = {
        @tailrec
        def factorialHelper(t : BigInt, accumulator : BigInt) : BigInt = {
            if(t <= 1) accumulator

            else factorialHelper(t-1,accumulator * t)
        }

        factorialHelper(n,1)
    }

    betterFact(10)
    betterFact(5000)
}
