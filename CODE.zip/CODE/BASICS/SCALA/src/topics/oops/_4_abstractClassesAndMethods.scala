package topics.oops


/* Classes which contain some unimplemented methods or fields are class as abstract classes */

object _4_abstractClassesAndMethods extends App {
        /*
            We create abstract classes with in-complete implementations because we want the child classes to implement these -> meant to be extended later

            We cannot instantiate an abstract class
         */
        abstract class Animal {

            val creatureType: String
            def eat : Unit
        }

        // val animal = new Animal // Animal cannot be instantiated

        // Any class that is extending an abstract class has to implement all the abstract methods and field or be declared abstract itself
        class Dog extends Animal{
            override val creatureType: String = "kanine"
            def eat: Unit = println("Bork Bork") // here the override keyword is not needed as the compiler can infer that the eat method is abstract and needs to be overridden

        }


        /*
            Traits -> They are like abstract classes but can be inherited along with classes
         */

        trait Carnivore{
            def eat(animal : Animal) : Unit
        }

        trait ColdBlooded{
            def bodyTemp() : Unit = println("I am cold blooded")
        }

        // we can add multiple traits using the with keyword like as example:
        class Crocodile extends Animal with Carnivore with ColdBlooded{

            val creatureType: String = "Croc"

            def eat: Unit = println("Nom Nom")

            def eat(animal: Animal): Unit = println(s"I am a Crocodile and I am eating a ${animal.creatureType}.")
        }

        val dog = new Dog
        val croc = new Crocodile

        croc.eat(dog)

        //Traits vs Abstract classes

        /*
            Both traits and abstract classes can contain abstract and non abstract members

            1. Traits cannot have constructors parameters
            2. Multiple traits may be inherited by a single class unlike other classes
            3. traits are generally chosen to represent behaviours while abstract class represent -> "a thing"
         */
    }

