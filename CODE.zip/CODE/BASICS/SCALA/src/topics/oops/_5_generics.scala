package topics.oops

/* Collections in scala are a powerful tool used to hold things of a certain type but if we want to make a collection for everytime we might
    have to duplicate the code for everytime but the Generics class in scala solves those problems */

object _5_generics extends App {

    // We can declare a generic class in scala using the syntax
    class MyList[A]{
        // now we can use the type A inside this class
    }

    val intList = new MyList[Int]
    // or
    val strList = new MyList[String]

    // we can use declare traits of generic type as such
    trait exampleOfGenericTrait[A] {

    }

    // we can also make generic methods but NOT GENERIC OBJECTS
    object MyList{
        def empty[A] : MyList[A] = new MyList[A]
    }

    // Now we can call this method using
    val newEmptyIntList = MyList.empty[Int]

    /*
        VARIANCE PROBLEM
     */

    class Animal
    class Cat extends Animal
    class Dog extends Animal

    // Now we know that Cat extends Animal but does a List Of Cat also extends a List of Animal
    // There are three answers to this

    /* 1. YES, List[Cat] extends List[Animal] -> COVARIANCE, we do this by using the +A keyword which means this is a covariant list */
    class CovariantList[+A]
    val animalList : CovariantList[Animal] = new CovariantList[Cat]

    //but after this we know that animalList is a list of Cats but can we add any other animal to it, DOING THIS WOULD POLLUTE THE LIST
    // animalList.add(new Dog) -> this is polluting the list


    /* 2. NO, LIST OF CATS AND LIST OF ANIMAL ARE DIFFERENT TYPES -> INVARIANT LIST */
    class invariantList[A]
    // val animalList2 : invariantList[Animal] = new invariantList[Cat] // -> this is an error saying that the types don't match

    /* HELL NO!! , CONTRAVARIANT LIST */
    class ContravariantTrainer[-A]
    val trainer : ContravariantTrainer[Cat] = new ContravariantTrainer[Animal]

    // completely opposite relation, not really useful for lists but things like the above where a trainer of AAnimals can also train cats
    // can be used in these types of situations


    /* BOUNDED TYPES - we can define what types to accept by a generic class or method <: -> class and sub classes , >: -> class and super classes */

    class Cage[A <: Animal]{}

    val cage = new Cage[Animal]
    val cage2 = new Cage[Cat]
    // val caf = new Cage[MyList[Int]] // -> gives error

    /*
        NOW WITH THE USE OF BOUNDED TYPES WE CAN SOLVE THE QUESTION OF DOG IN A CAT LIST i.e, the problem discusses in the part 1 of the answer
        to the variance problem, we can do this using the upper bound and lower bounds provided in the generics class definition
     */


    class BetterMyList[+A]{

        // in this method we are saying that if we get any super class element of class A we will turn the List to a more generic type of 'A'
        def add[B >: A](element : B) : BetterMyList[B] = ???
    }
}
