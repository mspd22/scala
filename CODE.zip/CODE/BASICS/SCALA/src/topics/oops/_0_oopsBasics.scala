package topics.oops

/* Class definitions can sit on the top level code */
object _0_oopsBasics extends App {
    val obj1 = new Person("John",20)
    println(obj1)

    println(obj1.x)

    /* Since the class body contains a side effect everytime you create a new instance of the class the side effect is executed */

    obj1.greet("Doe")
    // Here println(obj1.age) -> 20 will not work since class parameters are not class members or filed


}

class Person(name : String, val age : Int){
    // class body is contained between the {}
    // SO age is a class member now

    /*
        The class definition also acts as code block so the side effects inside the class body will be evaluated and calculated
     */

    val x = 10

    def greet(name : String) : Unit = println(f"${this.name}%s says : Hi $name%s") // this can be used with parameters as well as fields

    println("This is a side effect due to the fact that the Person class is now taking this expression as a value")
}
/*
    Unlike the other languages in Scala class parameters are not class members
    SO DOING SOMETHING LIKE object.member will not resolve the instance of that attribute/field
    TO convert class parameters into class members we can use the val or var keyword before the parameters in the class signature
 */

/* Method overloading and Constructor Overloading is supported in Scala */