package topics.oops

/* Useful for building lightweight data holding classes and an exceptional solution for defining companions classes and objects */


object _7_caseClasses extends App {
    /*
        Using the case keyword does the following

        1. class parameters are made into fields
        2. Sensible toString
        3. equals and hashcode implemented by default
        4. cases classes have handy copy methods
        5. cases classes have companion objects -> they have the factory methods also defined
        6. case classes are serializable -> very useful in akka frameworks
        7. case classes have extractor patterns and can be used in pattern matching
     */
    case class Person(name : String, age : Int){

    }

    val jim = new Person("JIM",20)
    println(jim.name)

    println(jim.toString)
    // OTHER FORM OF SYNTACTIC SUGAR -> println(jim) equivalent to println(jim.toString())

    val otherJim = new Person("JIM",20)
    println(jim == otherJim)
    val jim2 = jim.copy(age = 45)
    println(jim2)

    println(jim == jim2)

    val mary = Person("Mary",25)
    println(mary)

    /*  CASE OBJECTS */

    case object UK{
        // they are the same as case classes except the fact that they do not have a companion object
    }
}
