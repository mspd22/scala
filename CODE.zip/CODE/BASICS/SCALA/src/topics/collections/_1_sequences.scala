package topics.collections

import scala.util.Random

object _1_sequences extends App {

    /*
        SEQUENCES - DENOTED BY SEQ
            A vey general interface for data structures that
                - have a well-defined order
                - and can be indexed

            trait SEQ[+A]{
                def head : A
                def tail : SEQ[A]
            }

            Supports various operations:
                - apply, iterator, length, reverse for indexing and iterating
                - concatenation, appending, prepending
                - a lot of others: grouping, sorting, zipping, searching, slicing
     */

    val aSequence = Seq(1,2,3,4)
    println(aSequence)
    // if we print it, we see that it is a List. This is because the seq companion object actually has
    // an apply factory method that construct subclasses  of Seq but the declared type of seq is Seq[Int] here.

    println(aSequence.reverse)
    println(aSequence(2))
    println(aSequence ++ Seq(5,6,7))
    println(aSequence.sorted)

    /*
        RANGES - Also a Seq
     */

    val aRange : Seq[Int] = 1 to 10
    aRange.foreach(println)

    (1 to 10).foreach(x => println("This is another way to use Ranges"))


    /*
        LIST -

        sealed abstract class List[+A]
        case object Nil extends List[Nothing]
        case class ::[A](val hd : A, val tl : List[A]) extends List[A]

        A LinearSeq immutable linkedList
            - head, tail, isEmpty methods are fast O(1)
            - most operations are O(n): length, reverse

        Sealed - has Two Sub types
            - object Nil (Empty)
            - class ::
     */

    val aList = List(1,2,3,4)
    val prepended = 42 :: aList
    val appended = aList :+ 42
    val newList = 42 +: aList :+ 43

    println(prepended)
    println(appended)
    println(newList)

    val apples5 = List.fill(5)("apple")
    println(apples5)

    println(aList.mkString("This is a List : [","-","]"))

    /*
        ARRAY -

        final class Array[T] extends java.io.Serializable with java.lang.Cloneable

        The equivalent of simple java arrays
            - can be manually constructed with predefined lengths
            - can be mutable(updated in place)
            - are interoperable with Java's T[] Arrays
            - indexing is fast
     */

    val numbers = Array(1,2,3,4)
    val threeElements = Array.ofDim[Int](3)

    println(threeElements)
    threeElements.foreach(println) // Some default value will be provided for the array

    numbers(2) = 0 // This is actually a syntactic sugar for numbers.update(2,0)
    println(numbers.mkString(sep = "-"))

    val numberSeq : Seq[Int] = numbers // numbers is an array which is direct mapping over java's array
    // the seq can still hold it and the conversion happens
    // this is called an implicit conversion

    println(numberSeq)


    /*
        VECTORS -

        final class Vector[+A]

        The default implementation for immutable sequences
            - effectively constant indexed read and write : O(log_base32(n))
            - fast element addition: append/prepend
            - implemented as a fixed-branched trie(branch factor of 32)
            - good performance for large sizes
     */

    val vector : Vector[Int] = Vector(1,2,3)

    /*
        Vectors vs List

        Advantage of List: keeps reference of tail
        Disadvantage of List: Updating an element in the middle takes a lot of time

        Advantage of Vector: Depth of tree is small
        Disadvantage of Vector: Needs to change a small chunk when modifying
      */

    val maxRuns = 1000
    val maxCapacity = 1000000
    def getWriteTime(collection : Seq[Int]) : Double = {

        val r = new Random
        val times = for {
            it <- 1 to maxRuns
        } yield {
            val currentTime = System.nanoTime()
            collection.updated(r.nextInt(maxCapacity), r.nextInt())
            System.nanoTime() - currentTime
        }

        times.sum * 1.0 / maxRuns
    }

    val testList = {1 to maxCapacity}.toList
    val testVector = {1 to maxCapacity}.toVector

    println("\n\n---Testing---")
    println(getWriteTime(testList))
    println(getWriteTime(testVector))

    /* THIS IS WHY A VECTOR IS THE DEFAULT IMPLEMENTATION OF A SEQUENCE */
}