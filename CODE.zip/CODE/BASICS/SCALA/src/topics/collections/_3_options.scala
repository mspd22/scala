package topics.collections

import scala.util.Random

object _3_options extends App {

    /*
        OPTIONS - A special type of collection in scala which solve the billion-dollar mistake of Tony Hoare

        The billion-dollar mistake refers to the invention of the null pointer reference

        val string : String = null
        println(string.length) ->  Null pointer Exception

        Writing checks for these leads to spaghetti code

        An option is a Wrapper for a value that might be present or not

        sealed abstract class Option[+A]
        case class Some[+A](x : A) extends Option[A]
        case object None extends Option[Nothing] -> A singleton for abstract values
     */

    val myFirstOption : Option[Int] = Some(4)
    val noOption : Option[Int] = None

    println(myFirstOption)

    // To deal with unSafe API's

    def unSafeMethod() : String = null
    //val result = Some(unSafeMethod()) // -> Never do this as it is same as Some(null)

    // Instead
    val result = Option(unSafeMethod()) // -> Some or None
    println(result)

    /* NEVER DO NULL CHECKS BY OURSELVES OPTIONS DO IT FOR US */

    /*
        CHAINED METHODS
     */
    def backUpMethod() : String = "A valid Result"
    val chainedMethod = Option(unSafeMethod()).orElse(Option(backUpMethod()))

    /*
        While Designing API's
            - When we are designing unsafe API's we can return options
     */

    def betterUnSafeMethod : Option[String] = None
    def betterSafeMethod : Option[String] = Some("A Valid Result")

    val betterChainedMethod = betterSafeMethod orElse betterUnSafeMethod

    /*
        FUNCTION ON OPTIONS
     */

    println(myFirstOption.isEmpty)
    println(myFirstOption.get) // -> DO NOT USE THIS AS IT WILL THROW A NULL POINTER EXCEPTION(THE THING WE WANT TO AVOID WHEN ACCESSING NONE OPTION

    // map , flatMap, Filter
    println(myFirstOption.map( _ * 2))
    println(myFirstOption.filter(x => x > 10))
    println(myFirstOption.flatMap(x => Option(x * 10)))

    println("\n\n\n---EXERCISES---")
    // for comprehensions

    /*
        EXERCISES -

            1. GIVEN CONFIG - // try to establish a connection and if you are able to print the connect method
     */

    // Q1
    val config : Map[String, String] = Map(
        "Host" -> "176.45.36.1",
        "port" -> "80"
    ) // This configuration file was fetched from somewhere else, and you do not have the clarify whether the keys contain any value or not

    class Connection {
        def connect = "Connected"
    }

    object Connection {

        val random = new Random(System.nanoTime())
        def apply(host : String, port : String) : Option[Connection] = {
            if (random.nextBoolean()) Some(new Connection)
            else None
        }
    } // This is a safe method

    val host = config.get("host")
    val port = config.get("port")

    /*
        if(host != null)
            if(port != null)
                return Connection.apply(host,port)
         else null
     */
     val connection = host.flatMap(h => port.flatMap(p => Connection.apply(h,p)))

    /*
        if(c != null)
            return c.connect
        else null
     */
    val connectionStatus = connection.map(c => c.connect)

    /* if(connectionStatus == null) print(None) else print(Some(connectionStatus.get)) */
    println(connectionStatus)

    /*
        if status != null print(status)
     */
    connectionStatus.foreach(println)

    // Shorthand for this

    config.get("host")
        .flatMap(h => config.get("port")
         .flatMap(p => Connection(h,p))
         .map(connection => connection.connect))
    .foreach(println)

    // for comprehensions

    val forConnectionStatus = for {
        host <- config.get("host")
        port <- config.get("port")
        connection <- Connection(host,port)
    } yield connection.connect

    forConnectionStatus.foreach(println)
}
