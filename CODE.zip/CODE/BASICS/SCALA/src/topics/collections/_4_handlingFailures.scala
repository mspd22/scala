package topics.collections
import scala.util.{Try,Success,Failure}

object _4_handlingFailures extends App {

    /*
        Try - A wrapper for a computation that might fail
            - designing since multiple try catch blocks and nested blocks can make the code very unreadable

        sealed abstract class Try[+a]
        case class Failure[+T](t : Throwable) extends Try[T]
        case class Success[+T](value : T) extends Try[T]
     */

    // Ways to use Try is by - Create Success and Failure implicitly

    val aSuccess = Success(3)
    val aFailure = Failure(new RuntimeException("Super Failure"))

    println(aSuccess)
    println(aFailure)

    //THE OTHER WAY IS TO
    def unsafeMethod() : String = throw new RuntimeException("No String For You")

    val potentialFailure = Try(unsafeMethod())
    println(potentialFailure)

    // Syntactic Sugar
    val anotherPotentialFailure = Try {
        // code that throw another failure here
    }

    // utilities
    println(potentialFailure.isSuccess)
    println(potentialFailure.isFailure)

    // Or else
    def backUpMethod() : String = "A Valid Method"

    val fallbackTry = Try(unsafeMethod()).orElse(Try(backUpMethod()))
    println(fallbackTry)


    /*
        IF YOU DESIGN API
     */

    def betterUnSafeMethod() : Try[String] = Failure(new RuntimeException())
    def betterSafeMethod() : Try[String] = Success("A valid Result")

    val betterFallBackTry = betterSafeMethod() orElse betterUnSafeMethod()
    println(betterFallBackTry)


    // filter, map and flatmap same as options
    println(aSuccess.filter( _ > 10))
    println(aSuccess.map( _ * 10))
    println(aSuccess.flatMap(x => Success(x * 10)))

    /*
        EXERCISE
     */

    // same as the options one
}
