package topics.collections

object _2_tuplesAndMaps extends App {

    /*
        Tuples - finite ordered Lists
            - Tuples can group at-most 22 elements of different Types
     */

    val aTuple = new Tuple2(2,"Hello World") // Tuple2[Int, String] = (Int,String)
    println(aTuple)
    println(aTuple._1) // to access the first element
    println(aTuple.copy(_2 = "Goodbye java"))
    println(aTuple.swap)


    /*
        Maps - A key Value pair

        Insertion is done through one of the following methods
            1. Use a Tuple
            2. Use the -> notation
     */

    val aMap : Map[String, Int] = Map()


    val phoneBook = Map(("Jim" , 555), "Daniel" -> 789)
    println(phoneBook)

    // Map operations

    println(phoneBook.contains("Jim"))
    // println(phoneBook.contains("Mary")) // This will crash the program since "Mary" is not a Key
    // SO we can use the withDefaultValue Method when we are declaring a map as
    //  val phoneBook = Map(("Jim" , 555), "Daniel" -> 789).withDefaultValue(-1)

    // This will make it such that if any unKnown Key is called it returns -1

    // ADD A PAIRING
    val newPairing = "Mary" -> 234
    println(newPairing)
    val newPhoneBook = phoneBook + newPairing
    println(newPhoneBook)

    // FUNCTIONALS ON MAP -> map, flaMap, filter

    //maps
    println(newPhoneBook.map(pair => pair._1.toLowerCase -> pair._2))

    //filterKeys
    println(newPhoneBook.filterKeys(x => x.startsWith("J")))

    // map Values
    println(newPhoneBook.mapValues(number => "0245 -" + number))

    // conversions to other collections
    println(newPhoneBook.toList)
    println(List("Daniel" -> 983).toMap)

    val names = List("Jim","Angela","Mary","Bob","Daniel","James")
    println(names.groupBy(name => name.charAt(0)))
}
