package topics.collections

object _0_collections extends App {

    /*
        SCALA OFFERS BOTH MUTABLE AND IMMUTABLE COLLECTIONS

        -> WE ARE USING THE IMMUTABLE COLLECTIONS BY DEFAULT
            - type List[+A] = immutable.List[A]
     */

    /*
        Immutable Collections

                                        Traversable
                                            |
                                            |
                                            |
                                  ______ Iterable ______
                                 /          |           \
                                /           |            \
                               /            |             \
                              /            SEQ             \
                             /              |               \
                            /               |                \
                  HashSet  /                |                 \     HashMap
                      \   /                 |                  \    /
                       > SET                |                  MAP <
                      /                     |                       \
                  SortedSet                 |                      SortedMap
                                            A
                                           / \
                                          /   \              Queue __   __ Stack
                     Range               /     \                     \ /
                       |                /       \                     v
       String ----- IndexedSeq ---------         --------- LinearSeq <
                       |                                              A
                     Vector                                          / \
                                                            List  __/   \__ Stream




     */

    /*
        Mutable Collections

                                        Traversable
                                            |
                                            |
                                            |
                                  ______ Iterable ______
                                 /          |           \
                                /           |            \
                               /            |             \
                              /            SEQ             \
                             /              |               \
                            /               |                \
                  HashSet  /                |                 \     HashMap
                      \   /                 |                  \    /
                       > SET                |                  MAP <
                      /                     |                       \
                  LinkedHashSet             |                      MultiMap
                                            A
                                          / | \
                                         /  |  \
                                        /   |   \
                                       /    |    \
                   IndexedSeq ---------   Buffer  --------- LinearSeq------ LinkedList
                       /\                  / \                  |
                      /  \                /   \                 |
                     /    \              /     \                |
                    /      \            /       \           MutableList
                   /        \          /         \
                String       ArrayBuffer        ListBuffer
                Builder
     */

    /*
        TRAVERSABLE : Mother of all collections

        Provides many methods such as:
            maps        : map, flatMap, collect
            conversions : toArray, toList, toSeq
            size info   : isEmpty, size, nonEmpty
            tests       : exists, forall
            folds       : foldLeft, foldRight, reduceLeft, reduceRight
            retrieval   : head, find, tail
            string ops  : mkString
     */
}
