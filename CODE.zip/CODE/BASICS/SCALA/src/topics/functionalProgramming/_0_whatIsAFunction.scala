package topics.functionalProgramming

object _0_whatIsAFunction extends App {

    /*
        Use and Work with functions as first class elements -> Problem is we come form a OOP based paradigm

        The jvm was originally designed for Classes and Objects so to simulate functional programing was to
        use instances of classes or objects

        To use the function we either had to create an instance or use anonymous classes
     */
    trait MyFunction[A,B] {
        def apply(element : A) : B
    }

    val doubler = new MyFunction[Int,Int] {
        override def apply(element: Int): Int = element * 2
    }

    println(doubler(10))

    /* This is the closest we can get to actual functions using oop*/

    /*
        SCALA actually supports these function definitions using the Function1, 2, .... 22 function types

        Function1 = one parameter and one result
     */

    val stringToIntConvertor = new Function1[String,Int] {
        override def apply(v1: String): Int = v1.toInt
    }

    println(stringToIntConvertor("3") + 10)

    /*  By default, SCALA defines these function types up to 22 parameters*/

    val adder : Function2[Int,Int,Int] = new Function2[Int,Int,Int]{
        override def apply(a : Int, b : Int) : Int = a + b
    }

    // THE SAME CAN BE WRITTEN AS

    val betterAdder : (Int, Int) => Int = new ((Int,Int) => Int){
        override def apply(a : Int, b : Int) : Int = a + b
    }

    println(adder(10,20) == betterAdder(10,20))

    // FUNCTION TYPES Function2[A, B, R] === (A,B) => R

    /* ALL SCALA FUNCTIONS ARE OBJECTS OR INSTANCES OF CLASSES DERIVING FROM FUNCTION TYPES */

    /*
        Exercise 1:  A function to concatenate two strings
     */

    val stringConcatenation : (String, String) => String = new ((String,String) => String){
        override def apply(v1: String, v2: String): String = v1 + v2
    }

    println(stringConcatenation("Hello", " World!"))

    /*
        Exercise 3: Implement a function which takes an int as a parameter and returns another function
            which also takes an int as a parameter
     */

    //Using closure
    def add(element : Int) : Int => Int ={
        def helper(adder : Int) : Int = {
            element + adder
        }
        helper
    }

    val adderInception = add(10)
    println(adderInception(10))

    //different approach

    val add2 : Int => (Int => Int) = new (Int => (Int => Int)){
        override def apply(a: Int) : Int => Int = new (Int => Int){
            override def apply(b: Int): Int = a + b
        }
    }

    val adderInception2 = add2(10)
    println(adderInception2(30))

    /*
        This is called a curried Function -> They have the property that they can be called with
        multiple parameter lists
     */
}
