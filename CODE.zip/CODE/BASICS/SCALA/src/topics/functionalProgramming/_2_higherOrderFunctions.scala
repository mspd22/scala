package topics.functionalProgramming

import scala.annotation.tailrec

object _2_higherOrderFunctions extends App {

    /*
        What stops use from writing such functions
     */

    val ultimateFunction : (Int, (String, (Int => Boolean)) => Int) => (Int => Int) = null // null just to avoid not-implemented exception

    // THESE TYPES OF FUNCTIONS WHICH TAKE OR RETURN ANOTHER FUNCTION ARE CALLED HOF

    // A function which will take three arguments
    //      1. A function which will apply the transformation
    //      2. The number of times the transformations has to take place
    //      3. The subject of the transformation

    // nTimes(f,n,x) => f(f(f( ...... x    .....))) n-times =  nTimes(f,n-1,x)

    def addOne : Int => Int = _ + 1

    @tailrec
    def nTimes(f : Int => Int, n : Int, x : Int) : Int = {

        if(n < 1) x

        else nTimes(f,n-1,f(x))
    }

    println(nTimes(addOne,10,1))

    // Instead of actually passing all the values at once we can instead use a function definition which will apply the function
    //  n times and after which we can pass the actual operand

    def betterNTimes(f : Int => Int, n : Int) : (Int => Int) ={
        if(n < 1) (x : Int) => x

        else (x : Int) => betterNTimes(f,n-1)(f(x))
    }

    val plus100 = betterNTimes(addOne,100)
    println(plus100(0))

    // Here we are calling the betterNTimes function n-1 times total which will give a HOF of f(f(f....) n-1 times,
    // which will then be performed on a value provided by f(x) in the first iteration
    // SO it is like doing
    /*
        First Iteration  : f'(f(x))
        Second Iteration : f'(f(f(x))
        Third Iteration  : f'(f(f(f(x)))

        etc..,

        that is we are building the functions on the outside while taking the value to be performed upon will be
        placed on the inside from the start
     */


    /*
        CURRIED FUNCTIONS
     */

    val superAdder : Int => (Int => Int) = (x : Int) => (y : Int) => x + y
    val add10 = superAdder(10) // 10 + y

    println(add10(100))

    //FUNCTIONS WITH MULTIPLE PARAMETERS LISTS

    def curriedFormatter(c : String)(x : Double) : String = c.format(x)
    val standardFormat : (Double => String) = curriedFormatter("%4.2f")
    val preciseFormat : (Double => String) = curriedFormatter("%10.8f")

    println(standardFormat(Math.PI))
    println(preciseFormat(Math.PI))
}
