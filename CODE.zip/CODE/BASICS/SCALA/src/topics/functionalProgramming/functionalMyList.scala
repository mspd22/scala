package topics.functionalProgramming

/*
    @params
    HEAD - the first node of the list
    tail - the rest of the list

    @methods
    isEmpty() - > Checks to see if the list is empty or not
    add(int) - > Adds a new element to the list
    toString - > Return a string representation

    @advancedMethods
    map(transformer) : CustomList
    filter(predicate) : CustomList
    flatMap(transformer) : CustomList
 */

abstract class CustomList[+A] {

    def head : A
    def tail : CustomList[A]
    def isEmpty : Boolean
    def add[B >: A](element : B) : CustomList[B]

    def printElements : String
    override def toString: String = "[ " + printElements + "]"

    // map, filter and flatMap

    /*
        Here we will write map[B] because we need to be aware of the type we are converting the list into i.e B
     */
    def map[B](transformer : A => B) : CustomList[B]
    def flatMap[B](transformer: A => CustomList[B]) : CustomList[B]
    def filter(myPredicate : A => Boolean) : CustomList[A]

    // helperFunctions

    def ++[B >: A](list : CustomList[B]) : CustomList[B]


    // AFTER HOFS

    def foreach(f : A => Unit) : Unit

    def sort(compare : (A,A) => Int) : CustomList[A]

    def zipWith[B,C](list : CustomList[B],zip : (A, B) => C) : CustomList[C]

    def fold[B](start : B)(operator : (B,A) => B) : B
}

class Cons[+A](headElement : A,tailList : CustomList[A]) extends CustomList[A]{

    def head : A = headElement
    def tail : CustomList[A] = tailList
    def isEmpty: Boolean = false
    def add[B >:A](element: B): CustomList[B] = new Cons(element,this)

    def printElements: String = headElement + " " + tailList.printElements

    // map, filter and flatMap

    override def filter(myPredicate: A => Boolean): CustomList[A] = {
        if(myPredicate(headElement)) new Cons(headElement,tailList.filter(myPredicate))

        else tailList.filter(myPredicate)
    }

    override def map[B](transformer : A => B) : CustomList[B] = {
        new Cons(transformer(headElement),tailList.map(transformer))
    }

    override def flatMap[B](transformer: A => CustomList[B]): CustomList[B] = {
        transformer(headElement) ++ tailList.flatMap(transformer)
    }

    //

    def ++[B >: A](list : CustomList[B]) : CustomList[B] = new Cons(headElement, tailList ++ list)

    // FLATMAP, MAP AND FILTER USING ANONYMOUS FUNCTIONS

    val betterFilter : (A => Boolean) => CustomList[A] = (myPredicate : A => Boolean) =>{
        if(myPredicate(headElement)) new Cons(headElement,tailList.filter(myPredicate))

        else tailList.filter(myPredicate)
    }

//    val betterMap : (A => B) => CustomList[B] = transformer =>{
//        new Cons(transformer(headElement),tailList.map(transformer))
//    }

    // AFTER HOFS

    override def foreach(f: A => Unit): Unit = {
        f(headElement)
        tailList.foreach(f)
    }

    override def sort(compare: (A, A) => Int): CustomList[A] = {

        def insert(a: A, sortedList: CustomList[A]) : CustomList[A] ={

            if(sortedList.isEmpty) new Cons(a, Empty)

            else if (compare(a, sortedList.head) <= 0) new Cons(a,sortedList)

            else new Cons(sortedList.head,insert(a,sortedList.tail))
        }

        val sortedTail = tailList.sort(compare)
        insert(headElement,sortedTail)
    }

    override def zipWith[B, C](list: CustomList[B], zip: (A, B) => C): CustomList[C] = {
        if(list.isEmpty) throw new RuntimeException("Lists Do Not Have Same Length")

        else new Cons(zip(headElement,list.head),tailList.zipWith(list.tail,zip))
    }

    override def fold[B](start: B)(operator: (B, A) => B): B = tailList.fold(operator(start,headElement))(operator)
}

object Empty extends CustomList[Nothing]{

    def head: Nothing = throw new NoSuchElementException("No List present")
    def tail: Nothing = throw new NoSuchElementException("No List Present")
    def add[B >: Nothing](element: B): CustomList[B] = new Cons(element,Empty)
    def isEmpty: Boolean = true
    override def printElements : String = ""

    // filter, map and flatMap

    def map[B](transformer : Nothing => B) : CustomList[B] = Empty
    def flatMap[B](transformer: Nothing => CustomList[B]) : CustomList[B] = Empty
    def filter(myPredicate: Nothing => Boolean) : CustomList[Nothing] = Empty

    //

    def ++[B >: Nothing](list : CustomList[B]) : CustomList[B] = list

    // AFTER HOFS

    override def foreach(f: Nothing => Unit): Unit = ()

    override def sort(compare: (Nothing, Nothing) => Int): CustomList[Nothing] = Empty

    override def zipWith[B, C](list: CustomList[B], zip: (Nothing, B) => C): CustomList[C] = {

        if(!list.isEmpty) throw new RuntimeException("List Do Not Have Same Length")

        else Empty
    }

    override def fold[B](start: B)(operator: (B, Nothing) => B): B = start
}

object functionalMyList extends App{

    val newList = new Cons(1, new Cons(2, new Cons(3, new Cons(4, Empty))))
    val stringList = new Cons("a", new Cons("b", new Cons("c", new Cons("d",Empty))))

    println(newList.head)
    println(newList.toString)

    val newerList = newList.add(10)

    println(newerList.filter(new (Int => Boolean){
        override def apply(element : Int) : Boolean = element%2 == 0
    }).toString)

    println("AFTER HOFS")
    newerList.foreach(println)

    println(newerList.sort((x ,y) => y - x))

    println(newList.zipWith[String,String](stringList, _ + "-" + _))

    for {
        n  <- newerList
    } print(n + " ")

    println()

    val checking = for {
        n <- newerList
        x <- stringList
    } yield n + "-" + x

    println(checking)
}


// FOR THE COMPILER TO CREATE AND USE FOR COMPREHENSIONS THE MAP,FILTER AND FLATMAP FUNCTIONS MUST HAVE SPECIAL SIGNATURES

// map(f : A => B) => list[B]
// flatMap(f : A => MyList[B]) => myList[B]
// filter( f : A => Boolean) => MylIst[A]
