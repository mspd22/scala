package topics.functionalProgramming

object _3_mapFlatMapFilterFor extends App {

    // Official List and methods from scala libraries

    val list = List(1,3,4)
    println(list.head)

    // filter
    println(list.filter(x => x % 2 == 0))

    // map
    println(list.map(_ + 10))
    println(list.map(_ + " is a Int"))

    //flat map
    println(list.flatMap((x : Int) => List(x * 2, x * 4)))

    /*
        EXERCISE PRINT ALL COMBINATIONS
     */

    val numbers = List(1,2,3,4)
    val chars = List('a','b','c','d')

    println(numbers.flatMap(n => chars.map(c => "" + c + n)))

    val colors = List("White","Black")

    println(numbers.flatMap(n => chars.flatMap(c => colors.map(color => "" + c + n + "-" + color))))

    // foreach - same-same

    // for-comprehensions

    val forCombinations = for {
        n <- numbers if n % 2 == 0 // it is like writing a filter before the flatmap
        c <- chars
        color <- colors
    } yield  "" + c + n + "-" + color

    println(forCombinations)

    // for can also be written as

    for {
        n <- numbers
    } println(n)

    //SYNTAX OVERLOAD
    list.map{ x =>
        x*2
    }

    /*
        EXERCISES -
            1. check whether our custom list supports for comprehensions
            2. create a new collection of at-most one element - maybe[+T] -> Empty or A collection of one element
     */


}
