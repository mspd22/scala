package topics.functionalProgramming

object _1_anonymousFunctions extends App {

    /*
        Now we can use function types, but instantiating an object to create a function is still
        very much like object-oriented
     */

    val doubler = new (Int => Int){
        override def apply(v1: Int): Int = v1 * 2
    }

    println(doubler(10))

    /*
        This can also be written as the following due to syntactic sugar notations
     */

    // This is called an anonymous function or a lambda
    // you can also get rid of the type annotation in the function
    val betterDoubler : Int => Int = (x : Int) => x * 2
    println(betterDoubler(10))

    /*
        If we used the type annotation for the function as such:
            val betterDoubler : Int => Int
         then we can also do this

            val betterDoubler : Int => Int = x => x * 2
     */

    //Multiple Parameters:

    val fun2 : (Int, Int) => Int = (a : Int, b : Int) => a * b
    println(fun2(10,20))


    // No Params

    val fun3 : () => Int = () => 10
    // Here we have to use the () because in the above case we are writing
    //  val betterDoubler : Int => Int = x => x * 2
    // Here we are providing the parameters or arguments even if we declare the type annotation
    // So We cannot write
    //    val fun4 : () => Int = 10
    // This will not work, but we can again write this
    val fun4 = () => 10


    /*
        NOW WE ARE MORE USED TO CALLING METHODS WITHOUT THE PARENTHESIS BUT LAMBDAS MUST BE CALLED WITH PARENTHESIS
     */
    println(fun3)
    println(fun3())


    /*
        LAMBDAS WITH CURLY BRACES Notation
     */
    val stringToInt = { (str: String) =>
        str.toInt
    }


    /*
        MORE SYNTACTIC SUGAR
     */
    val niceAdder : Int => Int = _ + 1 // equivalent to x => x + 1
    val nicerAdder : (Int, Int) => Int = _ + _

    /*
        Exercise
     */

    // Question : Convert this to lambda expressions
    val add2 : Int => (Int => Int) = new (Int => (Int => Int)){
        override def apply(a: Int) : Int => Int = new (Int => Int){
            override def apply(b: Int): Int = a + b
        }
    }

    /*
        val answer : Int => (Int => Int) = (a : Int) => (b : Int) => a + b
        val answer : Int => (Int => Int) = a => b => a + b
        val answer : Int => (Int => Int) = a => a + _
     */
    val answer : Int => (Int => Int) = a => a + _
    println(answer(100)(20))
}
