package project.com.beginner.scala.oop.fileSystem

import project.com.beginner.scala.oop.files.Directory

/*
    @params
        root = The root Directory
        wd = Working Directory
        output = The output of the previous state if any at all
    @Definitions
        Contains the current state of our system
 */
class State(val root : Directory, val wd : Directory, val output : String) {

    def show() : Unit = {
        println(output)
        print(State.SHELL_TOKEN)
    }

    /*
        @params
            message = a message through which we can find the current state or output
     */
    def setMessage(message : String) : State = State(root, wd, message)
}

object State {
    private val SHELL_TOKEN = "$ "

    /*
        Same as State class above, and we are following the practise where we will create methods to create new instances
     */
    def apply(root : Directory, wd : Directory, output : String = "") : State = {
        new State(root = root,wd =  wd,output = output)
    }
}