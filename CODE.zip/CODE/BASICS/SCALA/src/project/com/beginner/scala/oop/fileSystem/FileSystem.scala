package project.com.beginner.scala.oop.fileSystem

import project.com.beginner.scala.oop.commands.Command
import project.com.beginner.scala.oop.files.Directory

import java.util.Scanner

object FileSystem {

    val root = Directory.ROOT
    var state = State(root, root) // one of the few places where you would need to use vars'
    private val scanner = new Scanner(System.in)

    while(true){
        state.show()
        val input = scanner.nextLine()
        state = Command.from(input).apply(state)
    }

    scanner.close()
}
