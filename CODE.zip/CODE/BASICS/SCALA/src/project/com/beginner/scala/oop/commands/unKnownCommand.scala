package project.com.beginner.scala.oop.commands

import project.com.beginner.scala.oop.fileSystem.State

/*
    A FAILSAFE COMMAND WHICH IS USED WHEN ALL OTHER COMMANDS CANNOT
 */
class unKnownCommand extends Command{
    override def apply(state: State): State = state.setMessage(s"${unKnownCommand.UKC}")
}

object unKnownCommand {
    val UKC = "Command Not Found"
}