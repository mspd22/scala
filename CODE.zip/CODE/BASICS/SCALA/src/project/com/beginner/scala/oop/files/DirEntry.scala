package project.com.beginner.scala.oop.files

abstract class DirEntry(val parentPath : String, val currDirName : String) {

    /*
        @params: None

            this is an instance call, so it will get the values according to its current instance
        @definition: It will return the complete path of the current working directory or the directory instance calling it
     */
    def getPath : String = parentPath + Directory.SEPARATOR + currDirName
}
