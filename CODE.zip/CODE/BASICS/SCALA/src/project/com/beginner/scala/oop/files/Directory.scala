package project.com.beginner.scala.oop.files

class Directory(override val parentPath: String, override val currDirName: String, val contents : List[DirEntry])
    extends DirEntry(parentPath, currDirName) {

    def hasEntry(dirName : String) : Boolean = ???

    /*
        We are going to get all the directories in the path to our wd

        example: /1/2/3/4 = ["1", "2", "3", "4"]
     */
    def getAllFoldersInPath : List[String] = getPath.substring(1).split("/").toList

    def findDescendant(path : List[String]) : Directory = ???
}

/*
    It is beneficial that we use methods to create new instances instead of directly hard coding them
 */

object Directory {

    val SEPARATOR = "/"
    val ROOT_PATH = "/"

    /*
        @params : parentPath = Path of the Parent Directory
                  dirName = Name of the Directory we are creating
                  contents = List of files and Directories present in the new created Directory
        @Definition : A method to create a new Director
     */
    def createNewEmptyDir(parentPath: String, dirName: String): Directory = new Directory(parentPath = parentPath, currDirName = dirName, contents = List())


    /*
         @Params : None
         @definition : Creates a Root Directory and returns it

         A special Function of crNewEmptyDir
     */
    def ROOT : Directory = Directory.createNewEmptyDir("","")
}
