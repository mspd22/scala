package project.com.beginner.scala.oop.commands

import project.com.beginner.scala.oop.fileSystem.State
/*
    Commands have the property to change the state of the system from one state to another state
 */
trait Command {
    def apply(state : State) : State
}

object Command {

    /*
        CONSTANTS
     */
    val SPACE_SPLITTER = " "
    val MKDIR = "mkDir"


    /*
        METHODS
     */

    /*
        @params: None
        @definition:
            Just same state is returned
     */
    def emptyCommand() : Command = new Command {
        override def apply(state: State): State = state
    }

    /*
        @params:
            commandName : Name of the command given with incomplete instructions

           @definitions : gives an error message saying that the command provided is incomplete
     */
    def inCompleteCommand(commandName : String) : Command = new Command {
        override def apply(state: State): State = state.setMessage(s"In complete Command : $commandName")
    }

    /*
        @params:
            input : String = the input command or string given to the state shell
        @definition:
            the method extracts the command to be performed

        The input string is split into parts based on spaces and each of the parts is used to compare and check which command to use
     */
    def from(input : String) : Command = {

        val tokens: Array[String] = input.split(SPACE_SPLITTER)

        if(input.isEmpty || tokens.isEmpty) emptyCommand()

        else if (MKDIR.equals(tokens(0))){
            if(tokens.length < 2) inCompleteCommand(MKDIR)

            else new MkDir(tokens(1))
        }

        else new unKnownCommand
    }
}