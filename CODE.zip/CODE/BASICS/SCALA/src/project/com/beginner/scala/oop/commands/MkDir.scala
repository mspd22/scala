package project.com.beginner.scala.oop.commands

import project.com.beginner.scala.oop.fileSystem.State
import project.com.beginner.scala.oop.files.Directory

class MkDir(dirName : String) extends Command {

    /*
        @params : state = The current state of the system
        @definitions :
            Making the function to create new Directories in our file system
     */


    override def apply(state: State): State = {

        val wd = state.wd

        if(wd.hasEntry(dirName)) state.setMessage(s"Entry $dirName already exists in $wd")

        else if(dirName.contains(Directory.SEPARATOR)) state.setMessage(s"$dirName Must not contain Separators")

        else if(checkIllegalName(dirName)) state.setMessage(s"$dirName : Illegal Entry Name")

        else doMkDir(state, dirName)
    }

    /* Just checking for illegal characters in the name provided to the shell */
    def checkIllegalName(dirName: String): Boolean = dirName.contains(".")

    /* The main logic function of the MkDir functionality */
    /*
        @params:
            state : The current state of the file system
            dirName : The name of the directory we are supposed to create
     */
    def doMkDir(state: State, dirName: String) : State ={
        /*
            We will now recursively break down and update each instance of the parent path directories

        case 1:
            /a
                /b
                /c
                add new d

            => new /a
                /b
                /c
                new /d


        case 2:
            /a/b
                /c
                new d

            => new /a new /b
                        /c
                        new /d
         */
//        def updateStructure(currentDirectory: Directory, path : List[String], newEntry: Directory) : Directory = {
//
//        }

        val wd = state.wd
        /*
            1. Get all the directories in the full path
            2. Create New Directory entry in the wd
            3. Update the whole directory structure starting from the root
            // REMEMBER THE DS IS IMMUTABLE - CREATE NEW DS FOR EVERY MODIFICATION
            4. Find the new working directory instance given wd's full path, in the new Directory structure
         */

        //Step 1
        val allDirsInPath : List[String] = wd.getAllFoldersInPath

        //step 2
        val newDir = Directory.createNewEmptyDir(wd.getPath,dirName)

        //step 3
//        val newRoot = updateStructure(state.root, allDirsInPath, newDir)

        //step 4
//        val newWd = newRoot.findDescendant(allDirsInPath)

//        State(newRoot, newWd)

        state
    }
}
