public class _0_Basics {

	/*

		Hadoop consists of two main components -> HDFS and MapReduce
			1. HDFS -> Where the data is stored in a distributed format.
			2. Map Reduce -> Where we have jobs which perform the transformations on the data using java. This is done by using distributed processing on HDFS.

		Now if we want to perform a JOIN query we need to write java code in MR. We need a SQL layer

		So we have
                                 Hive -> SQL(Query Engine)
                                 MR -> CORE engine for all transformation
		                        HDFS -> Data Store

		Hive => It is a query engine but saying it is a Database is not wrong. But it does not store data by itself it uses HDFS for data management.
		        It is an abstraction of MR. It uses MREngine internally to process the query. So we will write SQL code to interact with Hive instead of Java.
		        The output is again stored in HDFS.

		        While capable of doing most of the work in Hive, we still might require spark or MR to perform some complex or large queries/jobs.


		Working Of Hive => {

		    1. A Hive server is present in the system you have downloaded Hive.
		    2. We need to interact with Hive using the CLI.
		    3. Create - When we send a request through CLI, the request does to the Hive server. The Hive server will then create some metadata which will contain information
		    about the table but not the data itself. This metadata is different from that stored in Name Node.
		    4. This metadata is stored in the RDBMS database(Oracle, DB2, MySQL) -> Only metadata.
		    5. The data itself is stored in HDFS.
		    6. Insert/Load - When we send a request to store or insert data into Hive it will get the metadata information from the RDBMS and uses that info to store the new records
		    in a table in HDFS.
		    7. Select - Query the metadata info, and then it will query the HDFS table and show it in a row wise format.

		}

		    - If we do not have a RDBMS in our system and only installed Hive then Hive itself has an internal RDBMS database, an embedded database, DERBY. External RDBMS are called as
		    Remote Metastore.

		    - If we use embedded metadata then there will be problems with distributed processing. A single remote metastore is better. We can configuration file to make then use the remote
		    datastore.

	    */

        /*

            Some basic Commands in Hive(SQL)

            1. show databases; -> Show all the databases which are present in the Hive server.
            2. Create database name;
            3. use database_name;
            4. show tables;
            5. create table database.name_of_table{ };
                using database name to access the table is preferred because when we use an HQL file to perform a large number of queries,
                there can be cases when we forget to mention the database from where we want to modify the table from, in which case Hive
                will use the default `database`

                Example:
                    create table test.emp
                    (
                        sno int,
                        city string,
                        usr_name string)
                        ROW FORMAT delimited fields terminated by ',' LINES TERMINATED BY '\n' STORED AS TEXTFILE;

                Here we are asking to store as text file and when we are trying to load data we will be using new line for each record and
                comma for each value in a record. That is what the above line is specifying. This is used when we are using load command.

            6. 'load data' is used for loading a large amount of data into the Hive system.
                - `load data local inpath "path_to_data" into test.emp` -> Used for local system to Hive
                - `load data inpath "Path_to_data" into test.emp`  -> Used for HDFS to Hive

           !!!!!! -> MapReduce job is triggered only for aggregation functions.
           !!!!!! -> By default all the Hive table are stored in HDFS in the path "/usr/hive/warehouse/"

           HDFS FS => {
                In HDFS the test database is stored as a directory.
                The emp table is stored as a directory.
                The loaded files are stored in the directory of each table.
                We can also directly place any file into the directory of the table using HDFS commands instead of HIVE commands.
           }

           7. desc table;
           8. desc extended table; -> Even more details
           9. show functions

         */

        /*

            Internal Vs External fTables in Hive

            We will use the keyword EXTERNAL after table when we want to create an external table.

            1. When we create the table both of them will be stored in the /usr/hive/warehouse/ directory
            2. When we drop an internal table the table will be completed deleted along with the data in it. The record of the table is also erased from
            the warehouse folder.
            3. But when we try to do this with an External table, it will not be erased from the warehouse folder.
                - When an internal table is dropped, Hive will delete metastore data and the table data completely from HDFS.
                - But when an external table is dropped then only the structure and the table is dropped but not the data.
            4. ACID tables in Hive must be internal. Otherwise, use only external tables. !!!!!!!!!
            5. We can reuse or recreate the same table and reuse the data. Since the data is already present there and only the structure was lost, once we
            redefine the structure in Hive we can query the data again form HDFS.
        */
}
