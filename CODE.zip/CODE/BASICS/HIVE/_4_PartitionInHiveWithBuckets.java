public class _4_PartitionInHiveWithBuckets {

    /*
        - Avoid Full Scan.

     */
}
