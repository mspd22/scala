public class _1_Partitions {

    /*
          Partitioning => {

            Used for better searching. Division of data based on specific conditions.

            There are two types of partitions in Hive
                1. Static Partitions - Specified by user at time of insertion
                2. Dynamic Partitions - Automatically handled by Hive

            By default, Hive follows Static partitioning.

            Static Partitioning => {
                Syntax:
                    A partition table

                    create table test.user_data
                    (
                        sno int,
                        usr_name string
                    ) partitioned by (city string);

                - The disadvantage of creating a static partition table is that we cannot use the load command to store data into it.
                - We can only use the `insert into` and the `insert overwrite` because using the load command will not trigger an MR job.
                - Only when the MR job is trigger will the correct data be placed into the correct partitions. So the only way to lead large
                amounts of data into a partition table is to use a non-partition table to hold the data temporarily and then use it to insert
                data into the partition table.

                - Example: insert into test.user_data partition (city="chennai") select sno, usr_name from user_data_no_partition where city = "chennai";
                     This will take all the data under the city of 'chennai' and then put that data into the "chennai" partition of the partitioned table.

                !!!!!!
                - We can use the "show partitions table_name" to show all the partitions created for that table.
                - In HDFS for each partition we create a directory is created and that particular data is stored in it.
                !!!!! Here it will be like /usr/hive/warehouse/test/emp/city=chennai
            }

            Dynamic Partitioning => {

                - By default Hive only allows static partitioning, but we can set up dynamic partitioning using the "set hive.exec.dynamic.partition.mode=nonstrict"

                - The syntax for table creation is the same, but we will just execute the above set command.

                create table test.user_data_dynamic
                    (
                        sno int,
                        usr_name string
                    ) partitioned by (city string);

                insert into test.user_data dynamic (city) select sno, usr_name, city from user_data_no_partition where city = "chennai";

            }
         }
     */
}
