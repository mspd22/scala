public class _3_ACIDTables {

    /*
        - Hive was predominantly used for OLAP(Online Analytical Processing) and used to have only inserts but no updates.
        - But later Hive added ACID - Atomicity, Consistency, Integrity and Durability.
        - So Hive became OLTP

        Creating An ACID Table => {

            Four Rules:
            1. Internal Table has to be used.
            2. It has to be a bucketed table.
            3. It has to be in orc file format
            4. Transaction = True has to be enabled.

        }

        Insert
        Update
        Select
        Delete
     */

    /*
        ORC File Format => {
            - Optimised Row Columnar

            Some File formats used in Hive => {
                1. Original encoded with Text
                2. RCFile - 14% smaller
                3. Parquet - 62% smaller
                4. ORCFile - 78% smaller
            }

            - One of the advantages of using ORC file format is that it compresses efficiently to redice space used.
            - Another advantage is that it uses the columnar format which arranges columns adjacent within the file for compression
            and fast access. - Faster Queries

            - When we create a table with ORC, we cannot use the load command.
        }
     */
}
