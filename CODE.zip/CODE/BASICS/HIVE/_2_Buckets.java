public class _2_Buckets {

    /*
        Buckets => {

           - Used for distributing data.
           - Data Sampling
           - Map Side Joins

           Configuration Needed => {
                1. set hive.exec.dynamic.partition=true;
                2. set hive.exec.partition.mode=nonstrict;
                3. set hive.enforce.bucketing = true;
           }

           !!!!! We cannot use load command with partitioned or bucketed table. We can only use insert into or insert overwrite

           We will create a normal table and load the data into that temporarily and then use the insert into command to insert the
           data into the dynamic or bucket table.

           Creating a Bucket Table => {
                CREATE TEMPORARY TABLE test_data)
                    sno int,
                    name string,
                    amt int )
                    ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' STORED AS TEXTFILE;

                load data local inpath '/path/to/data' into table test_data;


                CREATE TABLE bk_test_data(

                    sno int,
                    name string,
                    amt int )
                    COMMENT 'This can be done to provide more information about why the table is created'
                    CLUSTERED BY (amt) INTO 3 BUCKETS
                    STORED AS TEXTFILE;

               insert into table bk_test_data
           }

           - The difference between buckets and partitions is that in partitions we will define how to distribute the data but in buckets
           Hive does that for us.

           Internal Selection of Bucket => {

                - Hive decides which record will go to which bucket by using the HashPartition algorithm.

                HashPartition = hash_of_bucketed_column % num_of_buckets
                The hash_of_bucketed_column is calculated using some hashing algorithm.

                The modulus will decied where to palce that particular record.
                - We can find the buckets in HDFS like 0000-0, 0000-1, 0000-2 etc.,..
           } !!!! If we want to override the selection algorithm, then we can use the concepts of partitions.

           Why Bucket is Used => {

                - Partitioning can only work if there exists atleast one attribute which is duplicated for some records for example country, age, amount etc.
                - But if there exist no attribute in a table that contains duplicate values then partitioning is not possible, hence we need to use buckets to
                distribute the data for better performance.
                - When querying we can calculate the HashPartition again and use it to find the required bucket and only search in that bucket
                instead of performing a full scan.
           }
        }
     */

    /*
        Bucket Count => {

            - Do not use a random cut for the number of buckets. Since the incorrect bucket count will make the program inefficient and slow.

            So we will use a formal for selecting the bucket count.

            Params:
                1. Table Size - If new, then trial the table for some time to get an estimate
                2. Block Size - Block size of HDFS

                3. temp_avg_num_blocks = table_size/block_size

                4. n : Find n such that 2^n >= temp_avg_num_blocks
                5. After finding n ; 2^n will be the number of buckets

            - This method requires that we change the bucket count whenever our table size is increased, but choosing the bucket count
            using the above method will ensure that the number of changes to be minimal.
        }

        - We can use insert overwrite to insert into a new table since we cannot change the bucket count once a table is created.
        - Drop the original table after the data is inserted into the new table.
        - Then rename the new table to the old table to finish the process.
     */
}
