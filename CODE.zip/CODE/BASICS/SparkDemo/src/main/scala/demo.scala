package spark.demo

import org.apache.spark.sql.SparkSession

object demo extends App {

    val spark =
        SparkSession.builder()
        .appName("SparkDemo")
        .master("local[*]")
        .getOrCreate()

    println("Spark Session is created")

    spark.close()
}
