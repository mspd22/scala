package spark.demo

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, row_number, year}
import org.apache.spark.sql.{Column, DataFrame, SparkSession, functions}

object _5_testingCode{
    def main(args : Array[String]) : Unit = {
        val spark =
            SparkSession.builder()
            .appName("Tester Build")
            .master("local[*]")
            .getOrCreate()

        val df =
            spark.read
            .option("header", value = true)
            .option("inferSchema", value = true)
            .csv("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/data/AAPL.csv")

        df.show()
        df.printSchema()

        val renameList : List[Column] = List(
            col("Date").as("date"),
            col("Open").as("open"),
            col("High").as("high"),
            col("Low").as("low"),
            col("Close").as("close"),
            col("Adj Close").as("adjClose"),
            col("Volume").as("volume")
        )

        val stockData = df.select(renameList : _*)

        highestClosingPricePerYear(stockData)

    }

    def highestClosingPricePerYear(df: DataFrame): DataFrame = {

        import df.sparkSession.implicits._
        val window = Window.partitionBy(year($"date").as("Year"))

        df
        .withColumn("max_close", functions.max($"close").over(window))
        .where($"close" === $"max_close")
        .drop("max_close")
    }


    def add(x : Int, y : Int) : Int = x + y
}


