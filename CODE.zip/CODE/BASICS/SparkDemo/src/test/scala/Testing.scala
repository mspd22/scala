package spark.demo

import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{Encoder, Row, SparkSession}
import org.apache.spark.sql.types.{DateType, DoubleType, StructField, StructType}
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.must.Matchers.contain
import org.scalatest.matchers.should.Matchers.convertToAnyShouldWrapper

import java.sql.Date

class Testing extends AnyFunSuite{

    test("First Unit Test"){
        val res = _5_testingCode.add(2, 3)
        assert(res ==  5)
    }

    val spark = SparkSession.builder().appName("First Test").master("local[*]").getOrCreate()

    private val schema = StructType(Seq(
        StructField("date", DateType, nullable = false),
        StructField("open", DoubleType, nullable = false),
        StructField("close", DoubleType, nullable = false)
    ))

    test("First DataFrame Test"){

        val testRows = Seq(
            Row(Date.valueOf("2022-01-12"), 1.0, 2.0),
            Row(Date.valueOf("2023-03-01"), 1.0, 2.0),
            Row(Date.valueOf("2023-01-12"), 1.0, 3.0)
        )

        implicit val encoder : Encoder[Row] = RowEncoder(schema)
        val testDf = spark.createDataset(testRows)

        val actualRows = _5_testingCode.highestClosingPricePerYear(testDf)
                .collect()

        val expectedRows = Seq(
            Row(Date.valueOf("2022-01-12"), 1.0, 2.0),
            Row(Date.valueOf("2023-01-12"), 1.0, 3.0)
        )

        actualRows should contain theSameElementsAs expectedRows
    }

}
