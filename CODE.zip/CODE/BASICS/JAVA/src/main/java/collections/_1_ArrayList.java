package collections;

import java.util.ArrayList;

public class _1_ArrayList {
    public static void main(String[] args) {

        /*
            ArrayList - A dynamic array of variable size

            Syntax:
                ArrayList<DataType> name = new ArrayList<DataType(optional)>(initialCapacity);

            - For datatypes we cannot use primitives, we can only use wrapper classes
         */

        ArrayList<Integer> vec = new ArrayList<>();

        vec.add(1);
        vec.add(23);
        vec.add(1434);
        vec.add(344);
        vec.add(86);
        vec.add(154);
        vec.add(326);
        vec.add(9765);
        vec.add(345);

        System.out.println(vec); // [1, 23, 1434, 344, 86, 154, 326, 9765, 345]
        System.out.println(vec.contains(344));
        vec.set(0, 99);
        System.out.println(vec);

        // Normal Indexing will not work here.
        for (int i = 0; i < vec.size(); i++) {
            System.out.print(vec.get(i) + " ");
        }
        System.out.println();

        // Using for-each loop
        for (Integer i : vec) {
            System.out.print(i + " ");
        }
        System.out.println();

        // Using for-each loop with lambda expression
        vec.forEach(i -> System.out.print(i + " "));
        System.out.println();

        /*
            We can define an initial size for the ArrayList, but it will not be fixed.
            The size will be increased automatically when the number of elements exceeds the initial size.
            Internally when the ArrayList is filled with some amount of elements, a new List is created in the Memory with
            a larger size than before and with the help of the `System.arraycopy()` method, the elements are copied to the
            new List. The old List is then deleted and the new List is assigned to the reference variable.
            The initial size is just a hint to the JVM to allocate that much space in the heap.

            This happens in constant time O(1) because the JVM uses a technique called "amortized analysis" to
            ensure that the average time complexity of adding an element to an ArrayList is O(1). This means that even though
            the worst-case time complexity of adding an element to an ArrayList is O(n) (when the array needs to be resized),
            the average time complexity is still O(1) because the resizing operation is infrequent and the cost is spread out
            over many insertions.

         */


        // Multi-Dimensional ArrayList
        ArrayList<ArrayList<Integer>> vec2D = new ArrayList<>();

        // We have to initialise the list first, before we can populate them.
        for(int i = 0;i<3;i++) vec2D.add(new ArrayList<Integer>());

        vec2D.get(0).add(1);
        vec2D.get(0).add(2);
        vec2D.get(0).add(3);
        vec2D.get(1).add(4);
        vec2D.get(1).add(5);
        vec2D.get(1).add(6);
        vec2D.get(2).add(7);
        vec2D.get(2).add(8);
        vec2D.get(2).add(9);

        for (ArrayList<Integer> i : vec2D) {
            System.out.print(i + " ");
        }
        System.out.println();


    }
}
