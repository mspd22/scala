package collections;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

public class _0_Arrays {
    public static void main(String[] args) {

        /*
            Arrays - Store a group of a single dara type. Unlike c/c++ whether the array data is continuous or not depends
            on the JVM. Because Heap objects are not continuous.

            Syntax: dataType []name_of_array = new dataType[size]
                                or
                    dataType name_of_array[] = new dataType[size]
         */

        int []arr = new int[5];
        // An array of 5 integer

        /*

        int []ex; // Declaration of the Array -> ex is defined in the stack space.
        ex = new int[5]; // Here the object is being created in the Heap Memory

            - ex points to the memory space in the heap

            - The `new` keyword is used for creating the object in heap.
        */


        System.out.println(arr[0]); // default of integer is 0

        String []strArr = new String[2];
        System.out.println(strArr[0]); // default value of String or any reference type is null

        /*
        null - A special literal of null type(none in python)

            - It is not a value or anything and cannot be assigned to primitives

            - We cannot use it as a datatype

            - Any reference variable will have the default value of null
         */

        // Input using for-loops
        int nums[] = new int[100];
        for(int i = 0;i < nums.length; i++){
            nums[i] = i*i;
        }

        System.out.println();
        /*
            ENHANCED FOR LOOP

            SYNTAX : for(data_type itr : iterable)
                     {
                        operations on itr
                     }
         */
        for(int ele : nums){
            System.out.print(ele + " ");
        }
        System.out.println();

        // toString
        System.out.println(Arrays.toString(nums));


        /*
            Array of Objects
                - An array of objects will contain the reference variables of the objects and the actual objects themselves will
            be present in some other part the memory.

            - In java there is only call by reference, so when objects are passed a copy of their reference variable is passed through
            the function
         */
        System.out.println("\n\nBefore pass_by_ref");
        System.out.println(Arrays.toString(nums));
        pass_by_ref(nums);
        System.out.println("\nAfter");
        System.out.println(Arrays.toString(nums));


        /*
            Multi-Dimensional Arrays

                - Array of Arrays
                - The first dimension is the number of rows and the second dimension is the number of columns
                - Each index of the array contains an array
                - In a 2-D array, the number of rows is mandatory but columns is optional
                - Individual array size inside may differ
         */

        int [][] arr2D = {
                {1,2,3,4},
                {5,6},
                {7,8,9}
        };
        System.out.println("\n 2D Array");
        for(int[] arr1D : arr2D){
            for(int ele : arr1D){
                System.out.print(ele + " ");
            }
            System.out.println();
        }
    }


    public static void pass_by_ref(int @NotNull [] ref){
        ref[0] = 100;
    }
}
