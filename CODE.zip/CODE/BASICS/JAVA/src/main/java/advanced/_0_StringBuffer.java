package advanced;

import java.util.Scanner;

public class _0_StringBuffer {
    public static void main(String[] args) {

        /*
            String Buffer
                - A mutable sequence of characters
                - It is used to create a string that can be modified.

            Advantages
                - It is faster than String because it is mutable.
                - It is used when we need to create a string that can be modified.
                - It is efficient for string manipulation.
                - It is thread-safe

           Disadvantage
                - It is slower

         */


        // Constructor Type 1
        StringBuffer sb = new StringBuffer();
        sb.append("Hello");
        System.out.println(sb); // Hello

        String str = sb.toString();
        System.out.println(str); // Hello

        // Constructor Type 2
        StringBuffer sb2 = new StringBuffer("Hello");

        // Constructor Type 3
        StringBuffer sb3 = new StringBuffer(30);

        // Some Methods
        sb.append(" World");
        System.out.println(sb); // Hello World

        sb.insert(5,",");
        System.out.println(sb);

        sb.replace(1,5,"abc"); // 1 to 4 - 5 not inclusive
        System.out.println(sb);

        // Creating a Random String of length n
        System.out.print("ENTER A NUMBER: ");
        Scanner input = new Scanner(System.in);

        int n = Integer.parseInt(input.nextLine());

        StringBuffer randomString = new StringBuffer();
        for (int i = 0; i < n; i++) {
            char randomChar = (char) ('a' + Math.random() * 26);
            randomString.append(randomChar);
        }
        System.out.println("Random String: " + randomString);
    }

}
