package advanced;

import java.util.Arrays;

public class _2_Generics {
    public static void main(String[] args) {

        /*
            Generics
                - Generics is a feature of Java that allows you to create classes, interfaces, and methods with a placeholder
                for the type of data they operate on. This allows for type safety and code reusability.
                - Generics are used to create classes, interfaces, and methods that can operate on any type of data.

        */

        MyArrayList list = new MyArrayList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        System.out.println(list); // MyArrayList{vec=[1, 2, 3, 4, 0, 0, 0, 0, 0, 0], size=4}
        System.out.println(list.get(2)); // 3
        System.out.println(list.remove(1)); // 2

        System.out.println("Size of List is : " + list.Size());
        // But this is not the actual size of the container
        // It is the size of the array that is used to store the elements
        // So we need to create a method to get the actual size of the container
        System.out.println("Actual Size of List is : " + list.getRealSize());

        // When we add more elements then
        for(int i = 0;i<10;i++){
            list.add(i+3);
        }

        System.out.println("\n--After Adding some more Elements--");
        System.out.println("Size of List is : " + list.Size());
        System.out.println("Actual Size of List is : " + list.getRealSize());

        /*
            We can make better custom lists using Generics
         */
        BetterCustomList<Integer> betterVec = new BetterCustomList<>();

        betterVec.add(1);
        for(int i = 0;i<32;i++){
            betterVec.add(i+1);
        }
        System.out.println(betterVec); // MyArrayList{
        // vec=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 21, 32
        System.out.println("\n--After Adding some more Elements--");
        System.out.println("Size of List is : " + betterVec.Size());
        System.out.println("Actual Size of List is : " + betterVec.getRealSize());



    }
}

// A Custom class for a custom ArrayList without using Generics
// This class only supports int data type
class MyArrayList {

    private int[] vec;
    private int size;
    private final static int DEFAULT_SIZE = 10;

    public MyArrayList() {
        vec = new int[DEFAULT_SIZE];
        size = 0;
    }

    public void add(int element) {
        if (size == vec.length) {
            resize();
        }
        vec[size++] = element;
    }

    public int get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return vec[index];
    }

    public int remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        int removedElement = vec[index];
        for (int i = index; i < size - 1; i++) {
            vec[i] = vec[i + 1];
        }
        size--;
        return removedElement;
    }

    public int remove(){
        if (size == 0) {
            throw new IndexOutOfBoundsException("Index: " + size + ", Size: " + size);
        }
        int removedElement = vec[size - 1];
        size--;
        return removedElement;
    }

    public void set(int index, int element) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        vec[index] = element;
    }

    public int Size() {
        return size;
    }

    public int getRealSize(){
        return vec.length;
    }

    private void resize() {
        int[] newElements = new int[vec.length * 2];
        System.arraycopy(vec, 0, newElements, 0, vec.length);
        vec = newElements;
    }

    @Override
    public String toString() {
        return "MyArrayList{" +
                "vec=" + Arrays.toString(vec) +
                ", size=" + size +
                '}';
    }
}

/*
    - We cannot instantiate a generic type directly. We have to use the Object class and type cast it during run time.

    - We also cannot use static members of type T because static members are accessible by all the objects of that class and
    each object can have different types of T. So we cannot use static members of type T.
    - We can use static members of type Object and type cast them during run time.
    - Method overloading of generic types is not allowed since the compiler will have no information about the datatype during run time.
    - We can use wildcards to allow for more flexibility in the types of data that can be used with generics.

 */

/*
    Wildcards
        - Wildcards are used to represent an unknown type in generics.
        - They are represented by the question mark (?) symbol.
        - They are used to allow for more flexibility in the types of data that can be used with generics.
        - There are three types of wildcards:
            1. Unbounded Wildcards
                - It is represented by the question mark (?) symbol.
                - It can be used to represent any type of data.
                - It is used when we do not care about the type of data.
            2. Bounded Wildcards
                - It is represented by the question mark (?) symbol followed by the extends keyword.
                - It can be used to represent a type that is a subclass of a specific class or interface.
                - It is used when we want to restrict the type of data to a specific class or interface.
            3. Lower Bounded Wildcards
                - It is represented by the question mark (?) symbol followed by the super keyword.
                - It can be used to represent a type that is a superclass of a specific class or interface.
                - It is used when we want to restrict the type of data to a specific class or interface.

            j
 */

//class BetterCustomList<T extends Number>
class BetterCustomList<T> {
    private Object[] vec;
    private int size;
    private final static int DEFAULT_SIZE = 10;

    public BetterCustomList() {
        vec = new Object[DEFAULT_SIZE];
        size = 0;
    }

    public void add(T element) {
        if (size == vec.length) {
            resize();
        }
        vec[size++] = element;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return (T) vec[index];
    }

    public T remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        T removedElement = (T) vec[index];
        for (int i = index; i < size - 1; i++) {
            vec[i] = vec[i + 1];
        }
        size--;
        return removedElement;
    }

    public T remove() {
        if (size == 0) {
            throw new IndexOutOfBoundsException("Index: " + size + ", Size: " + size);
        }
        T removedElement = (T) vec[size - 1];
        size--;
        return removedElement;
    }

    public void set(int index, T element) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        vec[index] = element;
    }

    public int Size() {
        return size;
    }

    public int getRealSize() {
        return vec.length;
    }

    private void resize() {
        Object[] newElements = new Object[vec.length * 2];
        System.arraycopy(vec, 0, newElements, 0, vec.length);
        vec = newElements;
    }

    @Override
    public String toString() {
        return "MyArrayList{" +
                "vec=" + Arrays.toString(vec) +
                ", size=" + size +
                '}';
    }

}