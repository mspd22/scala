package advanced;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

public class _1_BigNumbers {
    public static void main(String[] args) {

         /*
            Data Type to store large integers - BigInteger

            Object ---> java.lang.Number --> java.math.BigInteger extends Number implements Comparable<BigInteger>

            - It is used to perform arithmetic operations on large integers.
            - It is immutable, meaning once created, we cannot change the value of the BigInteger.
            - Range is from -2^Integer.MAX_VALUE to 2^Integer.MAX_VALUE (both exclusive)
          */

        // Creating a BigInteger
        BigInteger a = BigInteger.valueOf(33);
        BigInteger b = new BigInteger("446372823233332232323345236");
        // BigInteger c = new BigInteger("446372823233332232323345236", 2); // Binary
        // BigInteger d = new BigInteger("446372823233332232323345236", 16); // Hexadecimal

        // If we have a very large integer use String.
        BigInteger A = new BigInteger("19234567890123456789012345678901234567890");
        BigInteger B = new BigInteger("9876543210987654321098765432109876543210");

        // Arthmetic Operations
        System.out.println(A.add(B)); // Addition
        System.out.println(A.subtract(B)); // Subtraction
        System.out.println(A.multiply(B)); // Multiplication
        System.out.println(A.divide(B)); // Division
        System.out.println(A.remainder(B)); // Modulus
        System.out.println(A.pow(2)); // Power
        System.out.println(A.gcd(B)); // GCD
        System.out.println(A.compareTo(B)); // Compare
        // 0 if A == B
        // -1 if A < B
        // 1 if A > B

        /*
            Data type to store Big Floating Point Numbers

            BigDecimal => Same hierarchy as BigInteger
                - It is used to perform arithmetic operations on large floating point numbers.
                - It is immutable, meaning once created, we cannot change the value of the BigDecimal.
                - It is used to avoid the precision loss in floating point numbers as shown below.

                Precision loss happens due to their nature of representation in binary notation. Fractions are very complex to
                be represented in binary notation. So, the floating point numbers are represented in binary notation with a limited number of bits.

                - The precision of a floating point number is the number of digits in the number. For example, 0.1 has a precision of 1,
                - 0.01 has a precision of 2, and so on.
                - The precision of a BigDecimal is the number of digits in the number. For example, 0.1 has a precision of 1,
                - 0.01 has a precision of 2, and so on.

                - BigDecimal helps use give the exact precision.

                !!!!!!!!
                Range:
                It contains a random precision int unscaled value and 32-bit integer scale.
                value >= 0 Scale = Number of digits right of decimal point
                Otherwise -> unscale value = 10^-scale

         */
        double x = 0.04;
        double y = 0.03;
        System.out.println(x - y); // 0.010000000000000002 -> Loss in precision

        // Creating a BigDecimal
         BigDecimal DA = new BigDecimal("0.04");
         BigDecimal DB = new BigDecimal("0.03");

        // Arthmetic Operations
        System.out.println(DA.add(DB)); // Addition
        System.out.println(DA.subtract(DB)); // Subtraction
        System.out.println(DA.multiply(DB)); // Multiplication
        //System.out.println(DA.divide(DB)); // Division
        // Throws ArithmeticException: Non-terminating decimal expansion; no exact representable decimal result.
        System.out.println(DA.divide(DB, 2, RoundingMode.HALF_UP)); // Division with scale and rounding mode
        // It will return a BigDecimal with the specified scale and rounding mode.

        System.out.println(DA.remainder(DB)); // Modulus
        System.out.println(DA.pow(2)); // Power
        System.out.println(DA.compareTo(DB)); // Compare
        // 0 if A == B
        // -1 if A < B
        // 1 if A > B


    }
}
