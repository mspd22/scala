package oops.include;

public class Box {

    public double l;
    public double w;
    public double h;

    public Box(){
        this (-1);
    }

    public Box(double side){
        this(side, side, side);
    }

    public Box(double l, double w, double h) {
        this.l = l;
        this.w = w;
        this.h = h;
    }

    public Box(Box obj){
        this.l = obj.l;
        this.w = obj.w;
        this.h = obj.h;
    }

    public void information(){
        System.out.println("Running the Box");
    }
}
