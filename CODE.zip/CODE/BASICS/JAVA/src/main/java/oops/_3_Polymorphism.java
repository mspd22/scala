package oops;

public class _3_Polymorphism {
    public static void main(String[] args) {

        /*
            Polymorphism -> Of many forms
            It mostly occurs during inheritance.

            Act of representing in multiple ways.

            There are two types of Polymorphism
            1. Compile Time Polymorphism or Static Polymorphism
                - Method Overloading -> Same Name but different Method Signature including return types.
                E.g. Multiple Constructors
                - Operator Overloading - Not present in JAVA

            2. Run Time Polymorphism or Dynamic Polymorphism
                - Method Overriding
                E.g. Changing the Method definition of a child class during run time
         */

        /*
            During Method Overriding the child class method definition will get preference.

            How does java know -
                Java determines this by the process of dynamic method dispatch. The mechanism by which a call to an overridden
                method is resolved at run time rather than compile time. -> Late Binding
         */

        /*

            The final keyword is used for creating constants, but it can also be used for preventing methods from being
            overridden.

            This is done to prevent any byte code overhead involved with copying and resolving overridden methods at run time.
            -> Early Binding.

            It can also prevent inheritance by declaring a class final.
            By declaring a class as final, implicitly its methods are also considered as final.

            Static Methods are not Overridden.
         */
    }
}
