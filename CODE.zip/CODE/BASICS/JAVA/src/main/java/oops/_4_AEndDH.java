package oops;

public class _4_AEndDH {

    public static void main(String[] args) {

        /*
            Encapsulation -
                Wrapping up the implementation of the data members and methods in a class.
                Hides the core and data into a single entity and protect it from the outside world.

                Encapsulation is a fundamental concept in object-oriented programming where data and the methods that
                operate on that data are bundled together as a single unit. This unit, often a class, hides the internal
                state of the object from the outside world and only exposes a controlled interface for interacting with
                it. This protects the data from accidental modification and allows for easier maintenance and
                modification of the code.
         */

        /*
            Abstraction -
                Hiding the unnecessary details and showing only valuable details. You know what the element does, but you need
                not know it actually does the function nor do we need to know.

                E.g. Abstract Classes and Interfaces. We only care about the functionality rather than the implementation.
         */

        /*
            Data Hiding -
                Getters and Setters
         */
    }
}
