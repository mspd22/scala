package oops;

import oops.include.Box;

public class _2_Inheritance {

    /*
        Inheritance -
            Passing of attributes and behaviour

        A class(child) is said to be inherited/derived from another class(parent class) if the child class has access to
        attributes and methods of the parent class for its own use and modification.

        Child class will inherit using the `extends` keyword.

        The parent class will contain the more general or common attributes and behaviours specified. These can be
        directly used by the child classes, or they can be modified by the child classes specification.

        Parent class cannot access elements of the child class.
     */
    public static void main(String[] args) {

        Box box = new Box();
        System.out.println("Length : " + box.l + "\nWidth : " + box.w + "\nHeight : " + box.h + "\n\n");

        Cube cube = new Cube();
        System.out.println("--Cube 1--");
        System.out.println(cube.getInfo());

        Cube cube2 = new Cube(10);
        System.out.println("--Cube 12--");
        System.out.println(cube2.getInfo());

        Cube cube3 = new Cube(10,5);
        System.out.println("--Cube 3--");
        System.out.println(cube3.getInfo());


        Cube cube4 = new Cube(10,5,4,3);
        System.out.println("--Cube 4--");
        System.out.println(cube4.getInfo());

        // There is a special property in oops
        Box obj = new Cube(10,5,4,3);
//        System.out.println(obj.weight); -> Error
        // The above element is an object of the Cube type but the reference used is the Box type.
        // Here if we try to access the properties of the Cube class it will not be possible because it is the type of the
        // reference variable which determines the elements that can be accessed, not the type of the object created.


//        Cube c_b = new Box(5,4,3); -> Error
        // The above is also an error because when we create a Cube reference type then it would expect to have access all the
        // variables defined for the type Cube. In this case l, w, h and weight.
        // But here the constructor of the Box class will be called, since the object being created is of the Box type.
        // THIS WOULD MEAN THAT THE `WEIGHT` VARIABLE IS NOT CREATED WHICH CANNOT BE SINCE THE CUBE CLASS CONTAINS THE VARIABLE


    }
}

// We will create the class that is inheriting from Box in this file, but normally it will be better to declare it in its own file.
class Cube extends Box{

    double weight;

    // Based on the parameters provided the appropriate parent constructor is called. When creating a child class if there
    // is no constructor present by default then the parent class constructor is used based on the parameters given.
    Cube(){
        this.weight = -1;
    }

    Cube(double weight){
        this.weight = weight;
    }

    // We can explicitly call the constructor using the super keyword
    Cube(double weight, double side){
        super(side);
        this.weight = weight;
    }

    Cube(double weight, double len, double wid, double hei){
        super(len,wid,hei);
        this.weight = weight;
    }

    // This is allowed since we are passing a Cube object to a Box constructor and the Box constructor will have access to all
    // the required fields.
    Cube(Cube other){
        super(other);
        this.weight = other.weight;
    }


    String getInfo(){
        return "Length : " + this.l + "\nWidth : " + this.w + "\nHeight : " + this.h + "\nWeight : " + this.weight + "\n\n";
    }
}

/*
    Types of Inheritance

    1. Single Inheritance - One class derives another class

    2. Multi-level Inheritance - The child class of one parent class becomes the parent class of another child class

    3. Multiple Inheritance - A child class is inheriting from more than one parent class.
        Multiple Inheritance is not supported in JAVA due to ambiguity.

    4. Hierarchical Inheritance - A parent class is inherited by multiple child classes.

    5. Hybrid Inheritance - A combination of all the above.
 */