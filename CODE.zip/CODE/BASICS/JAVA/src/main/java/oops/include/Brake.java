package oops.include;

public interface Brake {

    void brake();
}
