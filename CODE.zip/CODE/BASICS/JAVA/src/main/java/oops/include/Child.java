package oops.include;

public class Child extends Parent{

    public Child(int age) {
        super(age);
    }

    // We have to provide the implementation of all the abstract methods declared in Parent, if not we have to declare
    // the current class as Abstract
    @Override
    public void A(String name) {
        System.out.println("I am going to be a " + name);
    }

    @Override
    public void B(String name) {
        System.out.println("Name is " + name + " Age is " + this.age);
    }

    @Override
    public void normal() {
        System.out.println("Normal Method from Child");
    }
}
