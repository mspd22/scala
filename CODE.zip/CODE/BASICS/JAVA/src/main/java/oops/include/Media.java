package oops.include;

public interface Media {

    void start();
    void stop();
}
