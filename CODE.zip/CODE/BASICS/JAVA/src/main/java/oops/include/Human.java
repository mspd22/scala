package oops.include;

public class Human {

    int age;
    String name;
    int salary;

    public static long population;

    public Human(String name, int age, int salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;

        Human.population += 1;
    }
}
