package oops.include;

/*
    A singleton class is a class where only one object creation is allowed.
 */
public class Singleton {

    // The constructor has to be called for an object to be constructed. Hence, if we make the constructor as `private`,
    // then the constructor cannot be called and hence the object cannot be created.
    private Singleton(){

    }

    // We will create the single instance ourselves and only pass that instance to any other object calling it.
    // So we will need to make it private for better access control and static since it is not dependent on any object of the class
    private static Singleton instance;

    // Now we will use a public method to distribute the instance.
    public static Singleton getInstance() {

        if( instance == null) instance = new Singleton();

        return instance;
    }
}
