package oops.include;

public abstract class Parent {

    public int age;

    // We can create constructor of a Parent class, but we cannot use it directly since we cannot create an object of
    // Parent type. They can only be used by the Child class constructors by calling the Super keyword.
    protected Parent(int age){
        this.age = age;
    }
    protected abstract void A(String name);

    protected abstract void B(String name);

    // Static Method
    static public void Hello(){
        System.out.println("Hello from Parent");
    }

    public void normal(){
        System.out.println("Normal Method from Parent");
    }

}
