package oops;
import oops.include.Child;
import oops.include.Parent;

public class _5_AbstractClasses{

    public static void main(String[] args) {

        /*
            Abstract Classes and Methods
                - Data abstraction is the process of hiding certain details and showing only essential information to the
                 user. Abstraction can be achieved with either abstract classes or interfaces.

            The abstract keyword is a non-access modifier, used for classes and methods:

                - Abstract class: is a restricted class that cannot be used to create objects (to access it, it must be
                   inherited from another class). An abstract class can have both abstract and regular methods

                - Abstract method: can only be used in an abstract class, and it does not have a body. The body is
                  provided by the subclass (inherited from).

                  Syntax: abstract void name(argumentList); -> No definition, only declaration


            Abstract classes must be inherited for them to have any use. And all the methods which are declared as abstract
            in the abstract class must be implemented in the child class which inherited it.

            Any class which contains an abstract method must be declared as abstract itself.
         */

        Child child = new Child(25);
        child.A("Coder");
        child.B("John");

        /*
            If we really want to create an object of an abstract class, then we need to create the implementations of all
            abstract methods when declaring it.

            Because if we do not provide the implementation of abstract classes, and we created an object and tried to
            access the methods, it will be a problem since the methods are not defined.
         */
        Parent obj = new Parent(25) {
            @Override
            protected void A(String name) {
                // Some implementation
            }

            @Override
            protected void B(String name) {
                // Some implementation
            }
        };

        /*
            - We cannot create abstract constructors.

            - we cannot create abstract static method, because static methods cannot be overridden so no way to implement
            the abstract methods in child classes.

            - We can create static methods in abstract classes

            - We can create non-abstract methods too in abstract classes.

            - We cannot use final with abstract classes or methods
         */

        // Static method
        Parent.Hello();

        // Normal Method in Parent
        obj.normal();

        // Normal Method in Child
        child.normal();

        /*
            Abstract classes cannot be used to make multiple Inheritance.
         */
    }
}
