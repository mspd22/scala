package oops; // Mention the package where the file is present in, has to be the first line in a file
// relative to the source folder

// We can use the import statement to specify which file to resolve the file contents from
import oops.include.Human;
import oops.include.Singleton;

public class _1_staticPackageMethodsSingleton {

    static int a;
    static int b;

    /*
        The static block can be used to initialise static variables and this static block is executed only once when the
        first object is created and class is loaded to memory for the first time.
     */
    static {
        System.out.println("I am in static block of main");
        a = 10;
        b = 20;
    }

    public static void main(String[] args) {

        /*
            Packages - Containers for storing classes.

            we cannot create two classes with the same name in the single package. Packages are used for resolving classes.
            They are just special folders or directories.
         */

        /*
            Static Keyword
         */

        Human obj1 = new Human("John",32,10000);
        Human obj2 = new Human("Jane",35,20000);

        // We have the population attribute for the Human class which should be same for all the Humans
        // Before static we get 1 and 1
        System.out.println(obj1.population);
        System.out.println(obj2.population);
        System.out.println(obj1);

        /*
            But we are getting 1 for both of them, i.e. instance  variables do not share memory between objects

            So we can use the `static` keyword to make population a class variable so that the same memory reference for all
            the objects.

            !!! We access static variables using the class name. We can also use the object instance but, it is better to use
            class name.

            This is because when we use obj.static the compiler will check the instance of the object but, it will not find
            the variable in an instance so it will check the class then where it will find it.
         */

        /*
            Static Methods and Static Members

                - A static method can only access static members. It cannot access non-static data without a proper reference.
                  This is because something that is not static belongs to a class and trying to access it without context is not possible.

                - SO we need to specify which instance it belongs to for using it.

                - Non-static methods can access Static methods since the reference is not really ambiguous.

                - `This` and `super` keyword cannot be used inside a static member.
         */

//        _1_staticSingletonPackageMethods.main(new String[1]); -> Will call the method recursively until stack overflow.

        System.out.println("value of a : " + _1_staticPackageMethodsSingleton.a);
        System.out.println("value of b : " + _1_staticPackageMethodsSingleton.b);

        /*
            Outer classes cannot be static due to the fact that outer classes do not depend on any other class to be referenced from.

            But inner classes can be static.

            In Java, when you have an inner class within an outer class, each instance of the outer class will have its
            own separate instance of the inner class. This means that if you create multiple instances of the outer class,
            each instance will have its own unique instance of the inner class. The inner class instances are tied to
            their respective outer class instances and are not shared between them.

            So when we try to access a non-static inner class from a static outer class it cannot find the reference to call
            the inner class from.

            So we need to make the inner class static.
            Here static does not mean that they won't have their individual identities, it means that they are not dependent
            on the objects of the outer class to get created.
         */


        Test a = new Test("John");
        Test b = new Test("Mark");

        System.out.println(a.name); // John
        System.out.println(b.name); // Mark


        /*
            Singleton classes
         */
        Singleton sobj1 = Singleton.getInstance();
        Singleton sobj2 = Singleton.getInstance();
        Singleton sobj3 = Singleton.getInstance();

        System.out.println(sobj1); // oops.include.Singleton@35f983a6
        System.out.println(sobj2); // oops.include.Singleton@35f983a6
        System.out.println(sobj3); // oops.include.Singleton@35f983a6
    }

    // Inner Class
    static class Test{

        String name;
        public Test(String name) {
            this.name = name;
        }
    }
}
