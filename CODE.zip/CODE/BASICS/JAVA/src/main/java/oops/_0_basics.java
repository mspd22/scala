package oops;

public class _0_basics {

    public static void main(String[] args) {

        /*
            Class -> A blueprint for creating objects.

            A Java class is a single, coherent unit of Java code which belongs together. A Java class may contain a mix
            of data (variables) and actions (methods).

            Java Class Building Blocks
            A Java class can contain the following building blocks:

            1. Fields
            2. Constructors
            3. Methods
            4. Nested Classes

                - Fields are variables (data) that are local to the class, or instances (objects) of that class.

                - Constructors are methods that initialize an instance of the class. Constructors often sets the values
                of fields in the given instance.

                - Methods are operations that the class or instances of that class can perform. For instance, a method
                 may perform an operation on input parameters, or change the value of fields kept internally in the object etc.

                - Nested classes are Java classes that are defined inside another class. Nested classes are typically
                intended to either be used only internally be the Java class that contains them, or to be used in connection
                 with the class that contains them.


            !!! Any file in java ending with the .java extension can only contain one public class definition.
         */

        /*
            Objects - AN instance of a class.

            While class is a logical construct, an object is a physical reality. This is the element which occupies the
            space in the memory and with which an application can interact with.

            Objects have some properties such as:
            1. State - A state of an object is defined by its current value of attributes.
            2. Identity - The physical memory reference.
            3. Behaviour - Defined by the methods present in the object.

            Instance Variables - The variables which are exclusive to a specific object instance.
            Reference Variables - The variable used to define an object.

            Creating an object - The new Keyword
                Student student -> Declaring a reference variable to the class Student, initially pointing to `null`

                Now we have to allocate memory for the object in memory, this is done using the `new` keyword.

                Student student = new Student(); -> Dynamic Memory Allocation i.e. it is being instantiated
                    ^               |
                    |               v
                compile time       runtime
         */

        Student obj = new Student(); // Will call the non parameterised constructor
        System.out.println(obj); // -> oops.Student@3cb5cdba
        System.out.println(obj.name); // Default -> null
        System.out.println(obj.rollNo); // Default -> 0
        System.out.println(obj.marks); // Default -> 90 since it is specified in class definition

        // Manipulating objects
        obj.rollNo = 22;
        System.out.println(obj.rollNo);

        /*
            Java Constructors

                Used for initialising values for the attributes of an object at the time of the creation of an object.

                The `.` operator is the access operator

                The constructor is a special type of function inside a class that runs when you create an object, and it will
                allocate some values. -> The by-default constructor.

                Having multiple constructors for a class with different signatures is called as constructor overloading
         */

        obj.greeting();


        /*
            The `new` keyword is used for allocating memory in the Heap memory
         */
    }
}

// Example of a class - Class names usually start with a capital letter
class Student {

    // Attributes or fields
    int rollNo;
    String name;
    float marks = 90;

    // Non parameterised constructor
    Student(){
        /*
        this.rollNo = 0;
        this.name = "Default Name";
        this.marks = 100.00f;

        // You can do this to assign some default values if no values were specified or, we use DRY to do this.
        */
        this (0,"Test Name",100.00f);
        // This is calling the parameterised constructor with the default values
    }

    /*
        The `this` keyword will get access to the current instance of the object that is calling the operation.
     */
    // Parameterised Constructor
    Student(int rollNo, String name, float marks){
        this.rollNo = rollNo;
        this.name = name;
        this.marks = marks;
    }

    // Behaviour or methods
    void greeting() {
        System.out.println("Hello, My Name is " + name);
    }

    /*
        In java, we cannot destroy an object manually but we can specify what to do when an object is destroyed.
     */

    @Override
    protected void finalize() throws Throwable {
        System.out.println("Object is Destroyed.");
    }
}

// Primitive Data types in java are stored in the stack memory to increase speed and efficiency.