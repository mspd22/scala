package oops;

import oops.include.Brake;
import oops.include.Engine;
import oops.include.Media;

public class _6_Interface implements Engine, Brake, Media {

    public static void main(String[] args) {


        /*
            To implement multiple inheritance in Java we can use Interfaces.

            Interfaces - Contain Abstract Functions. These help to resolve the ambiguity problem.

            
                - By default the function are public and abstract in an interface.
                - The variables are static and final by default in an interface.

                Variables are made static and final because no matter what unlike abstract classes interfaces cannot be
                initialized, so there will be no constructors or creation of object of an interface so if variables are not
                defined at the creation of an interface they cannot be initialized at any other point of time.

                SO WE DECLARE THEM AS FINAL SO THAT THEY HAVE TO DEFINED AT THE TIME OF DEFINITION.

                Interfaces are also called as pure abstract class since we cannot use abstract classes to mimic the
                implementation of interfaces but the reverse is not true.

                Multiple Interfaces can be implemented by a class but only a single class can be inherited.


                You can do
                    Engine obj = new Car();

                    But the same rules as that of classes are followed here.

               !!!!!!!!!!!!!!!!!!!!!!
               You can only access elements present in Engine but the Implementations will that of Car if present.
               !!!!!!!!!!!!!!!!!!!!!!

               You can also extend interfaces.

               interface name extends class_name{

               }


                !!!!!!!!
                default keyword -> can be used to define a method in an interface and this makes it optional for any class
                implementing this interface to not override that particular method since it has a default to fall back to.


                !!!!!!!
                static interface methods must have a definition in the interface itself.

                The access modifier for an overridden method must be the same or better access but not less.

               !!!!
               You can have Nested Interfaces inside classes and the difference is that the top level interfaces can only
               be declared as public or default while the Nested ones can have any Access Modifier.

         */

        _6_Interface obj = new _6_Interface();
        obj.acc();

    }

    /*
        Here even though there are method with the same name and signature in multiple interfaces, since no interface
        actually defines the methods, there will be no problem.

        The only definition will be present in the class that implements the interfaces and there will be no ambiguity
        issue.
     */
    @Override
    public void brake() {
        System.out.println("I Brake like a normal Car.");
    }

    @Override
    public void start() {
        System.out.println("I start like a normal Car.");
    }

    @Override
    public void stop() {
        System.out.println("I stop like a normal Car.");
    }

    @Override
    public void acc() {
        System.out.println("I accelerate like a normal Car.");
    }
}
