package oops.include;

public interface Engine {

    // static final by default, so no need to add modifiers
    int price = 100000;

    void start();
    void stop();
    void acc();
}
