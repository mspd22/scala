package basics;

public class _2_typeCasting {
    public static void main(String[] args) {

        /*
            TYPE CASTING
                - Typecasting is the process of converting the value of a single data type (such as an integer [int], float, or double)
                into another data type.

                - In java type casting can be automatic(implicit) or explicit(done by the user/dev).

                Syntax:
                <datatype> variableName = (<datatype>) value;
         */

        /*
            There are two main types of Type casting in java. They are:
            1. Widening Type Casting
                - Widening type casting is the process of converting a lower data type to a higher data type. It is also
                  referred to as implicit conversion or casting down. This process is performed automatically and is safe,
                  as there is no risk of  data loss. This kind of type conversion and casting in Java happens when:
                   • The target type is greater than the source type.
                   • The two data types are compatible.
            byte -> short -> char -> int -> long -> float -> double  (From left to right: Lower data type to Higher data type)

            2. Narrowing Type Casting
                - Narrowing type casting is the process of reducing a larger data type to a smaller one. Other names for this
                  are casting up or explicit type casting in Java. It does not happen on its own. If we do not do this explicitly,
                  we will get a compile-time error. The narrowing type casting is unsafe because data loss might occur due to the
                  smaller range of allowed values of the lower data type. A cast operator helps in explicit casting.

            double -> float -> long -> int -> char -> short -> byte  (From left to right: Higher data type to Lower data type)
         */
    }
}
