package basics;

/*
 *
 * Wrapper classes -> provides an easy way to use primitive data types as reference data types
 *                 -> can be used with collections such as ArrayList
 *
 */

// Primitive  -   Wrapper
// boolean    -   Boolean
// char       -   Character
// int        -   Integer
// double     -   Double

// autoboxing -> the automatic conversion that the java compiler makes between the primitive datatypes and their corresponding object wrapper classes
// unboxing -> the reverse of autoboxing. the automatic conversion of wrapper classes to their primitive data types

/*
 *
 * Converting a primitive value (an int, for example) into an object of the corresponding wrapper class (Integer) is called autoboxing.
 * The Java compiler applies autoboxing when a primitive value is:
 * 1. Passed as a parameter to a method that expects an object of the corresponding wrapper class.
 * 2. Assigned to a variable of the corresponding wrapper class.
 *
 */

/*
 *
 * Converting an object of a wrapper type (Integer) to its corresponding primitive (int) value is called unboxing.
 * The Java compiler applies unboxing when an object of a wrapper class is:
 * 1. Passed as a parameter to a method that expects a value of the corresponding primitive type.
 * 2. Assigned to a variable of the corresponding primitive type.
 *
 */

/*
 *
 * These are introduced to help us represent primitive data types as objects as most methods in java expect us to work
 * with objects rather than primitive data tpyes
 *
 */


public class _7_wrapperClasses {

    public static void main(String[] args) {

        Boolean a = true;
        // Character c = 'c';
        // Integer i = 10;
        // Double d = 11.0;
        String s = "The first letter of 'String' is capitilised because it works like a Wrapper class by default.";

        System.out.println(s);

        /*
         *
         * These wrapper classes provide a lot of methods to help us work on the objects(which are the varaibles contained by them).
         *
         */

        if(a == true){
            System.out.println("\n\nThis works because of unboxing and autoboxing");
        }

        // Primitive -> faster
        // Wrapper Classes -> slower but more functional

        /*
            When we pass a primitive to a function or a method in java it is passed by value.
            Passing by value means that the changes or modification done to that primitive will not be represented outside the'
            method.

            So we need to use Wrapper classes which will pass the reference of the data we are passing.
         */
    }
}
