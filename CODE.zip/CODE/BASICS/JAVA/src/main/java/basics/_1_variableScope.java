package basics;

public class _1_variableScope {

    /*
        Access Modifiers -
        There are four Access Modifiers in Java. They are:

            1. Default - When we don’t use any keyword explicitly, Java will set a default access to a given class, method,
               or property. The default access modifier is also called package-private, which means that all members are
               visible within the same package, but aren’t accessible from other packages.

            2. Public - If we add the public keyword to a class, method, or property, then we’re making it available to the
               whole world (i.e. all other classes in all packages will be able to use it). This is the least restrictive access
               modifier.

            3. Private - Any method, property, or constructor with the private keyword is accessible from the same class only.
               This is the most restrictive access modifier, and is core to the concept of encapsulation. All data will be hidden
               from the outside world.

            4. Protected - Between public and private access levels, there’s the protected access modifier.
               If we declare a method, property, or constructor with the protected keyword, we can access the member from
               the same package (as with package-private access level), as well as from all subclasses of its class, even if
               they lie in other packages.

               !!!! In protected only the subclass can access protected members and not even the parent class can.
               SO consider class Child extends Parent{

                    this is not allowed
                    Parent obj = new Parent();

                    obj.protected_data; --->  Not Allowed
               }


                         Class   Package   Subclass-SamePackage  SubClass-DiffPackage   World
            Public         Y        Y               Y                     Y               Y
            Protected      Y        Y               Y                     Y               N
            Default        Y        Y               Y                     N               N
            Private        Y        N               N                     N               N

     */
    /*
        The variable scopes used in java are:
            1. Class Scope: A variable declared with a private access modifier inside a class but outside its methods is a class variable.
            2. Method Scope: When a variable is declared inside a method, it has method scope, and it will only be valid inside the same method.
            3. Loop Scope: If we declare a variable inside a loop, it will have a loop scope and will only be available inside the loop.
            4. Bracket Scope: We can define additional scopes anywhere using brackets `{` and `}`.
     */

    /*
        Variable Shadowing -
        Variable shadowing occurs when a variable declared in a certain scope has the same name as a variable declared in an outer scope.
        In this case, the variable in the inner scope "shadows" the variable in the outer scope, meaning that the inner variable takes precedence
        over the outer variable when accessed within the inner scope.

     */
    public static void main(String[] args) {

        NestedScopesExample.printTitle();
//        Baeldung
//        John Doe
        // This is the output received. This is called as variable Shadowing where one variable over-rides the other due to
        //scope
    }
}

class NestedScopesExample {

    static String title = "Baeldung";
    public static void printTitle() {
        System.out.println(title);
        String title = "John Doe";
        System.out.println(title);
    }
}

