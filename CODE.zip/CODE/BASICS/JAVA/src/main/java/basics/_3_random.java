package basics;
import java.util.Random;

public class _3_random {
    public static void main(String[] args) {
        Random random = new Random(); // AN instance of the Random class
        /*
            This class will help us develop pseudo-random numbers
         */

        int x = random.nextInt(); // This will create a random number between -2 billion to 2 billion(INTEGER range)
        System.out.println(x);

        int y = random.nextInt(10); // A number from 0 to 9
        System.out.println(y);

        double z = random.nextDouble(); // Value between 0 and 1
        System.out.println(z);

        boolean c = random.nextBoolean();
        System.out.println(c);
    }
}
