package basics;

public class _4_conditionalsAndSwitch {
    public static void main(String[] args) {

        /*
            Conditionals are elements which check to see a condition and change the flow of control based on the
            result.

            There are three types of conditionals in JAVA. They are
            1. if-else statement
            2. Switch statement
            3. Ternary Conditional Statement
         */

        /*
            IF-ELSE Statements

            Use if to specify a block of code to be executed, if a specified condition is true
            Use else if to specify a new condition to test; if the first condition is false
            Use else to specify a block of code to be executed if the same condition is false

            Syntax:
            if(condition == true(using comparison operators)){
                executes
            } else if(cognition2 == true){
                executes
            } else {
                or this
            }

         */

        /*
            Switch Statement - Use switch to specify many alternative blocks of code to be executed

            In normal switch statement
                - Cases have to be the same type as the expression provided
                - duplicate case values are not allowed
                - break is to used
                - default will execute when there is no other case that matches
                - if default is not specified at the end then put a break statement after ot
         */

        int x = 10;
        switch (x){
            case 1:
                System.out.println("It is 1");
                break;

            case 2:
                System.out.println("It is 2");
                break;

            case 10:
                System.out.println("It is 10");
                break;

            default:
                System.out.println("NO Match");
        }

        // Newer Syntax from JAVA 14

//        switch (x){
//            case 1 -> System.out.println("It is 1");
//
//            case 2 -> System.out.println("It is 2");
//
//
//            case 10 -> System.out.println("It is 10");
//
//            default -> System.out.println("NO Match");
//        }


    }
}
