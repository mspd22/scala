package basics;

import java.sql.Array;
import java.util.ArrayList;

public class _5_stringMethods {
    public static void main(String[] args) {

        /*

            String - A class

            - We use objects of string class to store a set of characters.
            - String is immutable, meaning once created, we cannot change the value of the string.
            - String is a reference type, meaning it is stored in the heap memory.

            String Pooling
            - String Pooling is a memory optimization technique used in Java to save memory and improve performance.
            - String Pooling is a part of the heap memory where Java stores string literals.
            - When we create a string literal, Java checks if the same string already exists in the string pool.
            - If it does, Java returns a reference to the existing string instead of creating a new one.
            - This is done to save memory and improve performance.
            - String literals are stored in the string pool, while string objects created using the `new` keyword are stored in the heap memory.

            This means that when we create a new string with the same characters, then the reference variable of that object will also point
            to the object containing that string literal.
         */

        String a = "Hello";
        String b = "Hello";

        System.out.println(a == b); // Here the `==` operator is called the comparator
        // It checks everything including Values and reference to check for equality.

        /*
            We can use the new keyword to bypass the String pool optimization in memory. It will create the objects in Heap.

            Not recommended.
         */

        String c = new String("Hello");
        String d = new String("Hello");
        System.out.println(c == d); // false
        System.out.println(c.equals(d)); // true


        String name = "Bro";

        System.out.println(name.equals("Bro"));
        System.out.println(name.equalsIgnoreCase("BRO"));
        System.out.println(name.length());
        System.out.println(name.charAt(0));
        System.out.println(name.indexOf('o'));
        System.out.println(name.isEmpty());
        System.out.println(name.isBlank());
        System.out.println(name.toLowerCase());
        System.out.println(name.toUpperCase());
        System.out.println("   Bro   ".trim());
        System.out.println(name.replace('o', '0'));



        System.out.printf("Hello %s\n",name);
        /*
         *
         * conversion characters -> after the %-sign
         * %d -> decimal
         * %s -> String
         * %c -> character
         * %s -> Strings
         * %b -> boolean
         * %f -> floats and doubles
         *
         */

        //width -> minimum number of characters to be given as output
        System.out.printf("\nThis is an example of the width field in printf method %10s",name);

        System.out.println();
        //precision -> set a number of decimal points to be displayed after the decimal point
        System.out.printf("%.3f\n",10.3238342342);
        System.out.printf("%.5f\n",10.3238342342);
        System.out.printf("%.7f\n",10.3238342342);

        /*
         * -> adds an effect based on the flag used
         *
         * - : left justify
         * + : output the number along with its sign (+/-)
         * 0 : numeric values are zero padded
         * , : comma grouping separator if numbers > 1000
         *
         */


        // Concatenation in Strings
        System.out.println('a' + 'c');
        System.out.println("a" + "b");
        System.out.println((char)('a' + 4));

        // integer will be converted to Integer that will call toString()
        System.out.println("a" + 1);
        System.out.println("hello" + new Integer(300));
        System.out.println("hello" + new ArrayList());

        // Concatenation in Java is possible only when one of the objects is a String
        // This is the only case where Operator Overloading is possible in


        /*
            StringBuilder
                - A mutable sequence of characters
                - It is used to create a string that can be modified.
                - It reduces the time and complexity when building new strings from old strings
                - It is not synchronized, meaning it is not thread-safe.
                - It is faster than StringBuffer.

         */
    }
}
