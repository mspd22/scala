package basics;
import java.util.Scanner;

public class _0_basics {

    public static void main(String[] args) {

        System.out.println("Hello World"); // printing to console window
        System.out.println("There is implicit end line delimiter in println but not in print");
        System.out.println("`sysout` + tab or just selecting the drop-down option in most IDE's will allow you to skip typing the entire thing out.");

        /*
         * Variables
         */

        int x = 10;
        System.out.println(x + " is my Number");
        float y = 3.14f;
        System.out.println(y + " is the value of pi");

        System.out.println("There is no swap function in java, so use xor or a = a + b - (b = a)");

        Scanner input = new Scanner(System.in);
        System.out.print("Enter your name : ");
        String name = input.nextLine();
        System.out.print("Enter your age : ");
        int age = input.nextInt();

        /* Taking Input
         *
         * There is a problem when using nextInt or nextFloat instead of nextLine.
         * The scanner will not completely read the entire line hence needing to explicitly make it go to the next line to
         * take any other input in the succeeding lines. One solution is to just take an empty or null input every time we
         * use any other input form other than `nextLine` or to use `nextLine` and parse the input to the desired data type
         * we need.
         */

        input.nextLine(); // -> this is important
        System.out.print("What is your favourite food : ");
        String food = input.nextLine();


        System.out.println("Your name is " + name.toUpperCase());
        System.out.println("You are " + age +" years old");
        System.out.println("Your favourite food is " + food);

        input.close();

        /*
            Expressions in JAVA
         */

        // expression = operands + operations

        int a =  10;
        System.out.println(a + 1);
        System.out.println(a - 1);
        System.out.println(a * 2);
        System.out.println(a / 5);
        System.out.println(a % 3);

        /*
         *
         * integer division same as c++
         *
         */

        /*
            type casting
        */

        // double b = /3
        double b = (double) a/3;

        System.out.println(b);


        /*
         * Some Math Methods
         */
        System.out.println("\n\nMATH METHODS");
        System.out.println(Math.max(10, 29));
        System.out.println(Math.min(10.9393,9291));
        System.out.println(Math.abs(-10393));
        System.out.println(Math.sqrt(292));
        System.out.println(Math.round(10.32923));
        System.out.println(Math.ceil(12.345));
        System.out.println(Math.floor(10.345));
        System.out.println(Math.pow(10, 3));
    }
}

/*
 * comments are the same as c++
 */