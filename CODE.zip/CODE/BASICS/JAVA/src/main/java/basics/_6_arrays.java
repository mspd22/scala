package basics;

public class _6_arrays {
    public static void main(String[] args) {
        /*
         * First way
         */
        String[] cars = {"Camaro","Corvette","Tesla"};

        System.out.println(cars[0]);

        cars[0] = "Mustang";
        System.out.println(cars[0]);

        // System.out.println(cars[3]); -> Will raise a ArrayIndexOutOfBoundException
        /*
         * Another way
         */

        String[] cars2 = new String[3];
        cars2[0] = "a";
        cars2[1] = "b";
        cars2[2] = "c";

        for(String string : cars2) {
            System.out.println(string);
        }


        /*
         * 2d Arrays
         *
         * String cars[][] = new String[3][3];
         *
         */
    }
}
