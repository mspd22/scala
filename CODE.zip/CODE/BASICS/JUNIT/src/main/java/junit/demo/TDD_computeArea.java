package junit.demo;

public class TDD_computeArea {

    public int computeSquareArea(int side) {
        return side*side;
    }

    // Here public access modifier is not required as both the files are present in the same package.
     double computeCircleArea(double radius){
        return Math.pow(radius,2.0) * Math.PI;
    }
}
