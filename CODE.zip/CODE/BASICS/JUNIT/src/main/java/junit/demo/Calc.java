package junit.demo;

public class Calc {

    public int divide(int a, int b) {
        return a / b;
    }
}
