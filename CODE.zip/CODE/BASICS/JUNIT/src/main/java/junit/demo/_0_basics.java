package junit.demo;

public class _0_basics
{
    public static void main(String[] args) {

        /*
            Testing
                - The process of executing a program with the intent of finding errors.
                - The process of evaluating a program by observing its behavior.
                - Testing is performed after development by a special team of testers who work to find errors in the
                entire execution of the project.

            Life Cycle -
                Design -> Develop --> Unit Testing --> Testing -> Deployment
         */

        /*
            Unit Testing
                - The process of testing individual units of code (methods, classes, etc.) in isolation.
                - Unit testing is performed by developers during the development process.
                - Unit testing is performed on a small part of the code (a single method or class) in isolation.
                - Helps in finding bugs early in the development process.
                - It is also used for checking if the behaviour of the methods are as expected.
                - Units can refer to a single method or a single class or a group of methods that are used for performing a single task.

                Steps in Unit Testing
                    1. Prepare the Testing Environment
                    2. Provide Testing Input
                    3. Run the Test
                    4. Provide Expected Output
                    5. Perform Assertion
                    6. Report the Test Results
         */

        /*
            JUnit - Java Unit Testing
                - A unit testing framework for Java.
                - It is an open-source framework.
                - It is used to write and run repeatable tests.
                - It is used to test the functionality, behaviour, performance and security of the code.
         */

        /*

            Annotations in Junit5 or Junit Jupiter
                - @Test - Used to mark a method as a test method.
                - @BeforeAll - Used to mark a method that should be run before all the test methods in the class.
                - @AfterAll - Used to mark a method that should be run after all the test methods in the class.
                - @BeforeEach - Used to mark a method that should be run before each test method in the class.
                - @AfterEach - Used to mark a method that should be run after each test method in the class.
                - @Disabled - Used to mark a test method that should be ignored.
                - @DisplayName - Used to mark a test method with a custom name.


            - Came from org.junit.jupiter.api
            - Visibility of the @Test annotated method can be public, protected or default
            - They also inform the test engine what method to run.

         */

        /*
            Assertions
                - Actuality vs Expected
                - assertEquals(expected, actual) - Used to check if the expected value is equal to the actual value.
                - assertNotEquals(expected, actual) - Used to check if the expected value is not equal to the actual value.
                - assertTrue(condition) - Used to check if the condition is true.
                - assertFalse(condition) - Used to check if the condition is false.
                - assertNull(object) - Used to check if the object is null.
                - assertNotNull(object) - Used to check if the object is not null.
                - assertArrayEquals(expected, actual) - Used to check if the expected array is equal to the actual array.

            All of these and the more assert methods found in the Assertions class are static methods.
            - The assert methods are used to check if the expected value is equal to the actual value.

            All the assert methods are present in the org.junit.jupiter.Assertions class
         */

        /*
            TestInstance Behaviour
                - For testing an object of the testing class is created separately for each method defined in the test file.
                - We can control this behaviour using the TestInstance Annotation
                    1. @TestInstance(Lifecycle.PER_CLASS) - This will create a single instance of the test class for all the test methods.
                    2. @TestInstance(Lifecycle.PER_METHOD) - This will create a new instance of the test class for each test method.
                - The default behaviour is PER_METHOD.
                - This is useful when we want to share the state between test methods.
                - This is useful when we want to use the same instance of the test class for all the test methods.

         */
    }
}
