package junit.demo;

import java.util.Arrays;

public class _1_arrayAssertion {
    /*
        Array Assertion
            - assertArrayEquals(expected, actual) - Used to compare two arrays.
            - assertArrayEquals(expected, actual, message) - Used to compare two arrays with a custom message.
            - assertArrayEquals(expected, actual, delta) - Used to compare two arrays with a delta value.
            - assertArrayEquals(expected, actual, delta, message) - Used to compare two arrays with a delta value and a custom message.
     */
    /*
        The assertArrayEquals method is used to compare two arrays.
        - The number of elements in the array should match.
        - Elements in the array are of the same datatype.
        - Elements of the array are equal
        - Order of the elements in the array should be same.

        ONLY then the test case is considered as passed.
     */

    /*
        Now we will also check the assertThrows method
     */
    int[] sortingArray(int[] arr){
        Arrays.sort(arr);
        return arr;
    }

    /*
        Testing Performance with assetTimeOut and the timeout attribute
            - assertTimeout(timeout, executable) - Used to check if the method takes more than the specified time.
            - assertTimeoutPreemptively(timeout, executable) - Used to check if the method takes more than the specified time and preemptively cancel the execution of the method.
            - assertTimeoutPreemptively(timeout, executable, message) - Used to check if the method takes more than the specified time and preemptively cancel the execution of the method with a custom message.
     */
    int[] sortingArrayLoop(int []arr){
        for(int i = 0;i<1000000;i++){
            Arrays.sort(arr);
        }
        return arr;
    }
}
