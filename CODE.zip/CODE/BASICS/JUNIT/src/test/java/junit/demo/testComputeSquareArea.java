package junit.demo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

/*
In this example we are defining tests before we develop the actual code.
 */
public class testComputeSquareArea {

    @Test
    @DisplayName("Test for Area")
    void testComputeSquareArea() {

        TDD_computeArea tdd = new TDD_computeArea();
        assertEquals(25, tdd.computeSquareArea(5));
        assertEquals(0, tdd.computeSquareArea(0));
        assertEquals(1, tdd.computeSquareArea(1));
        assertEquals(1, tdd.computeSquareArea(-1));
        assertEquals(576,tdd.computeSquareArea(24));
    }

    @Test
    @DisplayName("Test for Circle")
    void testComputeCircleArea(){
        TDD_computeArea tdd = new TDD_computeArea();
        assertEquals(314.1592653589793, tdd.computeCircleArea(10));
        assertEquals(0, tdd.computeCircleArea(0));
        assertEquals(3.141592653589793, tdd.computeCircleArea(1));
        assertEquals(3.141592653589793, tdd.computeCircleArea(-1));
        assertEquals(1809.5573684677208,tdd.computeCircleArea(24));
    }

    @Test
    @DisplayName("Failure Message")
    void testComputeCircleAreaMessage(){
        TDD_computeArea tdd = new TDD_computeArea();
        assertEquals(4,tdd.computeCircleArea(((double) 14/22)),"Test failed for radius : 14/22");

        /*
        org.opentest4j.AssertionFailedError: Test failed for radius : 14/22 ==>
        Expected :4.0
        Actual
        */
    }

    // In the case of directly passing the string as a message, it will get evaluated no matter what.
    // But for the supplier interface, the lambda function is only evaluated if the assertion fails.
    @Test
    @DisplayName("Failure Message with Java Supplier Interface")
    void testComputeCircleAreaSupplier(){
        TDD_computeArea tdd = new TDD_computeArea();
        assertEquals(5,tdd.computeSquareArea(2),() -> "Test failed for radius : 14/22");
    }


}
