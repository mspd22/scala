package junit.demo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

public class testArrayAssertion {

    /*
        assertEquals method will not work in this case.
        - The assertEquals method is used to compare two objects.
        - The assertEquals method will compare the reference of the objects.

     */
    @Test
    void testArrayAssertion() {
        int[] expected = {1, 2, 3};
        int[] actual = {1, 2, 3};

        assertArrayEquals(expected, actual);
    }

//    @Test
//    void testArrayAssertionWithMessage() {
//        int[] expected = {1, 2, 3};
//        int[] actual = {1, 2, 3, 4};
//
//        assertArrayEquals(expected, actual, "Arrays are not equal");
//    }

    @Test
    void testArrayAssertionWithDelta() {
        double[] expected = {1.0, 2.0, 3.0};
        double[] actual = {1.0, 2.0, 3.0};

        assertArrayEquals(expected, actual, 0.01);
    }

    @Test
    @DisplayName("Assert Throws Exception")
    void testArrayAssertionWithException() {
        _1_arrayAssertion obj = new _1_arrayAssertion();
        int []unsortedArray = {3, 2, 1};
        int []sortedArray = {1, 2, 3};
        assertArrayEquals(sortedArray, obj.sortingArray(unsortedArray), "Arrays are not equal");

        // This proves that the method is working

        int []nullArray = null;
        // Old method of checking for exceptions

//        try {
//            obj.sortingArray(nullArray);
//
//            fail(); // We want to fail on purpose and make only the cases where an exception is created as passed.
//        }catch (NullPointerException e){
//            System.out.println("Exception Generated");
//        }

        assertThrows(NullPointerException.class,() -> obj.sortingArray(nullArray));
    }

    @Test
    //Before Junit 5
    //@Test(timeout = 10)
    @DisplayName("Timeout Test")
    void testArrayAssertionWithTimeout() {
        _1_arrayAssertion obj = new _1_arrayAssertion();
        int []unsortedArray = {3, 2, 1};
        int []sortedArray = {1, 2, 3};

        // Will fail the test case if the operation takes more than the time declared in the function
        assertTimeout(Duration.ofMillis(10), () -> {;
            obj.sortingArrayLoop(unsortedArray);
        });
    }
}
