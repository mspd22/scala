package junit.demo;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class testCalc {

    @Test
    public void test(){
        assertEquals("Hello World", "Hello World");
    }

    @Test
    public void testCalc(){
        Calc c = new Calc();
        assertEquals(2, c.divide(4, 2));
        assertEquals(0, c.divide(0, 2));
        assertEquals(2, c.divide(4, 3));
    }

    // Annotations and default is allowed.
    @Test
    @DisplayName("SecondTestMethod")
    void testCalc2(){
        Calc c = new Calc();
        assertEquals(2, c.divide(4, 2));
    }

    @Test
    void emptyMethod(){} // Will pass the test as Junit only searches for failure.
}
