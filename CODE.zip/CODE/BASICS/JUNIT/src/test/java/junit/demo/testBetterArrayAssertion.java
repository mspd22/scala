package junit.demo;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

@TestInstance(TestInstance.Lifecycle.PER_METHOD) // Default Behaviour
public class testBetterArrayAssertion {

    _1_arrayAssertion obj;

    @BeforeEach
    void init(){
        obj = new _1_arrayAssertion();
        System.out.println("Before Testing");
    }

    // The test framework will call the method annotated with the BeforeEach annotation everytime before executing a test.
    @Test
    void testBetterArrayAssertion() {
        int[] expected = {1, 2, 3};
        int[] actual = {1, 2, 3};

        System.out.println("Actual Test");
        assertArrayEquals(expected, actual);
    }

    @Test
    void testBetterArrayAssertionFail() {
        int[] expected = {1, 2, 3};
        int[] actual = {1, 2, 3,5,7};

        System.out.println("Actual Test");
        assertArrayEquals(expected, actual);
    }

    // have to be static so that we can call it without an object
    @AfterAll
    static void destructor(){
        System.out.println("After all the tests are completed.");
    }
}

// Output we receive
/*
Before Testing
Actual Test
Before Testing
Actual Test

org.opentest4j.AssertionFailedError: array lengths differ,
Expected :3
Actual   :5
<Click to see difference>


	at org.junit.jupiter.api.AssertionFailureBuilder.build(AssertionFailureBuilder.java:151)
	at org.junit.jupiter.api.AssertionFailureBuilder.buildAndThrow(AssertionFailureBuilder.java:132)
	at org.junit.jupiter.api.AssertArrayEquals.assertArraysHaveSameLength(AssertArrayEquals.java:428)
	at org.junit.jupiter.api.AssertArrayEquals.assertArrayEquals(AssertArrayEquals.java:237)
	at org.junit.jupiter.api.AssertArrayEquals.assertArrayEquals(AssertArrayEquals.java:87)
	at org.junit.jupiter.api.AssertArrayEquals.assertArrayEquals(AssertArrayEquals.java:83)
	at org.junit.jupiter.api.Assertions.assertArrayEquals(Assertions.java:1281)
	at junit.demo.testBetterArrayAssertion.testBetterArrayAssertionFail(testBetterArrayAssertion.java:35)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at java.base/java.util.ArrayList.forEach(ArrayList.java:1541)
	at java.base/java.util.ArrayList.forEach(ArrayList.java:1541)

After all the tests are completed.
 */
