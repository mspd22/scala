# SonarQube

* [SonarQube](https://www.sonarqube.org/) is an open-source platform for continuous inspection of code quality. It performs automatic reviews with static analysis of code to detect bugs, code smells, and security vulnerabilities on 29 programming languages.
* It provides reports on duplicated code, coding standards, unit test coverage, code complexity, and other metrics.
* It is used by developers to manage code quality and security in their projects.
* It is a tool that helps developers to write clean and maintainable code.
* It is a __Static Application Security Testing__ or __SAST__ tool

___

## Features
1. Code Quality Analysis: Provides detailed insights into code quality, including metrics like complexity, duplication, and maintainability.
2. Security Vulnerability Detection: Identifies potential security issues in the code. 
3. Integration: Works with various CI/CD pipelines, IDEs, and version control systems. 
4. Customizable Rules: Allows customization of coding rules and standards to fit specific project needs. 
5. Reports and Dashboards: Generates comprehensi11ve reports and dashboards to visualize code quality trends over time.

---

## Installation
```bash
# Install SonarQube
sudo apt-get update
sudo apt-get install -y openjdk-11-jre
wget https://binaries.sonarsource.com/Distribution/sonarqube/sonarqube-9.9.0.65466.zip
unzip sonarqube-9.9.0.65466.zip
sudo mv sonarqube-9.9.0.65466 /opt/sonarqube
sudo useradd sonar -d /opt/sonarqube
sudo chown -R sonar:sonar /opt/sonarqube
sudo chmod -R 755 /opt/sonarqube

# Start SonarQube
sudo -u sonar /opt/sonarqube/bin/linux-x86-64/sonar.sh start
```

## Configuration
```bash
# Configure SonarQube
sudo nano /opt/sonarqube/conf/sonar.properties
```
- Set the database connection properties (e.g., PostgreSQL, MySQL).
- Set the web server port (default is 9000).
- Set the authentication method (e.g., LDAP, OAuth).
- Set the email server properties for notifications.
- Set the logging level and file location.
- Set the maximum heap size for the Java process.
- Set the data directory for storing analysis results.
- Set the temporary directory for storing temporary files.
- Set the language-specific properties (e.g., Java, Python, JavaScript).
- Set the quality gate properties (e.g., pass/fail criteria).
- Set the webhook properties for integration with CI/CD tools.
- Set the security properties (e.g., user roles, permissions).
- Set the custom rules properties (e.g., custom coding standards).
- Set the plugin properties (e.g., installed plugins, custom plugins).
- Set the backup properties (e.g., backup schedule, backup location).
- Set the notification properties (e.g., email notifications, webhook notifications).
- Set the API properties (e.g., API keys, API endpoints).
- Set the integration properties (e.g., GitHub, Bitbucket, Jenkins).
- Set the performance properties (e.g., analysis time, memory usage).
- Set the monitoring properties (e.g., monitoring tools, monitoring endpoints).

---

## Code Coverage and Quality Check

* Will mention the amount of code covered by the testing.
* Code quality check will find bugs, vulnerabilities and code smells(poor readability in code).

## SonarQube Quality Profiles
* Quality profiles are a set of rules that define the coding standards and best practices for a specific programming language or technology.
* They are used to enforce coding standards and ensure that the code meets the required quality criteria.
* Quality profiles can be customized to fit the specific needs of a project or organization.
* They can be created, modified, and deleted as needed. Child profiles can be created for each of the language and technology provided in sonarQube.
* Quality profiles can be shared across projects and organizations.
* They can be used to enforce coding standards and best practices across multiple projects and teams.
* There are also Pre-defined profiles called Default for every language which we can use. These cannot be changed.
* There is also a marketplace for downloading new profiles.

## Quality GateCheck
* Quality gates are a set of conditions that must be met before a project can be considered ready for release.
* They are used to ensure that the code meets the required quality criteria and is free of critical issues.
* This is a set of parameters or threshold which are defined to gate-keep bad quality code.
* Examples like 
  - No new critical issues
  - No new blocker issues
  - Coverage on new code is greater than 80%
  - Maintainability rating is A or B

## Components of SonarQube
1. **SonarQube Server**: The core component that manages the analysis and stores the results.
    - It is used for publishing the report.
2. **SonarQube Scanner**: A tool that performs the actual code analysis and sends the results to the SonarQube server.
3. **SonarQube Database**: Stores the analysis results, configuration, and historical data.
    - The database used is generally PostgreSQL
4. **SonarQube Web Interface**: The user interface for viewing analysis results, managing projects, and configuring settings.
5. **SonarQube Plugins**: Extend the functionality of SonarQube by adding support for additional languages, rules, and integrations.
