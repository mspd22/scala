# JACOCO - Java Code Coverage

## Code Coverage
* Code coverage is a measure of how much of the code is executed during testing.
* It is the percentage of code which is covered by testing by automated tests.
* It is a form of white box testing which finds the areas of program that are not executed by a set of test cases.
* Code coverage is used to identify untested parts of a codebase, ensuring that all code paths are exercised during testing.

## Why Do we Need Code Coverage
* Code coverage helps to identify untested parts of a codebase, ensuring that all code paths are exercised during testing.
* It helps to measure the efficiency of test suites and identify areas for improvement.
* It offers a quantitative measurement.


### JaCoCo:

#### Role: JaCoCo is responsible for collecting code coverage data during test execution.
#### Function: It instruments the bytecode and records which lines, branches, methods, and classes are executed during the tests.
#### Output: JaCoCo generates coverage reports in formats like XML, which contain detailed coverage information.


### Issues In Code
1. Bugs - 
   - Bugs are errors or flaws in the code that cause it to produce incorrect or unexpected results.
   - They can occur due to logical errors, syntax errors, or incorrect assumptions made by the developer.
   - Bugs can lead to crashes, data corruption, or security vulnerabilities.
2. Code Smells -
   - Code smells are indicators of potential problems in the code that may not necessarily be bugs but suggest that the code could be improved.
   - They are often related to poor design, lack of readability, or maintainability issues.
   - Examples include long methods, duplicated code, and excessive complexity.
3. Duplication - 
   - Duplication refers to the presence of identical or similar code in multiple places within a codebase.
   - It can lead to maintenance challenges, as changes made in one location may not be reflected in others.
   - Reducing duplication improves code readability and maintainability.
4. Security Vulnerabilities -
   - Security vulnerabilities are weaknesses in the code that can be exploited by attackers to compromise the system.
   - They can arise from improper input validation, insecure coding practices, or outdated libraries.
   - Identifying and fixing security vulnerabilities is crucial for protecting sensitive data and ensuring system integrity.
   - They are not surefire errors but can cause problems if misused.
5. Security Hotspots -
   - Security hotspots are areas of the code that require special attention due to their potential security implications.
   - They may not be vulnerabilities themselves but indicate code that should be reviewed for security best practices.
   - Examples include cryptographic operations, authentication mechanisms, and data handling.
   - Manual Review is required to review if found.

