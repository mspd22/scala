package spring.demo.DI;

//import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class client {

    public static void main(String[] args) {

        // Traditional way of writing code
        Employee e = new Employee();
        e.setE_id(1);
        e.setE_name("John");
        e.setE_salary(100000);

        System.out.println("--Example of a Normal Object Creation--");
        System.out.println(e);
        System.out.println("\n");

        // Inversion of control (IOC)

        // 1. Add jar files for Spring Core.
        // 2. Configure Java Objects in an XML File
        // 3. Use Spring IOC container, e.g. BeanFactory or ApplicationContext to get the objects constructed by them

        /*
            -ApplicationContext can be configured to close on demand hence we can use this class when we need custom
            configurations on our context
         */


        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("employeeBean.xml");
        System.out.println("\n--Example of Object Creation Using Dependency Injection--");
        Employee e1 = (Employee) context.getBean("emp1");
        Employee e2 = context.getBean("emp2",Employee.class);

        System.out.println(e1);
        System.out.println(e2);
        System.out.println("\n\n");

        /*
            The advantage with xml file is that it can be modified at any time without affecting the source code.

            This is an example of IOC

            - In BeanFactory method : The object are only constructed when you request for them just like lazy evaluation in scala
            - But the ApplicationContext constructs objects even before we request for them.
         */

        /*
            - We can define our own custom init() and destroy() methods to manipulate the Bean object during its LifeCycle
            - We can declare them in the bean.xml file we have for defining the bean Object(in this case employeeBean.xml)
            - We can close or destroy the ApplicationContext using the close() method
         */

        System.out.println("--Example of Object Creation with our own custom Init and Destroy Methods");
        Employee customInitDestroy = context.getBean("emp3",Employee.class);
        System.out.println(customInitDestroy);
        System.out.println("\n\n");

        System.out.println("--Example of Constructor Injection--");
        Employee addrEmp = context.getBean("emp4",Employee.class);
        System.out.println(addrEmp);

        context.close(); // close the context
    }
}
