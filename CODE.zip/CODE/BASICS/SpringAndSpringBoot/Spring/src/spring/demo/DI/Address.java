package spring.demo.DI;

public class Address {

    // Attributes
    String city;
    String state;
    int zipCode;

    // Methods
    public Address(){

    }

    public Address(String city, int zipCode, String state) {
        this.city = city;
        this.zipCode = zipCode;
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public int getZipCode() {
        return zipCode;
    }

    public String getState() {
        return state;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Address{" +
                "city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zipCode=" + zipCode +
                '}';
    }
}
