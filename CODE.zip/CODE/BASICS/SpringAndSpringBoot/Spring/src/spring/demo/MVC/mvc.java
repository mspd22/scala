package spring.demo.MVC;

public class mvc {
    public static void main(String[] args) {

        /*
            MVC - Model View Controller
                - It is a java framework which is used to build web applications. It follows the Model-View-controller
                    design Pattern.
                - It also implements all the basic features of a core Spring framework like IOC and DI.

                - It also provides a dignified solution to use MVC in the spring framework with the help of a dispatcher
                    servlet.

                Dispatcher Servlet is a class that receives the incoming requests and maps it to the right resource such
                    as controller, model or view.

            Spring MVC -

                Front Controller -_Model_-> Controller -_Model_->View
                        |                                       |
                        V                                       V
                        ---------W E B  B R O W S E R------------

               Model - Contains the core data of the application. Data can be a single object or a group of objects
               Controller -> Contains the Business Logic of the application. @Controller to mark a class as a controller
               View -> Used to represent the information in a particular format example: Excel
               Front Controller -> Dispatcher Servlet class acts as the front controller

                                     _____Model And View___________ 4
                                    |                              |
                                    |                              |
                                    |      Handler Mapping    Controller
                                    |             /           /
                                    |          2 /         3 /
          ---->Request 1----> Dispatcher Servlet ------------
                                    |             \
                                  6 |              \ 5
                                  View            View Resolver

         */

        /*
            Steps to Implement MVC
                1. Add Dependencies
                2. Create a Controller class and configure web xml file
                3. Define the bean in XML file
                4. Create a JSP page and execute the program
         */

        /*
            Advantages of Spring MVC
                1. LightWeight
                2. Highly Productive
                3. MVC Supported
                4. Security
                5. Role Separation

         */
    }
}
