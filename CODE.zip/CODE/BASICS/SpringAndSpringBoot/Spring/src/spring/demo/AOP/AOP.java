package spring.demo.AOP;

public class AOP {
    public static void main(String[] args) {
        /*
            - Spring AOP enables Aspect oriented Programming in Spring applications
            - Aspects enable modularization of concerns
            - Adds cross-cutting concern before,after and around the actual logic
            - Easy to maintain code in the present and future

            AOP Core Concepts
                1. Aspect -> A class that implements the java enterprise application concerns which cuts through
                    multiple classes like security, logging, transaction management

                    They can be normal classes that can be configured by an XML file.

                2. Target Object -> Objects on which advices are applied
                3. PointCut
                4. Advice
                5. Join Point
                6. Weaving -> Process of linking an aspect with other applications types or objects to create an advised object.
                7. Proxy -> It is an object created after applying the advice on the target object
         */

        /*
            Advice => Actual actions that are taken for a particular join point. Methods that are executed when a
                particular joinPoint needs a matching point-cut in the application

            JoinPoint => A point in the program such as a method execution, exception handling etc. Also, a candidate
                point in the execution where an aspect can be plugged in.

            Point-cut => They are expressions that are matched with the joinPoint to determine whether advice needs to
                be executed or not.
         */


        /*
            Steps to Implement AOP in Spring Application
                1. Import the necessary AOP Dependencies
                2. Aspect & PointCut Expression - Write aspect class annotated with @Aspect
                3. Join Points - Write methods on which you want to execute advices and those match with point cut expressions
                4. Run the Application
         */

        /*
            TYPES OF AOP ADVICE
                1. Before Advice - It executes before the join point
                2. After Advice - It executes after the join point
                3. After Returning Advice - Advised to execute after the join point completes
                4. Around Advice - Advice that surrounds a join point like method invocation
         */
    }
}
