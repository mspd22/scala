package spring.demo.DI;

public class Employee {

    int e_id;
    String e_name;
    int e_salary;

    Address e_addr;

    public Employee() {

    }

    public Employee(int e_id, String e_name, int e_salary) {
        this.e_id = e_id;
        this.e_name = e_name;
        this.e_salary = e_salary;
    }

    public Employee(Address addr){
        this.e_addr = addr;
    }

    public String getE_name() {
        return e_name;
    }

    public void setE_name(String ename) {
        this.e_name = ename;
    }

    public int getE_salary() {
        return e_salary;
    }

    public Address getE_addr() {
        return e_addr;
    }

    public void setE_addr(Address e_addr) { // Setter Injection
        this.e_addr = e_addr;
    }

    public void setE_salary(int esalary) {
        this.e_salary = esalary;
    }

    public int getE_id() {
        return e_id;
    }

    public void setE_id(int eid) {
        this.e_id = eid;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "e_id=" + e_id +
                ", e_name='" + e_name + '\'' +
                ", e_salary=" + e_salary +
                ", e_addr=" + e_addr +
                '}';
    }

    public void myInit(){
        System.out.println("Created Employee class with ID " + this.e_id);
    }

    public void myDestroy(){
        System.out.println("Destroyed Employee class with ID " + this.e_id);
    }

}
