package topics.concurrency

import java.util.concurrent.{Executor, Executors}

object _0_basics extends App {

    /*
        JVM Threads -> basic for java concurrency

            - It is an instance of a class
            - It takes an instance of a trait called runnable as its argument

        Interface Runnable{
            public void Run()
        }
     */

    val aThread = new Thread(new Runnable {
        override def run(): Unit = println("Running in Parallel")
    }) // This piece of code instantiates a Thread object with a Runnable object whose method Run prints to the terminal


    // How to a run a thread
    //creates a JVM thread which runs on top of the OS thread
    aThread.start()
    /*
        Only gives the signal to the JVM to start the jvm thread which invokes the run method
        inside its inner runnable.

        The thread instance and the JVM Thread where the threads are run are completely different
     */

    // Also remember
    // runnable.run() -> doesn't do anything

    aThread.join() // -> Makes sure that the thread finishes running
    println("Hello")

    // val threadHello = new Thread(() => (1 to 5).foreach(_ => println("Hello"))) // -> Will work from scala 2.12 and above
    val threadHello = new Thread(new Runnable {
        override def run(): Unit = (1 to 5).foreach(_ => println("Hello"))
    })

    val threadGoodbye = new Thread(new Runnable {
        override def run(): Unit = (1 to 5).foreach(_ => println("GoodBye"))
    })

    threadHello.start()
    threadGoodbye.start()

    // Different Runs will give Different results
    /*
        IN THE JVM THREADS ARE REALLY EXPENSIVE TO START AND KILL,
        So we generally reuse them

        Executors and Thread Pool
     */

    val pool = Executors.newFixedThreadPool(10)
    pool.execute(new Runnable {
        override def run(): Unit = println("Something in the pool")
    })

    pool.execute(new Runnable {
        override def run(): Unit = {
            Thread.sleep(1000)
            println("Run after 1 Second")
        }
    })

    pool.execute(new Runnable {
        override def run(): Unit = {
            Thread.sleep(1000)
            println("Almost Done")
            Thread.sleep(1000)
            println("Done after 2 Seconds")
        }
    })

    // To Shut down the pool(i.e. the pool will not accept any new actions after this)
    pool.shutdown()
    // WILL GIVE AN ERROR
//    pool.execute(new Runnable {
//        override def run(): Unit = println("Should Not Happen")
//    })

    // pool.shutdownNow() // WILL SHUT DOWN THE POOL INCLUDING THE RUNNING THREADS

    println(pool.isShutdown)
}
