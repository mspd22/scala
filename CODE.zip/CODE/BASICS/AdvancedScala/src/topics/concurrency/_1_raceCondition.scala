package topics.concurrency

object _1_raceCondition extends App {

    /*
        CONCURRENCY PROBLEMS -> We Know this
     */

    // Option 1: Synchronise
//    class BankAccount(var amount : Int){
//        override def toString : String = "" + amount
//    }
//
//    def buy(account : BankAccount,thing : String, price : Int) = {
//        account.amount -= price
//    }
//
//    for( _ <- 1 to 1000){
//        val account = new BankAccount(50000)
//        val thread1 = new Thread(new Runnable {
//            override def run(): Unit = buy(account,"SHOES",3000)
//        })
//        val thread2 = new Thread(new Runnable {
//            override def run(): Unit = buy(account,"PHONE",4000)
//        })
//
//        thread1.start()
//        thread2.start()
//        Thread.sleep(100)
//        if(account.amount != 43000) println("AHA" + account.amount)
//    }
//
//    // NO TWO THREADS CAN EVALUATE ON THIS AT THE SAME TIME
//    def buySafe(account: BankAccount,thing: String, price : Int) = {
//        account.synchronized {
//            account.amount -= price
//            println("I've bought " + thing)
//            println("I have " + account.amount)
//        }
//    }

    // If we run this as many times as we want we will still see the same thing

    // Use @volatile like this
    /*
        class BankAccount(@volatile var amount : Int){
            override def toString : String = "" + amount
        }
     */

    /*
        EXERCISE
     */

    //Q1. 50 threads

    def inceptionThread(maxThreadCount : Int,index : Int) : Thread = new Thread(new Runnable {
        override def run(): Unit = {
            if (index < maxThreadCount) {
                val thread = inceptionThread(maxThreadCount, index + 1)
                thread.start()
                thread.join()
            }
            println(s"This is thread $index")
        }
    })

    inceptionThread(50,1).start()


    //Q2.
    var x = 0
    val threads = (1 to 100).map(_ => new Thread(new Runnable {
        override def run(): Unit = x += 1
    }))
    threads.foreach(_.start())

    // What is the biggest value possible for x -> 100 all threads run at different instance
    // What is the smallest value possible for x -> 1 all threads ran at the same time

    /*
        SLEEP FALLACY -> Trying to synchronise threads using sleep (very wrong practise)

        Making the os sleep for different times does not mean that the thread with the lowest sleep
        will execute first everytime. The Os may have different threads running and after executing the
        important ones all the sleep timers are off and it can choose any one causing concurrency problems
     */
}
