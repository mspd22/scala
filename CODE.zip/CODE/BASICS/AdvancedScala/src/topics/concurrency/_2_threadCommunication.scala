package topics.concurrency

import scala.collection.mutable
import scala.util.Random

object _2_threadCommunication extends App {

    /*
        PRODUCER - CONSUMER LEVEL 1

        Producer -> [P : x ] : C -> Consumer

        Both are running at the same time, and we have to force the consumer to wait for the Producer
     */

    class SimpleContainer {
        private var value : Int = 0

        def isEmpty : Boolean = value == 0

        // producing method
        def set(newValue : Int) : Unit = value = newValue
        // consuming method
        def get :Int = {
            val result = value
            value = 0
            result
        }
    }

    def naiveProdCons() : Unit = {
        val container = new SimpleContainer

        val consumer = new Thread(new Runnable {
            override def run(): Unit = {
                println("[Consumer] Waiting...")
                while(container.isEmpty){ // Busy Loop
                    println("[Consumer] actively waiting...")
                }

                println("[Consumer] I have Consumed : " + container.get)
            }
        })

        val producer = new Thread(new Runnable {
            override def run(): Unit = {
                Thread.sleep(500)
                val value = 42
                println("[Producer] I have produced, after long work " + value)
                container.set(value)
            }
        })

        consumer.start()
        producer.start()
    }


    // TODO
//    naiveProdCons()

    /*
        Monitor -> A data structure internally used by the jvm to keep track of which
        object is locked by which thread

        Synchronised will lock the monitor for a thread

        !! -> Only AnyRefs can have synchronised blocks

        General Principles:
            - Make no assumptions about which thread will get the lock first
            - Keep locking to a minimum (for performance concerns)
            - maintain thread safety at all times in parallel applications
     */

    /*
        Wait and Notify
            Wait -> Waiting on an object's monitor suspends the thread indefinitely
            notify -> Releases the lock and gives it back to another thread waiting on that object's monitor

        val SomeObject = " Hello "

        /Thread 1
        SomeObject.synchronized { -> Locks the object's monitor
            // code
            SomeObject.wait()  -> Release the  Lock and wait
            //code
        }

        /Thread 2
        SomeObject.synchronized { -> Locks the object's monitor
           // code
           SomeObject.wait()  -> signal one sleeping thread to continue(any one, no control)
           //code
       }
    */

    def smartProdCons() : Unit = {
        val container = new SimpleContainer

        val consumer = new Thread(new Runnable {
            override def run(): Unit = {
                println("[Consumer] Waiting...")
                container.synchronized(container.wait())

                println("[Consumer] I have Consumed : " + container.get)
            }
        })

        val producer = new Thread(new Runnable {
            override def run(): Unit = {
                println("[Producer] hard at work...")
                Thread.sleep(500)
                val value = 42

                container.synchronized {
                    println("[Producer] I have produced, after long work " + value)
                    container.set(value)
                    container.notify()
                }
            }
        })

        consumer.start()
        producer.start()
    }

    // TODO
//    smartProdCons()


    /*
        PRODUCER - CONSUMER LEVEL 2

        BUFFER PROBLEM -> [? ? ?] -> Both producer and consumer may block each other
     */

    def prodConsLargeBuffer() : Unit ={
        val buffer : mutable.Queue[Int] = new mutable.Queue[Int]
        val capacity = 3

        val consumer = new Thread(new Runnable {
            override def run(): Unit = {
                val random = new Random()

                while(true){
                    buffer.synchronized {
                        if(buffer.isEmpty){
                            println("[Consumer] Buffer Empty: Waiting...")
                            buffer.wait()
                        }

                        // now there is at least one value in the buffer
                        val x = buffer.dequeue()
                        println(s"[Consumer] I have consumer $x")

                        buffer.notify()
                    }

                    Thread.sleep(random.nextInt(500))
                }
            }
        })

        val producer = new Thread(new Runnable {
            override def run(): Unit = {
                val random = new Random()

                var i = 0

                while(true){
                    buffer.synchronized {
                        if(buffer.size == capacity) {
                            println("[Producer] Buffer is full: Waiting...")
                            buffer.wait()
                        }

                        // now there must be at least one empty space
                        println(s"[Producer] producing $i")
                        buffer.enqueue(i)

                        buffer.notify()

                        i += 1
                    }

                    Thread.sleep(random.nextInt(250))
                }
            }
        })

        consumer.start()
        producer.start()
    }

//    prodConsLargeBuffer()

    /*
        THE TIMES FOR WHICH THE PRODUCER AND CONSUMER WAIT WILL DETERMINE THE CASES WHERE
        BUFFER IS FULL OR EMPTY
     */


    /*
        PRODUCER - CONSUMER LEVEL 3

         MULTIPLE PRODUCERS AND CONSUMERS
     */

    class Consumer(id : Int, buffer : mutable.Queue[Int]) extends Thread{

        override def run(): Unit = {
            val random = new Random()

            while(true) {
                buffer.synchronized {

                    /*
                        Due to the wait and notify when the buffer is empty the consumer will
                        wait for the notification from producer and resume its operation, and then it
                        will call the notify method which will let other consumers consume from the
                        buffer but there could be cases where the buffer is empty and the consumer tries
                        to consume from it

                        so we will make if -> while

                        when a consumer wakes up it will again check if the buffer is empty or not and
                        will go back to sleep if it so
                     */
                    while (buffer.isEmpty) {
                        println(s"[Consumer $id] Buffer Empty: Waiting...")
                        buffer.wait()
                    }

                    // now there is at least one value in the buffer
                    val x = buffer.dequeue()
                    println(s"[Consumer $id] I have consumed $x")

                    buffer.notify()
                }
                Thread.sleep(random.nextInt(500))
            }
        }
    }

    class Producer(id : Int, buffer : mutable.Queue[Int], capacity : Int) extends Thread{
        override def run(): Unit = {
            val random = new Random()

            var i = 0

            while(true) {
                buffer.synchronized {

                    // same as before if -> while
                    while (buffer.size == capacity) {
                        println(s"[Producer $id] Buffer is full: Waiting...")
                        buffer.wait()
                    }

                    // now there must be at least one empty space
                    println(s"[Producer $id] producing $i")
                    buffer.enqueue(i)

                    buffer.notify()

                    i += 1
                }
                Thread.sleep(random.nextInt(500))
            }
        }
    }

    def multiProdCons(nConsumer : Int, nProducer : Int) : Unit = {

        val buffer : mutable.Queue[Int] = new mutable.Queue[Int]
        val capacity = 20

        (1 to nConsumer).foreach(i => new Consumer(i, buffer).start())
        (1 to nProducer).foreach(i => new Producer(i, buffer, capacity).start())
    }

    multiProdCons(3,3)
}