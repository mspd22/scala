package topics.concurrency

import java.util.concurrent.atomic.AtomicReference
import scala.collection.parallel.{ForkJoinTaskSupport, Task, TaskSupport}
import scala.collection.parallel.immutable.ParVector
import scala.concurrent.forkjoin.ForkJoinPool

object _5_parallelUtils extends App {

    /*
        Parallel Collections -> which means that operations on them are handled by multiple threads
     */
    val parList = List(1, 2, 3).par
    val parVector = ParVector[Int](1,2,3)

    /*
        Seq
        Vector
        Array
        Map - Hash, Trie
        Set - Hash, Trie
        etc...,
     */

    def measure[T](operation : => T) : Long = {
        val time = System.currentTimeMillis()
        operation
        System.currentTimeMillis() - time
    }

    val list = (1 to 10000000).toList
    val serialTime = measure {
        list.map(_ + 1)
    }

    val parallelTime = measure {
        list.par.map(_ + 1)
    }

    println(s"Serial Time : $serialTime")
    println(s"Serial Time : $parallelTime")

    // But

    val list2 = (1 to 10000).toList
    val serialTime2 = measure {
        list2.map(_ + 1)
    }
    println(s"Serial Time : $serialTime2")

    val parallelTime2 = measure {
        list2.par.map(_ + 1)
    }

    println(s"Serial Time : $parallelTime2")

    /*
        Map-Reduce Model is the reason for this
            - split the elements into chunks -> Splitter
            - operation
            - recombine - Combiner
     */

    /*
        Be careful when using parallel collections
            - map, flatMap, filter are normally safe
            but
            - fold and reduce and foreach might give different results
     */

    // Synchronisation Problems on the value they are working on
    var sum = 0
    List(1,2,3).par.foreach(sum += _)
    println(sum)

    // Configuration of threads working on the collection
    parVector.tasksupport = new ForkJoinTaskSupport(new ForkJoinPool(2))

    /*
        Creating our own taskSupport
     */

    parVector.tasksupport = new TaskSupport {
        override val environment: AnyRef = ???
        override def execute[R, Tp](fjtask: Task[R, Tp]): () => R = ???
        override def executeAndWaitResult[R, Tp](task: Task[R, Tp]): R = ???
        override def parallelismLevel: Int = ???
    }


    /*
        Atomic Operations and References
     */

    val atomic = new AtomicReference[Int](2)
    val currentValue = atomic.get() // Thread safe Read
    atomic.set(4) // Thread safe write
    atomic.getAndSet(5)
    atomic.compareAndSet(38,56) // If value is 38 then change it to 56
    // Reference Equality

//    atomic.updateAndGet(_ += 1) // Thread safe
}
