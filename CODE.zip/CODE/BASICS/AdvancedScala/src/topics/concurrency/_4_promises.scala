package topics.concurrency

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Await, Future, Promise}
import scala.concurrent.duration._
import scala.util.Success

object _4_promises extends App {

    /*
        Promises - Block on a Future
     */

    case class User(name : String)
    case class Transaction(sender : String, receiver : String, amount : Double, status : String)

    object BankingApp {

        val name = "RTJ Bank"

        def fetcher(name : String) : Future[User] = Future {
            //simulate long computation
            Thread.sleep(500)
            User(name)
        }

        def createTransaction(user : User, merchantName : String, amount : Double) : Future[Transaction] = Future {
            Thread.sleep(1000)
            Transaction(user.name, merchantName, amount, "Success")
        }

        def purchase(userName : String, item : String, merchantName : String, cost : Double) : String ={
            //fetch the user from DB
            // create a transaction
            // Wait for the transaction to finish
            val transactionStatusFuture = for{
                user <- fetcher(userName)
                transaction <- createTransaction(user,merchantName,cost)
            } yield transaction.status

            Await.result(transactionStatusFuture,2.seconds)
        }
    }

    println(BankingApp.purchase("Daniel", "iPhone 12","RTJ Store",3000))

    // Promises

    val promise = Promise[Int]() // "Controller" over a future
    val future = promise.future

    // thread 1 -. Consumer
    future.onComplete {
        case Success(r) => println("[Consumer] I've consumer" + r)
    }
    // thread 2 -> producer
    val producer = new Thread(new Runnable {
        override def run(): Unit = {
            println("[Producer] Crunching numbers...")
            Thread.sleep(500)
            //fulfilling the promise
            promise.success(42)
            println("[Producer] Done")
        }
    })

    producer.start()
    Thread.sleep(1000)


    /*
        Exercises
            - Fulfill a future immediately with a value
            - inSequence(fa, fb)
            - first value
            - last value
            - retryUntil(action : () => Future[T], condition : T => Boolean) : Future[T]
     */

    //Q1.
    def fulfillImmediately[T](value : T) : Future[T] = Future(value)

    //Q2.
    def inSequence[A, B](first : Future[A], second : Future[B]) = first.flatMap(_ => second)


    /*
        Steps
            1. Create aPromise
            2. Extract its Future
            3. Consume the Future
            4. Pass the Future to the producer
            5. Call the Producer
     */

}
