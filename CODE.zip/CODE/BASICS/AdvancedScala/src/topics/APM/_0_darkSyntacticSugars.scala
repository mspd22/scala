package topics.APM

import scala.util.Try
object _0_darkSyntacticSugars extends App {

    // Syntax Sugar 1: Methods with a single Parameter
    def singleArgMethod(arg : Int) : String = s"$arg little duck"

    val description = singleArgMethod {
        // write some code and return the result as a parameter
        10
    }

    val aTryInstance = Try { // java's Try {....}
        throw new RuntimeException()
    }

    List(1,2,3).map{ x =>
        x + 1
    }

    // SS 2: Single Abstract Method Pattern or single abstract method conversion
    trait Action {
        def act(x: Int) : Int
    }

    val anInstance : Action = new Action{
        override def act(x: Int): Int = x + 1
    }

    // This can be written as
//    val aFunkyinstance : Action = (x:Int) => x + 1

    // Examples -> Runnable
    val aThread = new Thread( new Runnable { override def run(): Unit = println("Hello, Scala!") }
    )

//    val aSweeterThread = new Thread(() => println("Sweet, Scala!"))

    // also works for abstract classes with one unimplemented method and other implemented methods

    abstract class AnAbstractType {
        def implemented : Int = 23
        def f(a : Int) : Unit
    }

//    val anAbstractInstance : AnAbstractType = (a : Int) => println("Sweet") // This should be working

    // SS 3: The :: and #: methods are special
    val preparedList = 2 :: List(3, 4)
    println(preparedList)
    /*
        HOW DOES THIS WORK
        There is no :: operator in the Integer class

        This works because of the associativity of the :: operator, it is right associative
        so when we write 2 :: List(4,5), the compiler re writes it as List(4,5).::2
     */

    class MyStream[T] {
        def -->:(Value : T) : MyStream[T] = this
    }

    val mystream = 1 -->: 2 -->: 3 -->: new MyStream[Int] // this only works because : is right associative

    // SS 4: Multi word Naming
    class TeenGirl(name : String) {
        def `and then said`(gossip : String) : Unit = println(s"$name said $gossip")
    }

    val lilly = new TeenGirl(name = " Lilly")
    lilly `and then said` "Scala is so Sweet"


    // SS 5: Infix Types
    class Composite[A,B]
    // Same as saying Composite[Int,String]
    val composite : Int Composite String = ???

    class -->[A,B]
    val towards : Int --> String = ???

    // SS 6: update() is a very special method, much like apply()
    val anArray = Array(1,2,3)
    anArray(2) = 7 // rewritten to anArray.update(2,7)
    // used in mutable collection
    // remember apply and update

    // SS 7: Setters for mutable containers
    class Mutable {
        private var internalMember : Int = 0 // private for OO encapsulation
        def member : Int = internalMember // getter
        def member_=(value : Int) : Unit = internalMember = value
    }

    val aMutableContainer = new Mutable
    aMutableContainer.member = 42
    // rewrittena s aMutableContainer.member_=(42)
}
