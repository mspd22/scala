package topics.APM

import java.sql.Wrapper

object _1_advancedPatternMatching extends App {

    val numbers = List(1)
    val description : Unit = numbers match {
        case head :: Nil => println(s"The only element is $head")
        case _ => println("Something else")
    }

    /*  CURRENTLY ONLY VIABLE USED FOR PATTERN MATCHING
        - constants
        - wildcards
        - case classes
        - tuples
        - magic like above
     */

    /*
        DUE TO CERTAIN CONSTRAINTS YOU CANNOT MAKE THIS CLASS A CASE CLASS
        BUT YOU STILL WANT TO USE PATTERN MATCHING ON IT
     */
    class Person(val name : String, val age : Int)

    object Person {
        def unapply(person : Person) : Option[(String,Int)] = {
            if(person.age < 21) None

            else Some(person.name,person.age)
        }

        // We can overload the unapply method

        def unapply(age : Int) : Option[String] = {
            Some(if(age < 21) "Minor" else "Major")
        }
    }

    val bob = new Person("Bob",25)
    val greeting = bob match {
        case Person(n, a) => s"Hi my name is $n and I am $a years old."
    }
    println(greeting)

    /*
        YOU NEED TO HAVE A unapply METHOD IN THE SINGLETON OBJECT FOR THIS TO WORK
        KEEP THE CASE NAME AS THE SAME AS THE OBJECT
     */

    val legalStatus = bob.age match {
        // The name of the object and inside should be the return option i.e. status
        case Person(status) => s"My legal status is $status"
    }
    println(legalStatus)

    /*
        EXERCISE
            -
     */

    object even { def unapply(arg : Int) :Option[Boolean] =
        if(arg %2 ==0) Some(true)

        else None
    }

    object singleDigit {
        def unapply(arg : Int) : Option[Boolean] = {
            if (arg > -10 && arg < 10) Some(true)
            else None
        }
    }

    val n : Int = 45
    val mathProperty = n match {
        case x if x < 10 => "Single Digit"
        case x if x % 2 == 0 => "Even Number"
        case _ => "NO property"
    }

    // This is tedious to write and do very time

    val betterMathProperty = n match {
        case singleDigit(_) => "Single Digit"
        case even(_) => "Even Number"
        case _ => "NO property"
    }

    println(betterMathProperty)

    /*
        object even { def unapply(arg : Int) : Boolean = (arg %2 ==0) }

        }

        object singleDigit {
            def unapply(arg : Int) : Boolean =  (arg > -10 && arg < 10)
        }

        val evenBetterMathProperty = n match {
            case singleDigit() => "Single Digit"
            case even() => "Even Number"
            case _ => "NO property"
        }
     */


    /*
        INFIX PATTERNS
     */

    case class Or[A, B](a : A, b : B)
    val either = Or(2, "Two")
    val humanDescription = either match {
        // normal way: case Or(number, string) => s"$number is written as $string"
        case number Or string => s"$number is written as $string"
    }

    println(humanDescription)

    /*
        DECOMPOSING SEQUENCES
     */

    val vararg = numbers match {
        case List(1, _*) => "Starting With 1"
    }

    abstract class MyList[+A] {
        def head : A = ???
        def tail : MyList[A] = ???
    }

    case object Empty extends MyList[Nothing]
    case class Cons[+A](override val head : A,override val tail : MyList[A]) extends MyList[A]

    object MyList {
        def unapplySeq[A](list : MyList[A]) : Option[Seq[A]] = {
            if(list == Empty) Some(Seq.empty)

            else unapplySeq(list.tail).map(list.head +: _)
        }
    }

    /*
        THIS WORKS AS THE SAME WAY AS UNAPPLY, unapplySeq IS A PREDEFINED METHOD
     */
    val mylist : MyList[Int] = Cons(1,Cons(2,Cons(3,Empty)))
    val decomposed = mylist match {
        case  MyList(1,2, _*) => "Starting with 1, 2"
        case _ => "Something Else"
    }

    println(decomposed)


    /*
        CUSTOM RETURN TYPES FOR UNAPPLY -> Doesn't have to be Option all the time
        Needs to Have Two defined method
            1. isEmpty : Boolean
            2. get : Something
     */

    abstract class Wrapper[T] {
        def isEmpty : Boolean
        def get : T
    }

    object PersonWrapper {
        def unapply(person : Person) : Wrapper[String] =new Wrapper[String]{
            def isEmpty = false
            def get : String = person.name
        }
    }

    println(bob match {
        case PersonWrapper(n) => s"This person's name is $n"
        case _ => "An Alien"
    })
}
