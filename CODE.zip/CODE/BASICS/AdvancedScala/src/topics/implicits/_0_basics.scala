package topics.implicits

//import scala.language.implicitConversions

object _0_basics extends App {

    // There is no -> method in the String class but still it still works why is this
    // The answer is that the implicit keyword in -> operator method converts the first argument to an arrowAssoc instance
    // Which will then call the method and returns a tuple

    val pair = "Daniel" -> "555"
    val inPair = 1 -> 2

    case class Person(name : String) {
        def greet = s"Hi my name is $name!"
    }

    implicit def fromStringToPerson(str : String) : Person = Person(str)

    /*
        The greet method does not exist for the string class but this will still work because of the
        implicit conversion made by the compiler

        The compiler will search for any method or anything that can convert the string to a thing(object, class, instance)
        that can call the greet method with the specific signature provided

        In this case we have the  fromStringToPerson which will be used by the compiler to implicitly convert the string to
        a Person first and then call the greet method

        - The chosen method signature i.e. input types and output types should all be perfect for this to work
     */
    println("Peter".greet) // reWritten to println(fromStringToPerson("Peter").greet)

    /*
        There should be only from implicit that matches if there is not the compiler will throw an error
     */
//    class A {
//        def greet : Int = 42
//    } // WILL CAUSE COMPILER TO CRASH
//
//    implicit def stringToA(str : String) : A = new A


    /*
        Implicit Parameters
     */

    def increment(x : Int)(implicit amount : Int) : Int = x + amount
    implicit val defaultAmount: Int = 10

    println(increment(2)) // Different from default Arguments
    // Since the argument was implicitly fetched by the compiler from the search Scope

}

