package topics.implicits

object _1_organizingImplicits extends App {

    /*
        Implicit ordering
     */


    println(List(1,4,2,5,3).sorted) // sorted takes an implicit ordering form the scala.Predef package which is imported automatically
    // But if we define an ordering ourselves it will then give preference to that

    implicit def reverseOrdering : Ordering[Int] = Ordering.fromLessThan((a : Int,b : Int) => a > b)

    /*
        Potential Implicit values are-
            - val/var
            - object
            -accessor methods i.e. methods/functions with no parenthesis
     */

    case class Person(name : String,age : Int)

    val persons = List(
        Person("Steve",30),
        Person("Amy",22),
        Person("John",66),
        Person("John",22)
    )

    println(persons.sorted) // no implicit ordering by default

    // We can declare our own ordering
    implicit def personOrdering : Ordering[Person] = Ordering.fromLessThan((p1,p2)  => {
        val res = p1.name.compareTo(p2.name)
        if(res == 0) p1.age < p2.age

        else res < 0
    })

    /*
        Implicit Scope - Places where the compiler searches for implicits

            - Normal Scope or Local Scope
            - Imported Scope
            - Companion Objects of all types involved in the method signature
                -> So in above example it would be
                    - List
                    - Ordering
                    - Person and Super Class
     */

    /*
        You can use an object to define a ordering and then import it just before you use it to
        give priority to it and to specify the context for the compiler

        like this

        object PersonNameOrdering {
            implicit def personOrdering : Ordering[Person] = Ordering.fromLessThan((p1,p2)  => p1.name.compareTo(p2.name)
        }

        import PersonNameOrdering._
        and then use the sorted method
     */

    /*
        EXERCISE
            - totalPrice = Most Used - 50%
            - Unit Price - 25%
            - Unit Count - 25%
     */
    case class Purchase(nUnits : Int, unitPrice : Double)
    object Purchase {
        implicit val totalPriceOrdering: Ordering[Purchase] = Ordering.fromLessThan((p1, p2) =>
            (p1.unitPrice * p1.nUnits) < (p2.unitPrice * p2.nUnits)
        )
    }

    object unitPriceOrdering{
        implicit val unitPriceOrdering : Ordering[Purchase] = Ordering.fromLessThan(_.unitPrice < _.unitPrice)
    }

    object unitCountOrdering {
        implicit val unitCountOrdering : Ordering[Purchase] = Ordering.fromLessThan(_.nUnits < _.nUnits)
    }


}
