package topics.advancedFP

object _2_curriesAndPAF extends App {

    /*
        Curried Function -> Functions which give another functions as return
     */

    val superAdder : Int => Int => Int = x => y => x + y

    val supperAdder5 = superAdder(5) // Int => Int = 5 + y
    println(supperAdder5(10))
    println(superAdder(10)(90)) // Also can do this

    def curriedAdder(x : Int)(y : Int) : Int = x + y // Scala allows this kind of curried definitions
    // THIS IS A METHOD NOT A FUNCTION PER SE

    // SO WE CANNOT NOT DO THIS
    // val add4 = curriedAdder(4). We have to do this

    val add4 : Int => Int = curriedAdder(4)
    // Here we have converted the method to a function value

    /*
        THIS IS IMPORTANT TO REMEMBER SINCE WE CANNOT USE METHOD IN HIGHER ORDER FUNCTIONS UNLESS
        WE CONVERTED THEM TO FUNCTION VALUES

        This is because methods are instances of classes as per the JVM limitation and not an
        instance of a function value, so we have to explicitly convert them before

        This process of conversion is called Lifting/ ETA expansion
     */

    def incr(x : Int) : Int = x + 1
    List(1,2,3,4).map(x => incr(x)) // Compiler will perform ETA expansion Behind the scenes

    // Partial Function Applications
    val add5 = curriedAdder(5) _ // -> Here we are explicitly telling the compiler to perform an ETA expansion


    /*
        EXERCISE
            - Different Syntax for add7
     */

    val simpleAddFunction = (x: Int,y : Int) => x + y
    def simpleAddMethod(x : Int, y : Int) : Int  = x + y
    def curriedAddMethod(x : Int)(y : Int) : Int = x + y

    val add7_1 = (x : Int) => simpleAddFunction(7,x) // simplest, replaceable with all three
    val add7_2 = simpleAddFunction.curried(7)

    val add7_3 = curriedAddMethod(7) _ // Paf
    val add7_4 = curriedAddMethod(7)(_) // Paf

    val add7_5 = simpleAddFunction(7, _ : Int) // alternate syntax for turning methods into function values


    /*
        PARTIALLY APPLIED FUNCTIONS
            - '_' ARE VERY POWERFUL
     */
    def concatenator(a : String, b : String, c : String) : String = a + b + c
    val insertName = concatenator("Hello, I'm ",_ : String, ", How are You")
    println(insertName("John"))

    // Here insertName is a partially applied function where some arguments are fixed but the others are not

    /*
        EXERCISES
            - Process a list of numbers and return their string representation with different formats
             Use the %4.2f, %8.6f and %14.12f with a curried formatter function

             - Difference
                    - between Functions and Methods
                    - Parameters by name vs 0-lambda
     */

    //Q1.
    def curriedFormatter(s : String)(num : Double) : String = s.format(num)
    val numbers = List(Math.PI,Math.E,1,9.8,1.3e-12)

    val simpleFormatter = curriedFormatter("%4.2f") _
    val seriousFormatter = curriedFormatter("%8.6f")(_)
    val preciseFormatter = curriedFormatter("%14.12f") _

    numbers.foreach(x => print(simpleFormatter(x) + " "))
    println()
    numbers.foreach(x => print(seriousFormatter(x) + " "))
    println()
    numbers.foreach(x => print(preciseFormatter(x) + " "))
    println()


    //Q2.

    def byName(n : => Int) = n + 1
    def byFunction(f : () => Int) = f() + 1

    def method : Int = 42
    def parenMethod() : Int = 43
    /*
        Calling byName and byFunction
            -int
            -method
            -parenMethod
            -lambda
     */

    byName(10) //Ok
    byName(method) //Ok
    byName(parenMethod()) //Ok
    byName(parenMethod) // OK, but beware ==> byName(parenMethod())

    //byName(() => 42 ) // Not Ok
    // but this is ok
    byName((() => 42)())

    // byFunction(45) // Not Ok
    // byFunction(method) // Not Ok!!!! no eta done by compiler here
    byFunction(parenMethod) // Eta Here
    byFunction(() => 45) // OK
    byFunction(parenMethod _) // Ok but _ is un-necessary

}
