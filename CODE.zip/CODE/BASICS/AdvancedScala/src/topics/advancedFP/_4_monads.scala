package topics.advancedFP

object _4_monads extends App {

    /*
        A Monad is a useful design pattern which is used for chaining useful operations
        and abstracting various work in the background

        ALL MONADS GENERALLY HAVE THE FOLLOWING COMPONENTS
            1. A Wrapper type to wrap elements to type of Monad -> example: numberWithLogs
            2. A Wrapper Function to take normal values and wrap them up to a monad
                - return, pure, unit
                -> example: wrapWithLogs
            3. Run Function which takes the wrapper function and an unwrapped input to perform
            a function
                - bind, flatMap, >>
                ->example: runWithLogs

         TYPES OF MONADS:
            1. Writer - Accumulation of Logs Data
            2. Option - Possibility of missing data
            3. Future/ Promise - Possibility for values to only become available later


         MONAD LAWS-
            1. Left Identity
                unit.flatMap(f) = f(x)

            2. Right Identity
                aMonadInstance.flatMap(unit) = aMonadInstance

            3. Associativity
                m.flatMap(f).flatMap(g) == m.flatMap(x => f(x).flatMap(g))
     */


    // Our Own Try Monad

    trait Attempt[+A] {
        def flatMap[B](f : A => Attempt[B]) :Attempt[B]
    }

    object Attempt{
        def apply[A](a : => A) : Attempt[A] =
            try{
                Success(a)
            } catch {
                case e: Throwable => Failure(e)
            }
    }

    case class Success[+A](value : A) extends Attempt[A]{
        override def flatMap[B](f: A => Attempt[B]): Attempt[B] =
            try{
                f(value)
            } catch {
                case e : Throwable => Failure(e)
            }
    }

    case class Failure(e : Throwable) extends Attempt[Nothing]{
        override def flatMap[B](f: Nothing => Attempt[B]): Attempt[B] = this
    }

    /*
        EXERCISE
            - Implement a Lazy[T] monad = computation which will only be executed when
                it's needed
            - Monads = unit + flatMap
             or
              Monads = unit + map + flatten

              Monad[T]{

                def flatMap[B](f : T => Monad[B] = ......

                def map[B](f : T => B) : Monad[B] => ???
                def flatten(m : Monad[Monad[T]]) : Monad[T] = ???
     */

    //Q1.

    class Lazy[+A](value : => A) {
        def flatMap[B](f : A => Lazy[B]) : Lazy[B] = f(value)
    }

    object Lazy {
        def apply[A](value : => A) : Lazy[A] = new Lazy[A](value)
    }
}

object example{

    println(runWithLogs(wrapperWithLogs(10),square))

    case class numberWithLogs (
        result : Int,
        logs : List[String]
    )

    def printLogs(input : numberWithLogs) : Unit = {
        println(s"The result is ${input.result}")
        input.logs.foreach(println)
    }

    def wrapperWithLogs(num : Int) : numberWithLogs = new numberWithLogs(num,Nil)

    def square(num : Int) : numberWithLogs =
        numberWithLogs(
            num * num,
            List(s"Squared $num to get ${num*num}")
        )

    def addOne(num : Int) : numberWithLogs =
        numberWithLogs(
            num + 1,
            List(s"Added 1 to $num to get ${num+1}")
        )

    def runWithLogs
    (
        input : numberWithLogs,
        transform : Int => numberWithLogs
    ) : numberWithLogs = {
        val newNumberWithLogs = transform(input.result)

        numberWithLogs(
            newNumberWithLogs.result,
            input.logs ++ newNumberWithLogs.logs
        )
    }

    val initial: numberWithLogs = wrapperWithLogs(10)
    val first: numberWithLogs  = runWithLogs(initial,addOne)
    val second: numberWithLogs  = runWithLogs(first,square)
    val third: numberWithLogs  = runWithLogs(second,addOne)
    val fourth: numberWithLogs  = runWithLogs(third,square)
    val fifth: numberWithLogs  = runWithLogs(fourth,addOne)

    printLogs(fifth)
}