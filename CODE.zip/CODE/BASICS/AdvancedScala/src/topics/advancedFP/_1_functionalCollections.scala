package topics.advancedFP

object _1_functionalCollections extends App {

    /*
        Imagine if Sets are functions.
        IN SCALA THEY ARE

        In official documentation sets are defined as:
            - trait Set[A] extends (A) => Boolean

        i.e.Extending a function from A to Boolean

        See MySet in Exercises.
     */

    /*
        FUNCTIONAL SEQ
            - Sequences are "callable" through an integer index

        trait Seq[+A] extends PartialFunction[Int, A]{
            def apply(index : Int) : A
        }

        val numbers = List(1,2,3)
        numbers(1) // 2
        numbers(3) // java.lang.IndexOutOfRangeException

            - Sequences are partial functions on the domain [0, 1, 2, 3, ... n-1]
            - Sequences are partial functions too
     */

    /*
        Functional Map
            - Maps are also "callable"

        trait Map[A, B] extends PartialFunction[A,B] {
            def apply(key : A) : B
            def get(key : A) :Option[B]
        }

            - A map is defined on the domain of its keys which is a sub-domain of A
            - A map is a Partial Function
     */
}
