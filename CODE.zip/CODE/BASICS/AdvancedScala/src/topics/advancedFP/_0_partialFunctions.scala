package topics.advancedFP

object _0_partialFunctions extends App {

    val aFunction = (x : Int) => x + 1 // Function1[Int,Int] === Int => Int
    // Defined on the Whole Integer Domain

    /*
        What if we want our function to only accept certain values like 1, 2, 5
     */

    class FunctionNotApplicable extends RuntimeException
    val aFussyFunction = (x : Int) => {
        if(x == 1) 10
        else if(x == 2) 20
        else if(x == 5) 100
        else throw new FunctionNotApplicable


    } // A messy implementation

    /*
        This function has the domain form {1,2,5} : IR
        Hence this function is also known as a partial function
     */
    val aNicerFussyFunction = (x : Int) => x match {
        case 1 => 10
        case 2 => 20
        case 5 => 100
        case _ => throw new FunctionNotApplicable
    } // Better but still we can write this in an even better way

    /*
        This is a Partial Function Literal and is equivalent in implementation with the above
        match statement but this literal is a proper partial function and is only assignable
        to a PartialFunction1 whereas the above is a Proper/Total function
     */
    val aPartialFunction : PartialFunction[Int,Int] ={
        case 1 => 10
        case 2 => 20
        case 5 => 100
    }

    println(aPartialFunction(2))
    // println(aPartialFunction(11)) // Will give a match error

    /*
        Utilities
    */

    println(aPartialFunction.isDefinedAt(65)) // Is the function defined for the given argument

    // Lift - to total function using Options
    val lifted = aPartialFunction.lift // Int => Option[Int]
    println(lifted(5))
    println(lifted(100))

    // orElse -> Extending the domain of a Partial Function
    val apfChain = aPartialFunction.orElse[Int,Int]{
        case 102 => 343
    }

    println(apfChain(102))

    // Partial Functions extend Normal Functions
    // Hofs Accept Partial Functions as well

    /*
        Unlike Total functions, Partial Functions can have only one Parameter type
     */

    /*
        EXERCISES
     */

    //Q1. Your own PF

    val aManualFussyFunction = new PartialFunction[Int,Int] {

        override def apply(x: Int): Int = x match {
            case 1 => 10
            case 2 => 20
            case 5 => 100
        }

        override def isDefinedAt(x: Int): Boolean = {
            if (x == 1 || x == 2 || x == 5 ) true

            else false
        }
    }

    //Q2. A Chatbot
    val chatBot : PartialFunction[String,String] ={
        case "Hello" => "Hello, My name is HAL9000"
        case "Call Mom" => "Cannot find your phone without your credit card"
        case "Goodbye" => "Once you start talking to me, there is no going back."
    }

    scala.io.Source.stdin.getLines().foreach(str => println("Chatbot says : " +  chatBot(str)))
}
