package topics.advancedFP

import exercises.{MyStream,Cons,EmptyStream}

object _3_lazyEvaluation extends App {

    // val x : Int = throw new RuntimeException // This will crash the program

    // Lazy delays the evaluation of values
    lazy val x: Int = throw new RuntimeException

    /*
        LAZY VALUES GET EVALUATED ONCE ONLY WHEN THEY ARE USED FOR THE FIRST TIME
     */

    lazy val y = {
        println("This is the only time you will see this message")
        45
    }

    println(y) // used here for the first time so the value gets evaluated
    println(y)

    /*
        Examples of implications
     */

    // 1. Side Effects
    def sideEffectCondition: Boolean = {
        println("BOO"); true
    }

    def simpleCondition: Boolean = false

    lazy val lazyCondition = sideEffectCondition
    // Here the lazy condition never gets evaluated since the first value is false
    // and compiler doesn't need to check the second value
    // So any side effect inside the lazy condition will not be evaluated
    println(if (simpleCondition && lazyCondition) "YES" else "NO")

    // 2. Call By Name
    def byNameMethod(n: => Int): Int = n + n + n + 1

    def retrieveMagicNumber: Int = {
        // side effect of a long computation
        println("Waiting")
        Thread.sleep(1000)
        42
    }

    println(byNameMethod(retrieveMagicNumber))
    /*
        THIS IS UNNECESSARY TO CALL A VALUE THREE TYPES
        WE USE LAZY VALS FOR THIS
     */

    /*
        CALL BY NEED
     */
    def byNeedMethod(n: => Int): Int = {
        val t = n
        t + t + t + 1
    }

    println(byNeedMethod(retrieveMagicNumber))


    // 3. Filtering with Lazy

    def greaterThan20(n: Int): Boolean = {
        println(s"Is $n Greater than 20?")
        n > 20
    }

    def lessThan30(n: Int): Boolean = {
        println(s"Is $n Less than 30?")
        n < 30
    }

    val numbers = List(1, 25, 40, 5, 23)
    val lt30 = numbers.filter(lessThan30)
    val gt20 = lt30.filter(greaterThan20)
    println(gt20)
    /*
        SIDE EFFECTS ARE EXECUTED 5 FIVES FIRST AND THEN ONLY 4 TIMES BECAUSE 40 !< 30
     */

    println()
    val lt30lazy = numbers.withFilter(lessThan30)
    val gt20lazy = lt30lazy.withFilter(greaterThan20)
    println(gt20lazy) // A monadic is returned

    gt20lazy.foreach(println)
    //  HERE the side effects and predicates are used on a by-need basis
    // The withFilter uses lazy vals in its implementation

    for {
        a <- numbers if a % 2 == 0
    } yield a + 1
    // IS THE SAME AS

    numbers.withFilter(_ % 2 == 0).map(_ + 1)

    /*
        EXERCISE 1
            - Implement a lazily evaluated, singly linked Stream of elements

            In MyStream class file
     */

    /*
        EXERCISE 2
            - Implement the fibonacci sequence using the infinite streams
            - Implement Eratosthenes sieve
     */

    //Q1.
    val numberStream = MyStream.from(1)(_ + 1)
    def fibonacci(first : BigInt, second : BigInt) : MyStream[BigInt] =
        new Cons[BigInt](first, fibonacci(second,first + second))

    println(fibonacci(1,1).take(100).toList())

    //Q2.
    def eratosthenes(list : MyStream[Int]) : MyStream[Int] ={
        if(list.isEmpty) list
        else new Cons(list.head, eratosthenes(list.tail.filter(_ % list.head != 0)))
    }

    println(eratosthenes(MyStream.from(2)(_ + 1)).take(100).toList())
}