package exercises

import scala.annotation.tailrec

abstract class MyStream[+A] {
    def isEmpty : Boolean
    def head : A
    def tail : MyStream[A]

    def #::[B >: A](element : B) : MyStream[B] // prepend operator
    def ++[B >: A](anotherStream : => MyStream[B]) : MyStream[B] // concatenate two streams

    def foreach(f : A => Unit) : Unit
    def map[B](f : A => B) : MyStream[B]
    def flatMap[B](f : A => MyStream[B]) : MyStream[B]
    def filter(predicate : A => Boolean) : MyStream[A]

    def take(n : Int) : MyStream[A] // Takes the first n elements out of the stream
    def takeAsList(n : Int) : List[A] = take(n).toList()
    // for takeAsList
    @tailrec
    final def toList[B >: A](acc : List[B] = Nil) : List[B] = {
        if(isEmpty) acc.reverse

        else tail.toList(head :: acc)
    }
}

object EmptyStream extends MyStream[Nothing]{

     def isEmpty: Boolean = true
     def head: Nothing = throw new NoSuchElementException("Head is not present for Empty Stream")
     def tail: MyStream[Nothing] = throw new NoSuchElementException("Tail is not present for Empty Stream")

     def #::[B >: Nothing](element: B): MyStream[B] = new Cons(element, this)
     def ++[B >: Nothing](anotherStream: => MyStream[B]): MyStream[B] = anotherStream

     def foreach(f: Nothing => Unit): Unit = ()
     def map[B](f: Nothing => B): MyStream[B] = this
     def flatMap[B](f: Nothing => MyStream[B]): MyStream[B] = this
     def filter(predicate: Nothing => Boolean): MyStream[Nothing] = this

     def take(n: Int): MyStream[Nothing] = this

}

/*
    Here tailStream will not be evaluated until used, and it will not be created because
    of lazy identifier until first use.

    So neither the parameters nor the val create the tail until it is absolutely needed

    i.e. tail = tailStream
    due to lazy evaluation the right side of the assignment which is tailStream does not
        get evaluated until first use of tail and tailStream itself will not get
        evaluated due to call-by-name until tailStream is used(which is at assignment to tail)

   SO the entire expression only gets evaluated when needed

   THIS MEANS THAT WHEN WE ARE CREATING NEW CONS LINK THE TAIL PART IS ALWAYS JUST
   REMEMBERED BUT NEVER EVALUATED

   SO When we say val stream = new Stream(2, new Cons .....))
   the compiler only remembers that 1 is connected to some other Stream but the stream
   itself is not known until it is needed( or used)
 */
class Cons[+A](headElement : A, tailStream : => MyStream[A]) extends MyStream[A]{

    def isEmpty: Boolean = false
    override val head: A = headElement
    override lazy val tail: MyStream[A] = tailStream // call by need

    /*
        How it still preserves lazy evaluation
            - val s = new Cons(1, EmptyStream)
              val prepended = 1 #:: s => new Cons(1,s) -> S is still lazily evaluated
              and it will not
     */
    def #::[B >: A](element: B): MyStream[B] = new Cons(element,this)
    /*
        EVEN HERE WHEN WE SAY tail ++ anotherStream
            - The concatenation only gets evaluated only when we explicitly call it
            - so right now, the compiler does not know that the two streams are
            concatenated, it only knows that after the tail we have to perform the
            concatenation when needed
     */
    def ++[B >: A](anotherStream: => MyStream[B]): MyStream[B] = new Cons(head, tail ++ anotherStream)

    def foreach(f: A => Unit): Unit = {
        f(head)
        tail.foreach(f)
    }

    def map[B](f: A => B): MyStream[B] = new Cons(f(head),tail.map(f)) // still preserves lazy evaluation
    def flatMap[B](f: A => MyStream[B]): MyStream[B] =  f(head) ++ tail.flatMap(f)
    def filter(predicate: A => Boolean): MyStream[A] = {
        if(predicate(head)) new Cons(head,tail.filter(predicate))

        else tail.filter(predicate)
    } // The method as a whole preserves lazy evaluation

    def take(n: Int): MyStream[A] = {
        if(n <= 0) EmptyStream

        else if(n == 1) new Cons(head,EmptyStream)

        else new Cons(head,tail.take(n-1))
    }
}

object MyStream {
     def from[A](start : A)(generator : A => A) : MyStream[A] = {
         new Cons(start, MyStream.from(generator(start))(generator))
     }
}

object StreamTesting extends App{

    val naturals = MyStream.from(1)(x => x + 1)

    println(naturals.head)
    println(naturals.tail.head)
    println(naturals.tail.tail.head)

    (0 #:: naturals).take(500).foreach(println)
    val startFrom0 = 0 #:: naturals
    println(startFrom0.flatMap(x => new Cons(x,new Cons(x + 1,EmptyStream))).take(10).toList())
}