package exercises

import scala.annotation.tailrec

trait MySet[A] extends (A => Boolean) {

    def apply(elem : A) : Boolean = contains(elem)
    def contains(elem : A) : Boolean
    def +(elem : A) : MySet[A]
    def ++(anotherSet : MySet[A]) : MySet[A]

    def map[B](f : A => B) : MySet[B]
    def flatMap[B](f : A => MySet[B]) : MySet[B]
    def filter(predicate : A => Boolean) : MySet[A]

    def forEach(f : A => Unit) : Unit

    /*
        EXERCISE 1
            - Removing an element
            - intersection with another set
            - difference with another set
     */

    def -(elem : A) : MySet[A]
    def &(anotherSet : MySet[A]) : MySet[A]
    def --(anotherSet : MySet[A]) : MySet[A]

    /*
        EXERCISE 2
            - Negation of a Set
     */

    def unary_! : MySet[A]
}

class EmptySet[A] extends MySet[A]{
    override def contains(elem : A) : Boolean = false
    def +(elem:  A): MySet[A] = new NonEmptySet[A](elem, this)
    def ++(anotherSet : MySet[A]) : MySet[A] = anotherSet

    def map[B](f: A => B): MySet[B] = new EmptySet[B]
    def flatMap[B](f: A => MySet[B]): MySet[B] = new EmptySet[B]
    def filter(predicate: A => Boolean): MySet[A] = this

    override def forEach(f: A => Unit): Unit = ()

    // After Exercise 1

    def -(elem : A) : MySet[A] = this
    def &(anotherSet : MySet[A]) : MySet[A] = this
    def --(anotherSet : MySet[A]) : MySet[A] = this

    // After Exercise 2

    override def unary_! : MySet[A] = new PropertyBasedSet[A](_ => true)
}

/*
    THE ALL INCLUSIVE SET IS TOO COMPLEX AND GENERIC FOR OUR PURPOSE
    So we will now create a PropertyBasedSet

 |------------------------------------------------------------------------------------------|
class AllInclusiveSet[A] extends MySet[A]{
    override def contains(elem: A): Boolean = true
    override def +(elem: A): MySet[A] = this
    override def ++(anotherSet: MySet[A]): MySet[A] = this

    // naturals = AllInclusiveSet[Int]
    // naturals.map(x % 3)
    // [0, 1 ,2] -> From infinite Set to a Finite Set


    def map[B](f: A => B): MySet[B] = ???
    def flatMap[B](f: A => MySet[B]): MySet[B] = ???
    def filter(predicate: A => Boolean): MySet[A] = ??? // Property Set
    def forEach(f: A => Unit): Unit = ???
    def -(elem: A): MySet[A] = ???
    // No way to implement these methods in a feasible manner hence we will now abandon this method of class definition

    override def &(anotherSet: MySet[A]): MySet[A] = filter(anotherSet)
    override def --(anotherSet: MySet[A]): MySet[A] = filter(!anotherSet)

    override def unary_! : MySet[A] = new EmptySet[A]
}
|------------------------------------------------------------------------------------------|
 */

// All elements of type A which satisfy the property => {x <- A | property(x) = true}
class PropertyBasedSet[A](property : A => Boolean) extends MySet[A]{

    override def contains(elem: A): Boolean = property(elem)

    // { x <- A | property(x) = true || x == element }
    override def +(elem: A): MySet[A] = new PropertyBasedSet[A](x => property(x) || x == elem) // new Boolean function

    // { x <- A | property(x) = true || anotherSet contains x }
    override def ++(anotherSet: MySet[A]): MySet[A] = new PropertyBasedSet[A](x => property(x) || anotherSet(x))

    // Since we cannot say what the resultant set will be, finite or infinite
    // it is not possible to define the map, flatMap and forEach properties
    override def map[B](f: A => B): MySet[B] = politelyFail
    override def flatMap[B](f: A => MySet[B]): MySet[B] = politelyFail
    override def forEach(f: A => Unit): Unit = politelyFail

    override def filter(predicate: A => Boolean): MySet[A] = new PropertyBasedSet[A](x => property(x) && predicate(x))
    override def -(elem: A): MySet[A] = filter(x => x != elem)
    override def &(anotherSet: MySet[A]): MySet[A] = filter(anotherSet)
    override def --(anotherSet: MySet[A]): MySet[A] = filter(!anotherSet)
    override def unary_! : MySet[A] = new PropertyBasedSet[A](x => !property(x))

    //

    def politelyFail: Nothing = throw new IllegalArgumentException("Really Deep Rabbit Hole")
}


class NonEmptySet[A](headElement : A, tailSet : MySet[A] ) extends MySet[A]{

    override def contains(elem : A) : Boolean = headElement == elem || tailSet.contains(elem)

    def +(elem : A) : MySet[A] = {
        if (this contains elem) this

        else new NonEmptySet[A](elem,this)
    }

    def ++(anotherSet : MySet[A]) : MySet[A] = tailSet ++ anotherSet + headElement

    //

    def map[B](f : A => B) : MySet[B] = (tailSet map f) + f(headElement)
    def flatMap[B](f: A => MySet[B]): MySet[B] = (tailSet flatMap f) ++ f(headElement)
    def filter(predicate : A => Boolean) : MySet[A] = {
        val filteredTail = tailSet filter predicate

        if(predicate(headElement)) filteredTail + headElement

        else filteredTail
    }

    override def forEach(f: A => Unit): Unit = {
        f(headElement)
        tailSet forEach f
    }

    // Exercise
    def -(elem:  A):MySet[A] = {
        if(headElement == elem) tailSet

        else tailSet - elem + headElement
    }

    def &(anotherSet : MySet[A]) : MySet[A] = filter(x => anotherSet.contains(x))
    // This can also be written as
    // filter(x => anotherSet(x)) -> Set is functional i.e. contains is the same contract as apply
    // filter(anotherSet)
    // This means that intersection and filtering are the one and the same for this set(Since It is a Functional Set).

     def --(anotherSet : MySet[A]) : MySet[A] = filter(x => !anotherSet(x))

    // After Exercise 2

    override def unary_! : MySet[A] = new PropertyBasedSet[A](x => !this.contains(x))
}


object MySet {

    def apply[A](values : A*) : MySet[A] = {
        @tailrec
        def buildSet(valSeq : Seq[A], acc : MySet[A]) : MySet[A] = {
            if(valSeq.isEmpty) acc

            else  buildSet(valSeq.tail, acc + valSeq.head)
        }

        buildSet(values.toSeq, new EmptySet[A])
    }
}

object MySetPg extends App{
    val s = MySet(1,2,3,4,5)
    s + 6 ++ MySet(-1,-2) + 3 flatMap(x => MySet(x, x*10)) filter(_ % 2== 0) forEach println

    val negative = !s // -> all the naturals with values not equal to 1,2,3,4,5

    println(negative(2))
    println(negative(100))
}
