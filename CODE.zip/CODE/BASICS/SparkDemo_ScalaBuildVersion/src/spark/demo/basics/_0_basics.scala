package spark.demo.basics

import org.apache.spark.sql.SparkSession

object _0_basics extends App {

    val spark =
        SparkSession.builder()
            .master("local[*]")
            .appName("_0_basics")
            .getOrCreate()

    // Reading data -> Creating a Reader
    // read method -> Returns a data frame which can be used to read non-streaming data
    private val df =
        spark.read
        .option("header", value = true)
        .csv("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/data/AAPL.csv")


    df.show()

    println("THE SCHEMA OF THE DATA FRAME -> ")
    df.printSchema() // Initially all the fields are considered as strings (the csv loader)

    val idf =
        spark.read
        .option("header",value = true)
        .option("inferSchema",value = true)
        .csv("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/data/AAPL.csv")

    idf.show()
    println("THE SCHEMA OF THE NEW DATA FRAME -> ")
    idf.printSchema()
    spark.close()

}
