package spark.demo.basics

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions.{col, row_number, year}
//import org.scalatest.flatspec.AnyFlatSpec

//
object _5_testingCode extends App {
    /*
        Testing -> Vey Needed to ensure out application is running as expected
    */

    // See the sbt version of spark
}
