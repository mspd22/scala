package spark.demo.basics

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions.{col, row_number, year}

object _4_partitions_AST_Optimisations_lazyEvaluation extends App {

    val spark =
        SparkSession.builder()
        .appName("SQL EXP")
        .master("local[*]")
        .getOrCreate()
//    spark.conf.set("spark.logConf", "false")
    /*
        We can use the functions in apache.spark.sql.functions to manipulate and modify columns but there is another way
        in which we can do this
            - SQL EXPRESSIONS written as String literals which will be interpreted at run time
            - No Compile time safety
     */

    val df =
        spark.read
        .option("header", value = true)
        .option("inferSchema", value = true)
        .csv("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/data/AAPL.csv")

    df.show()
    df.printSchema()

    val renameList : List[Column] = List(
        col("Date").as("date"),
        col("Open").as("open"),
        col("High").as("high"),
        col("Low").as("low"),
        col("Close").as("close"),
        col("Adj Close").as("adjClose"),
        col("Volume").as("volume")
    )

    val stockData = df.select(renameList : _*)

    /*
        Partitioning -> Level of parallelism

        Partition =>  Grouping of a set into non-empty, pairwise-disjoint sets, which cover the entire input set.

        We aim for equal size partitions, but it is not always possible and one of the major challenges of the performance
        There will be one task for processing each partition; The task is scheduled on the executors by the driver
     */

    /*
        AST, Logical Plan and Catalyst
            - Spark SQL provides us with a fully declarative and structured API
            - Meaning it defines operators which we can use to tell spark how the result can be derived from the input
                -(withColumn, groupBY, count)
            - Spark SQL is also called the structured API as it deals with structured data as Datasets have a schema
            - Therefore Spark knows what's in the columns of a DataFrame
            - By calling the API, we chain these operators, while spark assembles an abstract internal representation
                of the data : Abstract Syntax Tree (AST)
                    - The transformations are built as a tree and Spark sees this tree to decide if there could be any
                     optimisations(catalyst) to the transformation we made
                    - The internal representation is abstract so it doesn't depend on what input API we are using(python,R etc)
                    - Then Spark looks at the tree with a catalyst or optimiser
            - The result is an optimised logical plan
                - A lineage is also generated so we know which dataframe came from where
     */

    import spark.implicits._
    val window = Window.partitionBy(year($"date").as("Year")).orderBy($"close".desc)

    stockData
    .withColumn("rank", row_number().over(window))
    .filter($"rank" === 1)
    .sort($"close".desc)
    .explain(extended = true)

    /*
    == Parsed Logical Plan ==
    'Sort ['close DESC NULLS LAST], true
    +- Filter (rank#69 = 1)
       +- Project [date#53, open#54, high#55, low#56, close#57, adjClose#58, volume#59, rank#69]
          +- Project [date#53, open#54, high#55, low#56, close#57, adjClose#58, volume#59, rank#69, rank#69]
             +- Window [row_number() windowspecdefinition(year(cast(date#53 as date)), close#57 DESC NULLS LAST, specifiedwindowframe(RowFrame, unboundedpreceding$(), currentrow$())) AS rank#69], [year(cast(date#53 as date))], [close#57 DESC NULLS LAST]
                +- Project [date#53, open#54, high#55, low#56, close#57, adjClose#58, volume#59]
                   +- Project [Date#10 AS date#53, Open#11 AS open#54, High#12 AS high#55, Low#13 AS low#56, Close#14 AS close#57, Adj Close#15 AS adjClose#58, Volume#16 AS volume#59]
                      +- Relation[Date#10,Open#11,High#12,Low#13,Close#14,Adj Close#15,Volume#16] csv

    == Analyzed Logical Plan ==
    date: timestamp, open: double, high: double, low: double, close: double, adjClose: double, volume: int, rank: int
    Sort [close#57 DESC NULLS LAST], true
    +- Filter (rank#69 = 1)
       +- Project [date#53, open#54, high#55, low#56, close#57, adjClose#58, volume#59, rank#69]
          +- Project [date#53, open#54, high#55, low#56, close#57, adjClose#58, volume#59, rank#69, rank#69]
             +- Window [row_number() windowspecdefinition(year(cast(date#53 as date)), close#57 DESC NULLS LAST, specifiedwindowframe(RowFrame, unboundedpreceding$(), currentrow$())) AS rank#69], [year(cast(date#53 as date))], [close#57 DESC NULLS LAST]
                +- Project [date#53, open#54, high#55, low#56, close#57, adjClose#58, volume#59]
                   +- Project [Date#10 AS date#53, Open#11 AS open#54, High#12 AS high#55, Low#13 AS low#56, Close#14 AS close#57, Adj Close#15 AS adjClose#58, Volume#16 AS volume#59]
                      +- Relation[Date#10,Open#11,High#12,Low#13,Close#14,Adj Close#15,Volume#16] csv

    == Optimized Logical Plan ==
    Sort [close#57 DESC NULLS LAST], true
    +- Filter (isnotnull(rank#69) && (rank#69 = 1))
       +- Window [row_number() windowspecdefinition(year(cast(date#53 as date)), close#57 DESC NULLS LAST, specifiedwindowframe(RowFrame, unboundedpreceding$(), currentrow$())) AS rank#69], [year(cast(date#53 as date))], [close#57 DESC NULLS LAST]
          +- Project [Date#10 AS date#53, Open#11 AS open#54, High#12 AS high#55, Low#13 AS low#56, Close#14 AS close#57, Adj Close#15 AS adjClose#58, Volume#16 AS volume#59]
             +- Relation[Date#10,Open#11,High#12,Low#13,Close#14,Adj Close#15,Volume#16] csv

    == Physical Plan ==
    *(4) Sort [close#57 DESC NULLS LAST], true, 0
    +- Exchange rangepartitioning(close#57 DESC NULLS LAST, 200)
       +- *(3) Filter (isnotnull(rank#69) && (rank#69 = 1))
          +- Window [row_number() windowspecdefinition(year(cast(date#53 as date)), close#57 DESC NULLS LAST, specifiedwindowframe(RowFrame, unboundedpreceding$(), currentrow$())) AS rank#69], [year(cast(date#53 as date))], [close#57 DESC NULLS LAST]
             +- *(2) Sort [year(cast(date#53 as date)) ASC NULLS FIRST, close#57 DESC NULLS LAST], false, 0
                +- Exchange hashpartitioning(year(cast(date#53 as date)), 200)
                   +- *(1) Project [Date#10 AS date#53, Open#11 AS open#54, High#12 AS high#55, Low#13 AS low#56, Close#14 AS close#57, Adj Close#15 AS adjClose#58, Volume#16 AS volume#59]
                      +- *(1) FileScan csv [Date#10,Open#11,High#12,Low#13,Close#14,Adj Close#15,Volume#16] Batched: false, Format: CSV, Location: InMemoryFileIndex[file:/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/..., PartitionFilters: [], PushedFilters: [], ReadSchema: struct<Date:timestamp,Open:double,High:double,Low:double,Close:double,Adj Close:double,Volume:int>
     */

    /*
        Lazy Evaluations - Just like Scala will only remember the transformation and evaluate it only when needed
     */
}
