package spark.demo.basics

import org.apache.spark.sql.functions.{col, concat, lit}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object _1_datasetAndColumns  extends App {

    /*
        The dataset API
            - Dataset is the main abstraction introduced in Spark SQL
            - Spark SQL is an abstraction over Spark core's RDDs
            - The dataset API defines a DSL(domain-specific-language, declarative, not using Scala functions)
            - The data frame is basically a type definition of a Dataset of Row, whereas a Row is a quite generic domain object
            - Therefore Wem refer to Dataframes as untyped/generically typed views on our data
                `type DataFrame = Dataset[Row]`
                `Row` is a generic object (untyped view)
     */

    val spark =
        SparkSession.builder()
        .appName("_1_dataset")
        .master("local[*]")
        .getOrCreate()

    spark.conf.set("spark.logConf", "false")

    val df : DataFrame =
        spark.read.
        option("header",value = true)
        .option("inferSchema", value = true)
        .csv("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/data/AAPL.csv")

    /*
        Referencing Columns
            - DSL API
     */

    df.select("Date","Open","Close").show()

    /*
        The select method accepts two types of inputs, String or Column type
     */

    // How to convert String to Column type
    val column = df("Date") // apply method of dataframe returns a column type of arg
    col("Date") // Import a method to convert them
    import spark.implicits._
    $"Date" // An implicit method to convert them

    df.select(col("Date"), $"Open",df("Close")).show()

    // df.select("Date",$"Open",df("Close")) -> Do not mix the arg types compiler will give error

    // Column methods

    // 1. Modify Values
    val colOpen =  df("Open")
    val newColOpen1 = colOpen.plus(2.0)
    df.select(newColOpen1).show()
    // or
    val newColOpen2 = colOpen + 2.0
    df.select(newColOpen2).show()

    // 2. Casting into another datatype
    // Just for referencing the column in the dataframe
    val newColOpen3 = colOpen.cast(StringType).as("Open converted to String") // as -> Aliases
    df.select(newColOpen3).show() // -> WE are creating a new column here, in memory

    // 3. Comparing columns
    df.select(colOpen,newColOpen2,newColOpen3)
    .filter(newColOpen2 > 2.0)
    .filter(newColOpen2 > colOpen)
    .show() // Will give all the rows

    df.select(colOpen,newColOpen2,newColOpen3)
    .filter(newColOpen2 > 2.0)
    .filter(newColOpen2 > colOpen)
    .filter(newColOpen2 === colOpen) // this is false
    .show()

    // 4. Lit Method
    val litCol = lit(2.0) // Creates a column full of the literal we define
    df.select(litCol).show()

    // 5. Concat
    val newColOpenString = concat(lit("Open : "),newColOpen3).as("Open String Hello World")
    df.select(newColOpenString).show()

    spark.close()
}

