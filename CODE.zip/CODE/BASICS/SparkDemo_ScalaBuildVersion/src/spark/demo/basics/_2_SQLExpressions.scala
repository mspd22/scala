package spark.demo.basics

import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions.{col, current_timestamp, expr}
import org.apache.spark.sql.types.StringType

object _2_SQLExpressions extends App {

    val spark =
            SparkSession.builder()
            .appName("SQL EXP")
            .master("local[*]")
            .getOrCreate()

    /*
        We can use the functions in apache.spark.sql.functions to manipulate and modify columns but there is another way
        in which we can do this
            - SQL EXPRESSIONS written as String literals which will be interpreted at run time
            - No Compile time safety
     */

    val df =
        spark.read
        .option("header", value = true)
        .option("inferSchema", value = true)
        .csv("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/data/AAPL.csv")

    df.show()
    df.printSchema()

    val currTime1 = expr("cast(current_timeStamp() as string) as timeStampSQL")
    val currTime2 = current_timestamp().cast(StringType).as("timeStampFunc")

    df.select(currTime1,currTime2).show()

    // The problem is
//    val currTime3 = expr("cast(currents_timeStamp() as string) as timeStampSQL")
    // The above expression will throw an error during run time as it is not compile time safe and the compiler cannot
    // resolve the string provided, it will not find the mistake in currents

    // ALSO can do
    df.selectExpr("cast(Date as string)","Open + 2.0","current_timestamp()").show()

    // WE can run SQL queries through Spark SQL
    df.createTempView("df")
    spark.sql("select * from df").show()

    /*
        Assignment
            - Rename all columns to be of camelCase
            - Add a column containing the diff between `open` and `close`
            - Filter the days when the 'close' price was more than 10% higher than the open price
     */

    // 1. Rename
//    df.withColumnRenamed("Open","open").withColumnRenamed("Close","close"). ....

    // Even better way

    val renameList : List[Column] = List(
        col("Date").as("date"),
        col("Open").as("open"),
        col("High").as("high"),
        col("Low").as("low"),
        col("Close").as("close"),
        col("Adj Close").as("adjClose"),
        col("Volume").as("volume")
    )

    df.select(renameList : _*).show() // var args splice -> : _*

    // Also
    df.select(df.columns.map(c => col(c).as(c.toLowerCase)) : _*).show() // Only lower case

    // 2. Add diff
    val stockPrice = df.select(renameList : _*)
        .withColumn("diff", col("close") - col("open"))

    stockPrice.show()

    // 3. Filter
    stockPrice.filter(col("close") > col("open") * 1.1)
    .show()
    spark.close()
}
