package spark.demo.basics

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, row_number, year}
import org.apache.spark.sql.{Column, SparkSession, functions}

object _3_aggregationsAndWindows  extends App {

    val spark =
        SparkSession.builder()
        .appName("SQL EXP")
        .master("local[*]")
        .getOrCreate()

    /*
        We can use the functions in apache.spark.sql.functions to manipulate and modify columns but there is another way
        in which we can do this
            - SQL EXPRESSIONS written as String literals which will be interpreted at run time
            - No Compile time safety
     */

    val df =
        spark.read
        .option("header", value = true)
        .option("inferSchema", value = true)
        .csv("/Users/s0m12qs/Desktop/M S Pramod/CODE/BASICS/SparkDemo_ScalaBuildVersion/data/AAPL.csv")

    df.show()
    df.printSchema()

    val renameList : List[Column] = List(
        col("Date").as("date"),
        col("Open").as("open"),
        col("High").as("high"),
        col("Low").as("low"),
        col("Close").as("close"),
        col("Adj Close").as("adjClose"),
        col("Volume").as("volume")
    )

    val stockData = df.select(renameList : _*)

    // Group By
    import spark.implicits._
    stockData
        .groupBy(year($"date").as("Year"))
        .agg(functions.max($"close").as("Max Close"),functions.avg($"close").as("Avg Close"))
        .sort($"Max Close".desc)
        .show() // grouping by year and finding the max and Avg of each year

    // Short Hand
    stockData
        .groupBy(year($"date").as("Year"))
        .max("close","high")
        .show()

    /*
        Window Functions
            - With groupBy we could only see the columns we performed the aggregations on but how about the
            time when we want to see the entire table
            - Window functions can be used as constructs to apply a partitioned view and allowing arbitrary
            transformations on the grouped data
     */

    val window = Window.partitionBy(year($"date").as("Year")).orderBy($"close".desc)

    stockData
        .withColumn("rank", row_number().over(window))
        .filter($"rank" === 1)
        .sort($"close".desc)
    .show()

    spark.close()
}
