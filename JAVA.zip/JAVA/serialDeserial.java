import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import include.user;

public class serialDeserial implements Serializable {
    
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        
        user client = new user("Pramod","abc@123");

        client.sayHello();

        /* Steps to Serialize
	     * ---------------------------------------------------------------
	   	 * 1. Your class should implement Serializable interface
	     * 2. add import java.io.Serializable;
	     * 3. FileOutputStream fileOut = new FileOutputStream(file path)
	     * 4. ObjectOutputStream out = new ObjectOutputStream(fileOut);
	     * 5. out.writeObject(objectName)
	     * 6. out.close(); fileOut.close();
	     * ---------------------------------------------------------------
        */

        FileOutputStream fios = new FileOutputStream("userData.ser");
        ObjectOutputStream obos = new ObjectOutputStream(fios);
        obos.writeObject(client);

        fios.close();
        obos.close();

        System.out.println("Object Info stored\n\n ");

        /* Steps to Deserialize
	     * ---------------------------------------------------------------
	     * 1. Your class should implement Serializable interface
	     * 2. add import java.io.Serializable;
	     * 3. FileInputStream fileIn = new FileInputStream(file path);
	     * 4. ObjectInputStream in = new ObjectInputStream(fileIn);
	     * 5. objectNam = (Class) in.readObject();
	     * 6. in.close(); fileIn.close();
        */

        user request = null;

        FileInputStream fiis = new FileInputStream("userData.ser");
        ObjectInputStream obis = new ObjectInputStream(fiis);
        request = (user) obis.readObject();

        obis.close();
        fiis.close();

        System.out.println(request.name);
        System.out.println(request.password);
        request.sayHello();
    }
}
