public class stringMethods {
    public static void main(String[] args) {
        
        String name = "Bro";

        /* 
        
        System.out.println(name.equals("Bro"));
        System.out.println(name.equalsIgnoreCase("BRO"));
        System.out.println(name.length());
        System.out.println(name.charAt(0));
        System.out.println(name.indexOf('o'));
        System.out.println(name.isEmpty());
        System.out.println(name.isBlank());
        System.out.println(name.toLowerCase());
        System.out.println(name.toUpperCase());
        System.out.println("   Bro   ".trim());
        System.out.println(name.replace('o', '0'));
        
        */

        System.out.printf("Hello %s\n",name);

        /*
         * 
         * conversion characters -> after the %-sign
         * %d -> decimal
         * %s -> String
         * %c -> chaaracter
         * %s -> Strings
         * %b -> boolean
         * %f -> floats and doubles
         * 
        */

        //width -> minimum number of characters to be given as output
        System.out.printf("\nThis is an examle of the width field in printf method %10s",name);

        System.out.println();
        //precision -> set a number of deicmal points to be displayed after the decimal point
        System.out.printf("%.3f\n",10.3238342342);
        System.out.printf("%.5f\n",10.3238342342);
        System.out.printf("%.7f\n",10.3238342342);

        /*
         * -> adda an effect based on the flag used
         * 
         * - : left justify
         * + : ouypuy the number along with its sign (+/-)
         * 0 : numeric values are zero padded
         * , comma grouping seperator if numbers > 1000
         * 
        */


    }
}
