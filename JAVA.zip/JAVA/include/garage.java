package include;

public class garage {

    public void park(car carObj){
        System.out.println("\nThe car " + carObj.make + ' ' + carObj.model + " is parked.");
    }
    
}
