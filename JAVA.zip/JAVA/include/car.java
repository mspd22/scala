package include;

public class car {
    
    // WE HAVE TO DECLARE THEM AS PUBLIC BECAUSE OF THE VISIBILITY BETWEEN THE DIFFERNT PACKAGES.
    public String make = "Chevorlet";
    public String model = "Corvette";
    public String color = "Blue";
    public int year = 2020;
    public double price = 50000.00;

    public car(){

    }
    
    public car(String make,String model,String color,int year,double price){

        this.make = make;
        this.model = model;
        this.color = color;
        this.year = year;
        this.price = price;
    }

    public void drive(){
        System.out.printf("YOU ARE DRIVING THE %s %s made in %d.\n",make,model,year);
    }

    public void brake(){
        System.out.println("YOU HAVE STEPPED ON THE BRAKES.");
    }
}   
