package include;

public class Human {
    
    // CONSTRUCTOR

    public String name;
    public int age;
    public double weight;
    public String designation = "";

    public Human(String name,int age,double weight){
        this.name = name;
        this.age =  age;
        this.weight = weight;
    }

    public Human(String name,int age,double weight,String designation){


    }
    /*
     *
     * overloaded constructors are same as overloaded methods 
     * the name is same but the parameters are different
     *  
    */

    public void eat(){
        System.out.println(this.name + " is eating");
    }

    public void drink(){
        System.out.println(this.name + " is drinking");
    }

    public String toString(){
        return "\nNAME : " + this.name + "\nAGE : " + this.age + "\nWEIGHT : " + this.weight;
    }
}
