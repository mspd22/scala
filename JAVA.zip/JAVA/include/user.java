package include;

import java.io.Serializable;

public class user implements Serializable  { // implement Serializable to make it Serializable 
    
    public String name;
    public String password;

    public user(String name,String password){
        this.name = name;
        this.password = password;
    }

    
    
    public void sayHello(){
        System.out.println("Hello " + this.name);
    }    
}
