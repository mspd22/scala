package include;

public class genericClass <Thing> {
    
    Thing x;

    public genericClass(Thing x){
        this.x  = x;
    }

    public Thing getValue(){
        return x;
    }
}
