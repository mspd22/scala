import advanced.car;
import advanced.vehicle;
import advanced.bicycle;

public class inheritance {
 
    public static void main(String[] args) {
        
        /*
         * 
         * The car class does not have a go method but it still works because the car 
         * class inherites form the vehicle class which contains a go method
         * 
        */

        car obj = new car();
        obj.go();

        bicycle bike = new bicycle();
        bike.stop();

        System.out.println(obj.speed);
        System.out.println(bike.speed);


        /*
         * 
         * New attributs and methods can be added to the sub classes to make them more 
         * specify in their behaviour 
         *  
        */

        System.out.println("Cars generally have " + obj.doors + " doors.");
        System.out.println("Bicycles have " + bike.pedals + " pedals");

        /*
         * 
         * The process of overriding methods is done by using the sub class to redefine a 
         * pre existing parent class method with new or added functionality to make it more 
         * specialised than its parent class countepart
         * 
         * -> It is done by using the same name and parameter as the parent class method and 
         * changing its working. The new method is the overriding method and the parent class
         *  method is called the overridden method
         * 
         * 
         * -> It is generally good practise to mention a function is a overriding function by using 
         * the @override syntax above the method definition.
        */

        vehicle tempObj = new vehicle();

        tempObj.go(); // -> the parent or super class method
        obj.go(); // -> uses the overriding method
    }
}
