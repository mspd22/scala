import include.car;
import include.Human;

public class oops {
    public static void main(String[] args) {
        
        /*
         * 
         * object -> an instance of a class that may contain attributes and methods
         * 
        */

        /*                    
                        OBJECT
                *---------------------* 
                |                     |                     
                |     ATTRIBUTES      |
                |   (or properties)   |
                |                     |
                |---------------------|                   
                |                     |
                |      METHODS        |
                |    (Behaviour)      |
                |                     |
                *---------------------* 

                -> can be created in same java file or another java file

                CLASS -> A blueprint for creating instances of a particular type
        */


        /*
         * SEE THE CAR CLASS IN THE INCLUDE FOLDER 
        */

        car myCar = new car();
        System.out.println(myCar.color);
        System.out.println(myCar.price);

        myCar.drive();
        myCar.brake();

        myCar.year = 2021; // change here
        System.out.println(myCar.year);

        // change in only one instance
        car myCar2 = new car();
        System.out.println(myCar2.year);

        /*
         * 
         * inorder to access the data members and methods we have to make them public 
         * 
        */


        System.out.println("\n\n\nEXAMPLE FOR CONSTRUCTORS");

        Human me = new Human("Pramod",20,80.0);

        System.out.println(me.name);
        me.eat();
        me.drink();

        /*
         * 
         * toStringMethod -> special method that all obects implictly inherit in java
         *                   can be changed to textually represent an object
         *  
        */

        // System.out.println(me); // same as below line if you explicitly declare the toString method
        System.out.println(me.toString());
    }
}
