import java.util.ArrayList;

public class AL {

    public static void main(String[] args) {
        
        ArrayList<String> food = new ArrayList<String>();

        food.add("pizza");
        food.add("hamBurger");
        food.add("hotDog");

        for (int i = 0;i<food.size();i++) {
            System.out.println(food.get(i));
        }

        System.out.println();

        food.set(0,"sushi");

        System.out.println(food);

        food.remove(1);

        System.out.println(food);

        food.clear();

        System.out.println(food);

        /*
         * (2D ArrayLists are the same as c++ vectors) 
        */
    }
}
