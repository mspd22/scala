import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class file {
    
    public static void main(String[] args) {
        
        /*
         * 
         * An abstract representation of file and directory pathnames
         *  
        */

        File file = new File("index.txt");

        if(file.exists()){
            System.out.println("EXISTS");
        } else {
            System.out.println("DOES NOT EXIST");
        }

        file = new File("/Users/sreepramod/Desktop/COLLAGE FOLDER/RP/RP.docx");
        if(file.exists()){
            System.out.println("EXISTS");
            System.out.println(file.getAbsolutePath());
        } else {
            System.out.println("DOES NOT EXIST");
        }

        // file.isFile()
        // file.getPath
        // file.getAbsolutePath
        // file.delete()

        /*
         * FILE WRITER 
        */

        try (
            FileWriter fw = new FileWriter("New.txt")) {
            fw.write("HELLO\njefsfnfslfdslff\nkjdfddssdc");
            fw.append("ANADKSJNC");
            fw.close();
        } catch (IOException e) {
            
            e.printStackTrace();
        }

        /*
         * 
         * File Reader class ->  read the contents of the file as a stream of characters.
         *                       One by one read() retuns a int vlaue which contians the
         *                       byte values when read() returns -1 there is no more data to read
         *  
        */

        try 
            (FileReader fr = new FileReader("NEW.txt")) {
            int data = fr.read();

            while(data != -1){
                System.out.println((char)data);
                data = fr.read();
            }

            fr.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch(IOException ie){
            ie.printStackTrace();
        }
    }
}
