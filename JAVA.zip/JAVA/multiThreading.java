import advanced.myRunnable;
import advanced.myThread;

public class multiThreading {
    
    public static void main(String[] args) throws InterruptedException {
        

        myThread thread1 = new myThread();

        myRunnable runnable1 = new myRunnable();
        Thread thread2 = new Thread(runnable1); // another way to create a new thread

        thread1.start();
        // thread1.join(1000); // the calling thread waits until the specified thread dies (or stops for some time) here the main thread will stop until thread1 stops
        thread2.start();
         
    }
}