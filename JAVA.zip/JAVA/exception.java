import java.util.InputMismatchException;
import java.util.Scanner;

public class exception {
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);

        try{
            System.out.print("ENTER  A WHOLE NUMEBR TO DIVIDE : ");
            int a = Integer.parseInt(input.nextLine());

            System.out.print("ENTER A NUMBER TO DIVIDE BY : ");
            int b = Integer.parseInt(input.nextLine());

            int z = a/b;
            System.out.println("\nTHE FINAL RESULT IS : " + z);

        }  catch(ArithmeticException e){

            System.out.println(e);

        } catch(InputMismatchException ie){

            System.out.println(ie);

        } catch(Exception ee){
            
            System.out.println("SOMETHING WENT WRONG");

        } finally {
            input.close();
        }    
    }
}
