import include.genericClass;

public class generics {
    
    public static void main(String[] args) {
        

        /*
         *  used for code compression and readability
         * 
         *  -> only works for reference types
        */


        Integer[] iara = {1,2,3,4,5};
        Double[] dara = {1.0,2.0,3.0};
        Character[] cara = {'a','b','c','d','e'};
        String[] sara = {"a","b","c","d"};

        display(iara);
        display(dara);
        display(cara);
        display(sara);

        System.out.println(getEle(iara, 2));
        System.out.println(getEle(dara, 1));
        System.out.println(getEle(cara, 4));
        System.out.println(getEle(sara, 0));

        /*
         * 
         * -> See genericClass in include package
         * 
        */

        genericClass<Integer> myInt = new genericClass<>(10);
        genericClass<Double> myDou = new genericClass<>(1000.231);
        genericClass<String> myStr = new genericClass<>("Hello World");

        System.out.println(myInt.getValue());
        System.out.println(myDou.getValue());
        System.out.println(myStr.getValue());

        /*
         * 
         * ArrayList is an example of a inbulit generic class with one genric parameters ArrayList<Thing> name;
         * 
         * HashMap is an example of a inbuilt generic class with two generic parameters HashMap<Thing1,Thing2> name;
         * 
        */

        /*
         *
         * You can lmit the types passed to the generic parameters by defining them as Thing extends Number(so only data types like int,double,long are allowed) etc.
         * 
        */
    }

    public static <Thing> void display(Thing[] array){

        for(Thing things : array){
            System.out.print(things + " ");
        }
        System.out.println();
    }

    public static <Thing> Thing getEle(Thing[] array,int index){
        return array[index];
    }
}
