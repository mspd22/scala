// import java.util.ArrayList;
// import include.car;
// import include.garage;
// import advanced.car;

public class test {

    public static void main(String[] args) {
        
        /*
         * ************************ EXMAPLE 1 ************************
        */

        /* 
        ArrayList<Integer> arr = new ArrayList<Integer>();

        for(int i = 0;i<10;i++) arr.add(i+1);

        System.out.println(arr);

        for(Integer i : arr){
            i = i * 2;
        }

        System.out.println(arr);

        for(int i : arr){
        i = i * 2;
        }

        System.out.println(arr);
        */

        /*
         * END 
        */

        
        /*
         * ************************ EXAMPLE 2 ************************
        */

        /*
         
        System.out.println(hello("Pramod",20));

        */

        /*
         * END
        */

        /*
         * ************************ EXAMPLE 3 ************************
        */
         
        /* 
        car[] carObj = new car[3];

        carObj[0] = new car();
        carObj[1] = new car("Tata","Hexa","Blue",2018,180000);
        carObj[2] = new car("Renault","Duster","Golden Brown",2014,140000);

        System.out.println(carObj[0].make);
        System.out.println(carObj[1].make);
        System.out.println(carObj[2].make);


        garage newGarage = new garage();
        newGarage.park(carObj[1]);

        */

        /*
         * END
        */


        /*
         * ************************ EXAMPLE 4 ************************
        */
        
        /* 
        car obj1 = new car("Tata","Hexa",2018);
        car obj2 = new car("Renault","Duster",2010);

        System.out.println("\nBEFORE COPYING");
        System.out.println(obj1);
        System.out.println(obj2);

        // obj1 = obj2;

        // System.out.println("\nAFTER COPYING");
        // System.out.println(obj1);
        // System.out.println(obj2);

        
        // * The above method makes it such that both tthe objects are pointed to the same memory location
        // So we use copy method and constructor

        obj2.copy(obj1);

        System.out.println(obj2.getMake());
        System.out.println(obj2.getModel());
        System.out.println(obj2.getYear());

        car obj3 = new car(obj1);

        System.out.println();
        System.out.println(obj3.getMake());
        System.out.println(obj3.getModel());
        System.out.println(obj3.getYear());

        //COPY CONSTRUCTOR

        */

        /*
         * END
        */


    }

    public static String hello(String name,int age){
        return "Hello " + name + ". You are " + age + " years old.";
    }

    public static int overload(int a, int b){
        return a + b;
    }

    public static int overload(int a, int b,int c){
        return a + b;
    }

    public static double overload(double a,double b){
        return a + b;
    }
    
}
