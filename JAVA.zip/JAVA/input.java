import java.util.Scanner;

public class input {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your name : ");
        String name = input.nextLine();
        System.out.print("Enter your age : ");
        int age = input.nextInt();  

        /*
         * 
         * There is a problem when using nextInt or nextFloat instead of nextLine 
         * The scanner will not completely read the entire line hence needing to 
         * explicitly make it go to the next line to take any other input in the 
         * succeding lines. One solution is to just take an empty or null input every
         * time we use any other input form other than nexline or to use nextline and
         * parse the input to the desired data type we need
         *  
        */

        // input.nextLine(); // -> this is important
        System.out.print("What is your favourite food");
        String food = input.nextLine();


        System.out.println("Your name is " + name.toUpperCase());
        System.out.println("You are " + age +" years old");
        System.out.println("Your favourite food is " + food);
        
        input.close();
    }
}
