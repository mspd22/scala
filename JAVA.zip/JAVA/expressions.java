public class expressions {
    public static void main(String[] args) {
        
        // expression = operands + operations

        int a =  10;
        System.out.println(a + 1);
        System.out.println(a - 1);
        System.out.println(a * 2);
        System.out.println(a / 5);
        System.out.println(a % 3);

        /*
         * 
         * integer division same as c++
         *  
        */

        /*
            type casting
        */

        // double b = /3
        double b = (double) a/3;

        System.out.println(b);


        /*
         * Math Methods
        */
        System.out.println("\n\nMATH METHODS");
        System.out.println(Math.max(10, 29));
        System.out.println(Math.min(10.9393,9291));
        System.out.println(Math.abs(-10393));
        System.out.println(Math.sqrt(292));
        System.out.println(Math.round(10.32923));
        System.out.println(Math.ceil(12.345));
        System.out.println(Math.floor(10.345));
        System.out.println(Math.pow(10, 3));
    }
}
