public class ab {
    
    public static void main(String[] args) {
        

        /*
         *
         * abstract -> abstract classes cannot be instantiated, but they can have a subclass 
         *          -> abstract methods are declared without an implementation
         *   
        */

        /*
         * -> used to add a layer of security by making sure that generic classes cannot be instantiated and missued 
         * -> abstract methods have to be defined in child classes
         * -> abstract methods can only be declared in abstract classes
        */
    }
}
