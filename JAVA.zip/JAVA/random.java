import java.util.Random;

public class random {
    public static void main(String[] args) {
        
        /*
         * Creat a Random class object to use that object to create random numbers 
        */
        Random random = new Random();

        
        int x = random.nextInt(10); // -> random.nextInt(lowerBound,uerBound);
        System.out.println(x); // 0 to 9

        System.out.println(random.nextDouble()); // 0 to 1 decimal values
    }
}
