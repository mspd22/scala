package advanced;

public class bicycle extends vehicle {
    
    public int wheels = 2;
    public int pedals = 2;
}
