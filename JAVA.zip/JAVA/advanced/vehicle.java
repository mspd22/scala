package advanced;

public class vehicle {
    
    public double speed;
    
    public void go(){
        System.out.println("The vehicle is Running.");
    }

    public void stop(){
        System.out.println("The vehicle is Stopped.");
    }
}
