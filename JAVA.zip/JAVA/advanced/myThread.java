package advanced;

public class myThread extends Thread{

    static int count = 0;
    public void run(){

        count++;
        System.out.println("The thread is running");

        for(int i = 10;i>0;i--){
            System.out.println("Thread #" + count + ' ' + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Thread #" + count + " is finished");
    }
}
