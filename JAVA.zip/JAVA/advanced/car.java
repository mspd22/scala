package advanced;

public class car extends vehicle {
    
    public int wheels = 4;
    public int doors = 4;

    public car(){

    }

    @Override
    public void go(){
        System.out.println("The car is moving");
    }

    /*
     * 
     * The below code is for getters and setters and object copy
     *  
    */
    
    private String make;
    private String model;
    private int year;

    public car(String make,String model,int year){
        this.make = make;
        this.model = model;
        this.year = year;
    }

    public car(car x){
        this.copy(x);
    }

    public String getMake(){
        return this.make;
    }

    public String getModel(){
        return this.model;
    }

    public int getYear(){
        return this.year;
    }

    public void setMake(String make){
        this.make = make;
    }

    public void setModel(String model){
        this.model = model;
    }

    public void setYear(int year){
        this.year = year;
    }

    public void copy(car obj){

        this.setMake(obj.getMake());
        this.setModel(obj.getModel());
        this.setYear(obj.getYear());
    }
}
