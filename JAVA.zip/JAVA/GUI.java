import javax.swing.JOptionPane;

public class GUI {
    public static void main(String[] args) {
        
        String name = JOptionPane.showInputDialog("Enter your name : ");
        JOptionPane.showMessageDialog(null, "Hello " + name);

        int age = Integer.parseInt(JOptionPane.showInputDialog("Enter youe age here : "));
        JOptionPane.showMessageDialog(null,"Your age is " + age);

        Double height = Double.parseDouble(JOptionPane.showInputDialog("Enter your height : "));
        JOptionPane.showMessageDialog(null,"Your height is " + height);

    }
}
