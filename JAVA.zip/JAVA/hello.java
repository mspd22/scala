public class hello {
    
    public static void main(String[] args) {

        // System.out.println("Hello World"); // printing to console window
        // System.out.println("There is implicit end line delimeter in println but not in print");
        // System.out.println("sysout + tab or just selecting the drop down option in most IDE's\nwill allow you to skip typing the entire thing out.");
        
        /*
         * Variables 
        */

        int x = 10;
        System.out.println(x + " is my Number");
        float y = 3.14f;
        System.out.println(y + " is the value of pi");

        System.out.println("There is no swap function in java, so use xor or a = a + b - (b = a)");
    }

}

/*
 * comments are the same as c++ 
*/