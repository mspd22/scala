error id: c+Zi9CmPjM87ylISdMsYpQ==
### Bloop error:

source file not found: <WORKSPACE>/src/main/scala/.scala-build/scala_b740afc53c-d46b317401/src_generated/main/1_string.worksheet.scala
#### Short summary: 

source file not found: <WORKSPACE>/src/main/scala/.scala-build/scala_b740afc53c-d46b317401/src_gener...