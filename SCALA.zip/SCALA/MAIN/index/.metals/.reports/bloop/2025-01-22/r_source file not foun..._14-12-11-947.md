error id: PGlcd0B6cNT/P/Qlkurg9A==
### Bloop error:

source file not found: <WORKSPACE>/src/main/scala/.scala-build/scala_b740afc53c-c4848335a3/src_generated/main/6_functions.worksheet.scala
#### Short summary: 

source file not found: <WORKSPACE>/src/main/scala/.scala-build/scala_b740afc53c-c4848335a3/src_gener...