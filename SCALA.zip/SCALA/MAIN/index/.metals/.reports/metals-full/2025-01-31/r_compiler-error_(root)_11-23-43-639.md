file://<WORKSPACE>/src/main/scala/oops/5_generics.scala
### dotty.tools.dotc.ast.Trees$UnAssignedTypeException: type of Ident(animalList) is not assigned

occurred in the presentation compiler.

presentation compiler configuration:


action parameters:
offset: 1289
uri: file://<WORKSPACE>/src/main/scala/oops/5_generics.scala
text:
```scala
package oops

/* Collections in scala are a powerful tool used to hold things of a certain type but if we want to make a collection 
    for everytype we might have to duplicate the code for everytype but the Generics class in scala solves thos problem */
object Generics extends App{
    
    // We can declare a generic class in scala using the syntax
    class MyList[A]{
        // now we can use the type A inside this class
    }
    
    val intList = new MyList[Int]
    // or 
    val strList = new MyList[String]

    // we can use declare traits of generic type as such
    trait exampleOfGenericTrait[A] {

    }

    // we can also make generic methods but NOT GENERIC OBJECTS
    object MyList{
        def empty[A] : MyList[A] = new MyList[A]
    }

    // Now we can call this method using 
    val newEmptyIntList = MyList.empty[Int]

    /* 
        VARIANCE PROBLEM
     */

    class Animal
    class Cat extends Animal
    class Dog extends Animal

    // Now we know that Cat extends Animal but does a List Of Cat also extends a List of Animal
    // There are three answers to this

    /* 1. YES, List[Cat] extends List[Animal] -> COVARIANCE, we do this by using the +A keyword which means this is a covariant list */
    class CovariantList[+A]
    val animalList[@@]
    
}

```



#### Error stacktrace:

```
dotty.tools.dotc.ast.Trees$Tree.tpe(Trees.scala:74)
	dotty.tools.dotc.util.Signatures$.applyCallInfo(Signatures.scala:208)
	dotty.tools.dotc.util.Signatures$.computeSignatureHelp(Signatures.scala:104)
	dotty.tools.dotc.util.Signatures$.signatureHelp(Signatures.scala:88)
	dotty.tools.pc.SignatureHelpProvider$.signatureHelp(SignatureHelpProvider.scala:46)
	dotty.tools.pc.ScalaPresentationCompiler.signatureHelp$$anonfun$1(ScalaPresentationCompiler.scala:435)
```
#### Short summary: 

dotty.tools.dotc.ast.Trees$UnAssignedTypeException: type of Ident(animalList) is not assigned