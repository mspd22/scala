error id: oops/inheritance.Animal#eat().
file://<WORKSPACE>/src/main/scala/oops/3_inheritance.scala
empty definition using pc, found symbol in pc: oops/inheritance.Animal#eat().
semanticdb not found
|empty definition using fallback
non-local guesses:
	 -

Document text:

```scala
package oops

/* 
    INHERITANCE IN SCALA

    1. It is done using the extends keyword like in java
    2. There are three access modifiers in Scala they are
        a. Public by default
        b. Protected
        c. Private

 */
object inheritance {
    
    def main(args : Array[String]): Unit = {
        
        val marie = fPerson("Marie"); // using companion object 
        println(marie.name);

        val cat1 = new Cat;
        cat1.crunch;
    }

    object fPerson{
        def apply(name : String) = new fPerson(name,0);
    }

    /*  CONSTRUCTORS IN INHERITING */
    class fPerson(val name : String, age : Int) {
        
    }

    // In scala the parent class will get instantiated first when we try to instantiate a child class jsut like java 
    // and we need to have the correct constructor and gaurentee that its present
    // the compuler will need to call the parent class constructor first before its own
    // so just saying -> class Adult(name : String, age : Int, id : String) extends fPerson ->  is not enough, we need to say
    class Adult(name : String, age : Int, id : String) extends fPerson(name,age){

    }

    // and if there is a secondary constructor in the class definition then we can shorten the way we write the inheritance parameters, like this

    /* 
        class fPerson(name : String, age : Int) {
            def this(name : String) = this(name,0); // some default value for age and pass this to the primary constructor
    }


    class Adult(name : String, age : Int, id : String) extends fPerson(name){

    }
     */

    //

    /*  __________________________________________________________________________________________ */


    class Animal{
        protected def eat = println("Nom Nom Nom");
    }

    class Cat extends Animal{

        def crunch : Unit ={
            println("Mewom Mewom")
            eat
        }
    }
    
    class Dog extends Animal{
        override protected def eat: Unit = println("Bork Bork");
    }
}

```

#### Short summary: 

empty definition using pc, found symbol in pc: oops/inheritance.Animal#eat().