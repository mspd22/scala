error id: `<none>`.
file://<WORKSPACE>/src/main/scala/oops/typesOfI.scala
empty definition using pc, found symbol in pc: `<none>`.
empty definition using semanticdb
|empty definition using fallback
non-local guesses:
	 -

Document text:

```scala
package oops

object typesOfI {
  
    /* 1. SINGLE CLASS INHERITANCE */

    class Animal{

        def eat : String = println("Nom Nom Nom");
    }

    class Cat extends Animal{

    }
}

```

#### Short summary: 

empty definition using pc, found symbol in pc: `<none>`.