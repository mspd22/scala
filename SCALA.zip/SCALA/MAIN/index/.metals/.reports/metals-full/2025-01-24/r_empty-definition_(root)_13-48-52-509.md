error id: scala/annotation/meta/
jar:file://<HOME>/Library/Caches/Coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.15/scala-library-2.13.15-sources.jar!/scala/annotation/meta/beanGetter.scala
empty definition using pc, found symbol in pc: scala/annotation/meta/
semanticdb not found
|empty definition using fallback
non-local guesses:
	 -

Document text:

```scala
/*
 * Scala (https://www.scala-lang.org)
 *
 * Copyright EPFL and Lightbend, Inc.
 *
 * Licensed under Apache License 2.0
 * (http://www.apache.org/licenses/LICENSE-2.0).
 *
 * See the NOTICE file distributed with this work for
 * additional information regarding copyright ownership.
 */

package scala.annotation.meta

/**
 * Consult the documentation in package [[scala.annotation.meta]].
 */
final class beanGetter extends scala.annotation.StaticAnnotation

```

#### Short summary: 

empty definition using pc, found symbol in pc: scala/annotation/meta/