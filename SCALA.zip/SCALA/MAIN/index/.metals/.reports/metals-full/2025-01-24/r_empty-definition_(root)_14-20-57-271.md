error id: oops/ePerson#hangingOutWith().
file://<WORKSPACE>/src/main/scala/oops/exercise.scala
empty definition using pc, found symbol in pc: oops/ePerson#hangingOutWith().
semanticdb not found
|empty definition using fallback
non-local guesses:
	 -

Document text:

```scala
package oops

/* Novel and Writer class */
class Writer(firstName : String,surName : String,val birthYear : Int){

    def getFullName() : String = f"$firstName%s $surName%s";
}

class novel(name : String, releaseYear : Int, author : Writer){

    def authorAge() : Int = author.birthYear - releaseYear;

    def getName() : String = author.getFullName()

    def isWrittenBy(author : Writer) : Boolean = this.author == author; // will check not just the attributes but the instance itself

    def copy(newReleaseYear : Int) : novel = new novel(name,newReleaseYear,author);
}



/* ________________________________________________________________________________________ */


/*  Counter class */

class counter(num : Int) {
    
    def getCurentCount() : Int = num; // this is same as saying || class counter(val num : Int){}

    def incrCount() = {

        println("Incrementing");
        new counter(num + 1); 

    } // immutability in this instance

    /*  Immutability generally says that the instances are fixed and cannot be changed inside, whenever you want to modify an instance you
        need to create a new instance with the modified values
     */

    def decrCount() : counter = new counter(num - 1);

    def decrCount(mod : Int) : counter = new counter(num - mod);

    def incrCount(n : Int) : counter = {
        if(n <= 1) this

        else incrCount().incrCount(n-1); 
    }

    /*  
        !!!! HERE IF YOU USE THE () IN THE DEFAULT METHOD WITH NO PARAMETER YOU WILL NEED TO USE () WHILE CALLING IT TOO IF NOT 
         THEN NO NEED OF BRACKETS. 

        def incrCounter() : counter = {
            
        }

        Then incrCounter().incrCounter(n-1)

        If not 

        def incrCounter : counter = {
            
        }

        then incrCounter.incrCounter(n-1);
     */


}
/* ________________________________________________________________________________________ */

/* PERSON CLASS */

class Person(val name : String, age : Int, favoriteMovie : String) {
        def likes(movie : String) : Boolean = movie == favoriteMovie;

        def hangingOutWith(person : Person) : String = f"${this.name} is hanging out with ${person.name}."
        
        def + (person : Person) : String = f"${this.name} is hanging out with ${person.name}."

        def unary_! : String = s"$name, What the operator!";

        def isAlive : Boolean = true;

        def apply() : String = s"Hi, my name is $name and my favorite Movie is $favoriteMovie";

        // Exercise methods

        def + (nickName : String) : Person = new Person(name + s"( $nickName )", age, favoriteMovie);

        def unary_+ : Person = new Person(name,age + 1,favoriteMovie);

        def learns(str : String) : String = s"$name learns $str";

        def learnsScala : String = learns("Scala");

        def apply(num : Int) : String = s"$name has seen $favoriteMovie $num times";


        @main def main() : Unit = {

            val mary = new Person("Mary",25,"Inception");

            println(mary + "The Rockstar");
        }
}


```

#### Short summary: 

empty definition using pc, found symbol in pc: oops/ePerson#hangingOutWith().