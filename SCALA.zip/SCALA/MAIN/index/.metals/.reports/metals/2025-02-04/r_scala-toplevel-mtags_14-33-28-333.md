error id: file://<WORKSPACE>/src/main/scala/oops/exercise.scala:[4223..4224) in Input.VirtualFile("file://<WORKSPACE>/src/main/scala/oops/exercise.scala", "package oops

/* Novel and Writer class */
class Writer(firstName : String,surName : String,val birthYear : Int){

    def getFullName() : String = f"$firstName%s $surName%s";
}

class novel(name : String, releaseYear : Int, author : Writer){

    def authorAge() : Int = author.birthYear - releaseYear;

    def getName() : String = author.getFullName()

    def isWrittenBy(author : Writer) : Boolean = this.author == author; // will check not just the attributes but the instance itself

    def copy(newReleaseYear : Int) : novel = new novel(name,newReleaseYear,author);
}



/* ________________________________________________________________________________________ */


/*  Counter class */

class counter(num : Int) {
    
    def getCurentCount() : Int = num; // this is same as saying || class counter(val num : Int){}

    def incrCount() = {

        println("Incrementing");
        new counter(num + 1); 

    } // immutability in this instance

    /*  Immutability generally says that the instances are fixed and cannot be changed inside, whenever you want to modify an instance you
        need to create a new instance with the modified values
     */

    def decrCount() : counter = new counter(num - 1);

    def decrCount(mod : Int) : counter = new counter(num - mod);

    def incrCount(n : Int) : counter = {
        if(n <= 1) this

        else incrCount().incrCount(n-1); 
    }

    /*  
        !!!! HERE IF YOU USE THE () IN THE DEFAULT METHOD WITH NO PARAMETER YOU WILL NEED TO USE () WHILE CALLING IT TOO IF NOT 
         THEN NO NEED OF BRACKETS. 

        def incrCounter() : counter = {
            
        }

        Then incrCounter().incrCounter(n-1)

        If not 

        def incrCounter : counter = {
            
        }

        then incrCounter.incrCounter(n-1);
     */


}
/* ________________________________________________________________________________________ */

/* PERSON CLASS */

class ePerson(val name : String,val age : Int = 0, favoriteMovie : String) {
        def likes(movie : String) : Boolean = movie == favoriteMovie;

        def hangingOutWith(person : ePerson) : String = f"${this.name} is hanging out with ${person.name}."
        
        def + (person : ePerson) : String = f"${this.name} is hanging out with ${person.name}."

        def unary_! : String = s"$name, What the operator!";

        def isAlive : Boolean = true;

        def apply() : String = s"Hi, my name is $name and my favorite Movie is $favoriteMovie";

        // Exercise methods

        def + (nickName : String) : ePerson = new ePerson(name + s"($nickName)", age, favoriteMovie);

        def unary_+ : ePerson = new ePerson(name,age + 1,favoriteMovie);

        def learns(str : String) : String = s"$name learns $str";

        def learnsScala = this `learns` "Scala";

        def apply(num : Int) : String = s"$name has seen $favoriteMovie $num times";
}

/*  ________________________________________________________________________________________ */



/* EXCEPTIONS */

class PocketCalculator{

    class OverFlowException extends Exception
    class UnderFlowException extends  Exception
    class MahtCalculationException extends Exception

    def add(x : Int,y : Int) : AnyVal = {

        try {
            val res = x + y

            if(res > Int.MaxValue) throw new OverFlowException

            else if(res < Int.MinValue) throw new UnderFlowException
        } catch{
            case e : OverFlowException => println("THE RESULT IS NOT AN INTEGER (OVERFLOW)")
        }
    }


    def sub(x : Int, y : Int) : AnyVal = {

        try{
            val res = x - y
            if(res < Int.MinValue) throw new UnderFlowException

            else if(res > Int.MaxValue) throw new OverFlowException
        } catch {
            case e : UnderFlowException => println("THE RESULT IS NOT AN INTEGER (UNDERFLOW)")
        }
    }

    def mul(x : Int, y : Int) : AnyVal = {
        try{
            val res = x * y

            if(res < Int.MinValue) throw new UnderFlowException

            else if(res > Int.MaxValue) throw new OverFlowException
        } catch {
            case e : MahtCalculationException => println("MCE")
        }
    }

    def 
}
object except extends App{

    // crashing my program with a out of memory problem

    // throw new OutOfMemoryError

    //crashing the program with a SOE exception
    // throw new StackOverflowError
}
/* ________________________________________________________________________________________ */





/* 
    CONTRAVARICE PROBLEM
    INHRITANCE.SCALA
 */")
file://<WORKSPACE>/file:<WORKSPACE>/src/main/scala/oops/exercise.scala
file://<WORKSPACE>/src/main/scala/oops/exercise.scala:154: error: expected identifier; obtained rbrace
}
^
#### Short summary: 

expected identifier; obtained rbrace