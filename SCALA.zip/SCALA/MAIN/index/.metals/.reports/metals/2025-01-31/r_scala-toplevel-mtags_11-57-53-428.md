error id: file://<WORKSPACE>/src/main/scala/oops/myList.scala:[696..697) in Input.VirtualFile("file://<WORKSPACE>/src/main/scala/oops/myList.scala", "package oops

abstract class myList[+A] {

    def head : A
    def tail : myList[A]
    def add[B >: A](element : B) : myList[B]
    def isEmpty : Boolean
    def printElements : String

    // this is a polymorphic call since the printElements method is different for both the two sub classes
    override def toString(): String = "[ " + printElements + "]"
}


//Nothing is proper substitue of any type
// here we have to take extra steps because saying
// val newLis : Mylist[Int] = Empty is valid so,
object Empty extends myList[Nothing]{

  override def head: Nothing = throw new NoSuchElementException
  override def tail: myList[Nothing] = throw new NoSuchElementException
  override def [B >: Nothing]add(element: ): myList[Nothing] = new cons(element,Empty )
  override def isEmpty: Boolean = true
  override def printElements: String = ""
}

class cons[+A](h : A, t : myList[A]) extends myList[A]{

  override def head: A = h
  override def tail: myList[A] = t
  override def add[B >: A](element: B): myList[B] = new cons(element,this)
  override def isEmpty: Boolean = false 
  override def printElements: String = {
    h + " " + t.printElements
  }
}

object testing extends App{

    val mylist = new cons(10,cons(12,cons(14,cons(16,cons(20,Empty)))))
    
}

")
file://<WORKSPACE>/file:<WORKSPACE>/src/main/scala/oops/myList.scala
file://<WORKSPACE>/src/main/scala/oops/myList.scala:23: error: expected identifier; obtained lbracket
  override def [B >: Nothing]add(element: ): myList[Nothing] = new cons(element,Empty )
               ^
#### Short summary: 

expected identifier; obtained lbracket