@main 
def hello(): Unit = {
  println("Hello world!")
  println(msg)

}

def msg = "I was compiled by Scala 3. :)"



/* 
    1. Scala runs on browsers and JVM. It can be used for server-side applications and can also be used with Scala.js format.
    2. It does not provide low level handling capabilities like, pointers and memory mangement.
    3. It has a concise syntax
    4. It is fully integratable with java code and has a wide range of great frameworks which extend its functionalites
    5. It is a strong statically typed language.
 */


/* 
    1. Traits -> Used in Scala => A trait encapsulates method and field definitions, which can then be reused by mixing them 
                  into classes. Traits are used to define object types by specifying the signature of the supported methods.

    2. Scala can be run in interactive mode using the scala terminal or shell; and the other way is to use the script mode
        which uses a word file to run scala program. Name the text document ending with the extension .scala and use the 
        terminal to run 
          a. scalac name.scala
          b. scala name

    3. def main(args : Array[String]) : unit = {} is the default starting point for any scala program

    4. Scala is case sensitive

    5. Nomeclature generally followed in Scala programming
      a. Class names should start with a capital letter and follow camel case
      b. Method Names should start with a small letter and follow camel case
      c Program file namae should be the same as java, file name should be same as object name

    6. Identifiers same as java language{

        The Scala compiler will internally "mangle" operator identifiers to turn them into legal Java identifiers with embedded $ characters. 
        For instance, the identifier :-> would be represented internally as $colon$minus$greater.

        ##{
          Mixed Identifiers -> Identifier followed by an underscore and an operator identifier

          Literal Identifiers -> 'identifier'
        }
    }

  7. 50 Keywords

  8. Scala is a new line oriented language i.e no need for delimeter(;) at the end of the statements and instead just write them in a new line.

  9. You can import more than one class or object from a single package, for example, TreeMap and TreeSet from the scala.collection.
      immutable package − import scala.collection.immutable.{TreeMap, TreeSet}

    
 */

