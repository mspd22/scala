package oops

object methidNotations {

    class Person(val name : String,favoriteMovie : String) {
        def likes(movie : String) : Boolean = movie == favoriteMovie;

        def hangingOutWith(person : Person) : String = f"${this.name} is hanging out with ${person.name}."
        
        def + (person : Person) : String = f"${this.name} is hanging out with ${person.name}."

        def unary_! : String = s"$name, What the operator!";

        def isAlive : Boolean = true;

        def apply() : String = s"Hi, my name is $name and my favorite Movie is $favoriteMovie";
    }

    def main() : Unit = {
        val mary = new Person("Mary","Inception");

        println(mary.likes("Inception"));
        println(mary `likes` "Inception"); 

        // THE ABOVE STATEMENTS ARE EQUIVALENT

        /* 
            1. This is called the infix notation style
            2. This notation works with methods that have only one parameter
            
            3.!!!! THE STYLE OF CALLING METHODS LIKE THIS IS CALLED SYNTATIC SUGARS. - {a nicer way to represent a complex code.}

            This method is created in scala for : "operators" in SCALA
         */

        val tom = new Person("Tom","Figth Club");

        println(mary `hangingOutWith` tom); // here we can actually use operators like

        /* + - / * ..etc */

        println(mary + tom);
        println(mary.+(tom));

        //ALL OPERATORS ARE METHODS!!!!!

        println(1.+(2));

        // PREFIX NOTATIONS
        val x = -1;
        val y = 1.unary_-;

        // this is the same, unary operator only works with + - ` !`

        println(!mary) // or println(mary.unary_!);


        // POSTFIX NOTATIONS
        println(mary.isAlive);
        // println(mary isAlive);

        /* THE APPLY METHOD */

        println(mary.apply())
        println(mary()) // same as above
    }  
}

