package oops

object exceptions extends App{
    
    val x : String = null
    // println(x.length()) 
    // this ^^ will crash the jvm -> throws the null pointer exception

    /* throwing and catching exception - the above line of code crashes the jvm because there is no one to catcht the exception */

    // val aWerirdValue : Nothing = throw new NullPointerException
    
    /*  Like everything else in scala throwing an exception is an expression with a Nothing type
        SO it doesnt really hold a value but can be assigned

        Exceptions are really instances of classes

        throwable classes extend the throwable class -> major sub classes include error and exception
     */

    def getInt(x : Boolean) : Int = {
        if(x) throw new RuntimeException

        else 42
    }

    try{
        getInt(true)
    } catch {
        case e : RuntimeException => println("Runtime Exception")
    } finally {
        println("A code that will get executed no matter what")
    }

    /* 
        IF WE DO NOT CATCH THE RIGHT KIND OF EXCEPTION THEN THE PROGRAM WILL CRASH BUT STILL THE CODE IN THE FINALLY BLOCK WILL GET EXECUTED 
            FIRST BEFORE THE JVM CRASHES 

        EXCEPTIONS COME FROM THE JVM NOT THE SCALA LANGUAGE, THEY ARE JAVA SPECIFIC EXCEPTIONS

        -> FINALLY BLOCKS DO NOT  INFLUENCE THE RETURN TYPE OF THE TRY-CATCH-FINALLY BLOCK
        -> THE RETURN TYPE OF THE TRY-CATCH-FINALLY BLOCK IS DEPENDENT ON THE RETURN TYPE OF THE TRY BLOCK AND ALL OTHER CATCH BLOCKS,
            THE COMPILER WILL TRY TO GROUP THE LEAST COMMMON ANCESTOR OF THE RETURN TYPES
     */

     /* HOW TO DEFINE OUR OWN EXCEPTIONS */

    class myException extends Exception

    try {
        throw new myException
    } catch{
        case e : myException => println("You can also create and throw your own custom exceptions like this.")
    }

    /* Exercises */

    
}
