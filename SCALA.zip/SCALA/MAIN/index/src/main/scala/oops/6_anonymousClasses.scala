package oops

object anonymousClasses extends App{
    
    abstract class Animal{
        def eat : Unit
    }

    // this is an anonymopus class, we have instantiated a real class here, funnyAnimal is a real class
    val funnyAnimal : Animal = new Animal{
        override def eat: Unit = println("ha ha ha ha ha ha")
    }

    println(funnyAnimal.getClass()) // -> class oops.anonymousClasses$$anon$1

    /* 
        BEHIND THE SCENES WITH THE COMPILER: 
            class anonymousClasses$$anon$1 extends Animal {
                override def eat: Unit = println("ha ha ha ha ha ha")
            }
            
            val funnyAnimal : Animal = new anonymousClasses$$anon$1
     */

    class Person(name :String){
        def sayHi : Unit = println(s"Hi my name is $name, How about you ?")
    }

    //Anonymous classes work with abstract classes as well as non abstract classesf
    val john = new Person("JIM "){
        override def sayHi: Unit = println("ONLY IF WEREN;T FOR")
    }
}
