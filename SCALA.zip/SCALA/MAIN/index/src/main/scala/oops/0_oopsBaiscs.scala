package oops

/* Class definitions can sit on the top level code */
object oopsBaiscs{
    def main() : Unit = {
        val obj1 = new Person("John",20);
        println(obj1);

        println(obj1.x);

        /* Since the class body contains a side effect everytime you create a new instance of the class the side effect is executed */

        val obj2 = new Person("",100);

        obj1.greet("Doe");
        // Here println(obj1.age) -> 20 will not work since class parameters are not class members or fileds
    }
}

/* 
    Unlike the other languages in Scala class parameters are not class memebers 
    SO DOING SOMETHING LIKE object.memeber will not resolve the instance of that attribute/field
    TO convert class parameters into class memebers we can use the val or var keywod before the parameters in the class signature
 */
class Person(name : String, val age : Int){
    // class body is contained between the {} 
    // SO age is a class memeber now

    /* 
        The class definition also acts as code block so the side effects inside the class body will be evaluated and calaculated
     */

    val x = 10;

    def greet(name : String) : Unit = println(f"${this.name}%s says : Hi $name%s"); // this can be used with parametes as well as fields

    println("This is a side effect due to the fact that the Person class is now taking this expression as a value");
}

/* Method overloading and Constructor Overloading is supported in Scala */