package oops

/* 
    INHERITANCE IN SCALA

    1. It is done using the extends keyword like in java
    2. There are three access modifiers in Scala they are
        a. Public by default
        b. Protected
        c. Private

 */
object inheritance extends App{
    
        
    val marie = fPerson("Marie"); // using companion object 
    println(marie.name);

    val cat1 = new Cat;
    cat1.crunch;

    val dog1 = new Dog;
    dog1.eat();

    println(dog1.creatureType)
    
    

    object fPerson{
        def apply(name : String) = new fPerson(name,0);
    }

    /*  CONSTRUCTORS IN INHERITING */
    class fPerson(val name : String, age : Int) {
        
    }

    // In scala the parent class will get instantiated first when we try to instantiate a child class jsut like java 
    // and we need to have the correct constructor and gaurentee that its present
    // the compuler will need to call the parent class constructor first before its own
    // so just saying -> class Adult(name : String, age : Int, id : String) extends fPerson ->  is not enough, we need to say
    class Adult(name : String, age : Int, id : String) extends fPerson(name,age){

    }

    // and if there is a secondary constructor in the class definition then we can shorten the way we write the inheritance parameters, like this

    /* 
        class fPerson(name : String, age : Int) {
            def this(name : String) = this(name,0); // some default value for age and pass this to the primary constructor
    }


    class Adult(name : String, age : Int, id : String) extends fPerson(name){

    }
     */

    //

    /*  __________________________________________________________________________________________ */


    class Animal{

        val creatureType = "Wild"
        protected def eat() = println("Nom Nom Nom"); // we can also just say def eat : Unit = {} and we do not have to use the () operator when calling the eat method
    }

    class Cat extends Animal{

        def crunch : Unit ={
            eat()
            println("Mewom Mewom")
            
        }
    }
    
    class Dog extends Animal{
 
        override val creatureType: String = "Domestic" // We can also override the values or vals using the override keyword
        override def eat() = println("Bork Bork");
    }

    /* 
        Here we have overrided the field creatureType by using the override keyword and using it in the field : We can also do this

        -> overriding fields of super classes directly from the constructor
        class Dog(override val creatureType : String) extends Animal{
            ....
        } 

        or

        -> using class parameters to override the fields of super classes
        class Dog(dogType : String) extends Animal {
            override creatureType = dogType;
            ....
        }

        all instances of a dreived class will use the most overridden implementation
     */

     /* 
        POLYMORPHISM

        type substitution 
     */

    val unKnownAnimal : Animal = new Dog();
    // unKnownAnimal.eat();  //RESEARCH THIS !!!!


    /*  SUPER KEYWORD -> Used to refernce a method or field from parent class */

    /* PREVENTING OVERRIDES 

        use the final keyword

        1. Use it on class methods -> prevents child classes from overriding it
        2. Use it on the class itself -> The final class cannot be inherited by any other class
        3. Seal the class using the sealed keyword -> prevents the extension of this class from other files but other classes in the same file can extend it
            -> mostly used when you want your class hirarchy to be exhaustive
    */
}
