package oops

/* SCALA DOES NOT HAVE CLASS LEVEL FUNCTIONALITY OR "STATIC" */

/* 
    SO in java we say
    class t{

        public static void main(String []args){
    
            System.out.println(Person.N_EYES);
        }
    
    }

    class Person {
        static public final int N_EYES = 2;
    }

    In scala we have,
 */
object objects {

    object dPerson{
        val N_EYES : Int = 2;

        def apply(mother : String, father : String) : dPerson = new dPerson("Bobbie");
    }

    class dPerson(val name : String){

    }

    @main def main() : Unit = { 

        println(dPerson.N_EYES);

        val a = dPerson;
        val b = dPerson;

        println(a == b) // true becoz there can onyl be a single instance of the object

        val bobbie = dPerson("m","f");
    }
}

/* 
    IN SCALA objects are

    1. Its own type
    2. It's only instance it can have
    3. It's own class

    Hence it is a singleton instance (object)


    !!!!! COMPANIONS

    In scala we often write the object and class of same name as file name

    This is to seperate them as 
    1. Instance Level functionality - classes
    2. Class or "Static" level functionality - object

    Companions are easier to access.

    Scala is more object oreinted than almost all oops languages like java due to this feature 
        ->  you either access all the code form a singleton instance or a regular instance

    When you use companions you have a single isntance of the object you can access with its name like all the static values you need in 
    one place i.e that single instance.
 */

/* 
    FACTORY METHODS -> methods used for creating new instances, for example in Person object the apply method is generally used to make new instances 
    of the companion class    
*/

// SCALA APPLICATION IS A SCALA OBJECT WITH :> def main(args : Array[String]) : Unit = { }