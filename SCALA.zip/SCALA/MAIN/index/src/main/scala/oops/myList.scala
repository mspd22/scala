package oops

/* 

    TRAITS

 */


trait MyPredicate[-A]{
    def test(element : A) : Boolean
}

trait MyTransformer[-A,B]{
    def transform(element : A) : B
}


/* ------------------------------------------------------------------------------------------------------------*/
abstract class myList[+A] {

    def head : A
    def tail : myList[A]
    def add[B >: A](element : B) : myList[B]
    def isEmpty : Boolean
    def printElements : String

    // this is a polymorphic call since the printElements method is different for both the two sub classes
    override def toString : String = "[ " + printElements + "]"

    def map[B](transformer : MyTransformer[A,B]) : myList[B]
    def flatMap[B](transformer : MyTransformer[A,myList[B]]) : myList[B]
    def filter(predicate : MyPredicate[A]) : myList[A]

    // concatination
    def ++[B >: A](list : myList[B]) : myList[B]
}

class cons[+A](h : A, t : myList[A]) extends myList[A]{

    def head: A = h
    def tail: myList[A] = t
    def add[B >: A](element: B): myList[B] = new cons(element,this)
    def isEmpty: Boolean = false 
    def printElements: String = {
      h.toString + " " + t.printElements
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - //

    def filter(predicate : MyPredicate[A]) : myList[A] = {
        if(predicate.test(h)) new cons(h,t.filter(predicate)) 

        else t.filter(predicate)
    }

    def map[B](transformer : MyTransformer[A,B]) : myList[B] = {
        new cons(transformer.transform(h),t.map(transformer))
    }

    /* 
      For example : [1, 2] ++ [3,4,5] =>
        new cons(1, [2] ++ [3,4,5]) =>
          new cons(1,new cons(2,Empty ++ [3,4,5])) =>
            new cons(1,new cons(2, [3,4,5]) => new cons(1,new cons(2,new cons(3,new cons(4,new cons(5,Empty)))))
     */
    def ++[B >: A](list: myList[B]): myList[B] = new cons(h, t ++ list)
    def flatMap[B](transformer : MyTransformer[A,myList[B]]) : myList[B] = transformer.transform(h) ++ t.flatMap(transformer)
    
}


//Nothing is proper substitue of any type
// here we have to take extra steps because saying
// val newLis : Mylist[Int] = Empty should be valid so,
object Empty extends myList[Nothing]{

    def head: Nothing = throw new NoSuchElementException
    def tail: myList[Nothing] = throw new NoSuchElementException
    def add[B >: Nothing](element: B): myList[B] = new cons(element,Empty )
    def isEmpty: Boolean = true
    def printElements: String = ""

    def map[B](transformer : MyTransformer[Nothing,B]) : myList[B] = Empty

    def filter(predicate : MyPredicate[Nothing]) : myList[Nothing] = Empty

    def ++[B >: Nothing](list : myList[B]) : myList[B] = list

    def flatMap[B](transformer : MyTransformer[Nothing,myList[B]]) : myList[B] = Empty
}


object testing extends App{

    val mylist = new cons(10,cons(12,cons(14,cons(16,cons(20,Empty)))))
    println(mylist.toString)

    val mylist2 = new cons("Hello",cons("world",cons("welcome",cons("to",cons("scala",Empty)))))
    println(mylist2.toString)

    println(mylist.map[Int](new MyTransformer[Int,Int] {
      override def transform(element: Int): Int = element*2
    }).toString)

    println(mylist.filter(new MyPredicate[Int] {
      override def test(element: Int): Boolean = element % 4 == 0
    }).toString)

    println(mylist.map(new MyTransformer[Int,Double]{
      override def transform(element: Int): Double = element.toDouble 
    }).toString)
    
    println(mylist ++ mylist.map(new MyTransformer[Int,Int] {
      override def transform(element: Int): Int =  element * element
    }))
    
    println(mylist.flatMap(new MyTransformer[Int,myList[Int]] {
      override def transform(element: Int): myList[Int] = new cons(element,new cons(element + 1,Empty))
    }).toString)
}

